/* eslint-disable handle-callback-err */
/* eslint-disable no-alert */
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as constants from "./Constants";
import { Alert, Platform, Share } from "react-native";
import END_POINT from "./EndPoints";
import { Actions } from "react-native-router-flux";
import { APIClient, CoinCultApi } from "./api";
import { showMessage } from "react-native-flash-message";
import { colors } from "./theme";
import { encryptData, DecryptDataSingle } from "./encryptionUtils";
import EncryptedStorage from "react-native-encrypted-storage";

const KEY_ENCRYPTION = "XCHANGE_MONSTER_ENCRYPTION";
export default class Singleton {
  static myInstance = null;
  deviceToken = "";
  accessToken = "";
  kycId = "";
  hideZeroBalance = false;
  checkAuthBack = false;
  theme = "theme1";
  statusChange = null;
  showMaintenance = null;
  favArrayKey = "favArr";
  encryptionKey =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  buySellTicketSocket = null;
  marketTradeSocket = null;
  isLogin = false;
  isLoginSuccess = false;
  refreshingToken = false;
  tradeArr = [
    { txt: 25, isSelect: false },
    { txt: 50, isSelect: false },
    { txt: 75, isSelect: false },
    { txt: 100, isSelect: false },
  ];
  marketDataGlobal = null;
  static getInstance() {
    if (Singleton.myInstance == null) {
      Singleton.myInstance = new Singleton();
    }
    return this.myInstance;
  }

  async saveToken(token) {
    Singleton.getInstance().accessToken = token;
    await this.saveDataSecure(constants.ACCESS_TOKEN, token);
  }
  async SaveHideZeroBalance(status) {
    Singleton.getInstance().hideZeroBalance = status;
    await this.saveData(constants.HIDE_ZERO_BALANCE, "0");
  }

  async saveToFav(item) {
    return new Promise((resolve, reject) => {
      this.getData("favArr").then((res) => {
        if (res == null || res == "[]") {
          let arry = [item];
          this.saveData("favArr", JSON.stringify(arry)).then((res) => {
            return resolve();
          });
        } else {
          let arr = JSON.parse(res);
          let added = false;

          for (let i = 0; i < arr.length; i++) {
            if (
              arr[i].base_unit == item.base_unit &&
              arr[i].quote_unit == item.quote_unit
            ) {
              arr.splice(i, 1);
              added = true;
            }
          }
          if (added == false) {
            arr.push(item);
          }

          this.saveData("favArr", JSON.stringify(arr)).then((res) => {
            return resolve();
          });
        }
      });
    });
  }
  clearStorage() {
    return new Promise((resolve, reject) => {
      AsyncStorage.clear()
        .then(async (response) => {
          try {
            await EncryptedStorage.clear();
            resolve(response);
            // Congrats! You've just cleared the device storage!
          } catch (error) {
            reject(error);
            // There was an error on the native side
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  async saveKycId(id) {
    Singleton.getInstance().kycId = id;
    await this.saveData(constants.KYC_ID, id);
  }

  async saveEmptyDefault() {
    Singleton.getInstance().kycId = "";
    await this.saveData(constants.KYC_ID, "");
    Singleton.getInstance().accessToken = "";
    await this.saveDataSecure(constants.ACCESS_TOKEN, "");
    await this.saveDataSecure(constants.REFRESH_TOKEN, "");
    await this.saveData(constants.IS_LOGIN, "false");
  }
  exponentialToDecimalConvert(exponential) {
    let decimal = exponential.toString().toLowerCase();
    if (decimal.includes("e+")) {
      const exponentialSplitted = decimal.split("e+");
      let postfix = "";
      for (
        let i = 0;
        i <
        +exponentialSplitted[1] -
          (exponentialSplitted[0].includes(".")
            ? exponentialSplitted[0].split(".")[1].length
            : 0);
        i++
      ) {
        postfix += "0";
      }
      const addCommas = (text) => {
        let j = 3;
        let textLength = text.length;
        while (j < textLength) {
          text = `${text.slice(0, textLength - j)}${text.slice(
            textLength - j,
            textLength
          )}`;
          textLength++;
          j += 3 + 1;
        }
        return text;
      };
      decimal = addCommas(exponentialSplitted[0].replace(".", "") + postfix);
    }
    if (decimal.toLowerCase().includes("e-")) {
      const exponentialSplitted = decimal.split("e-");
      let prefix = "0.";
      for (let i = 0; i < +exponentialSplitted[1] - 1; i++) {
        prefix += "0";
      }
      decimal = prefix + exponentialSplitted[0].replace(".", "");
    }
    return decimal.toString();
  }
  deleteOfflineStepsData() {
    return new Promise((resolve, reject) => {
      this.saveData(constants.VERIFY_INFO_STEP, "").then((r) => {
        this.saveData(constants.PHONE_VERIFY_STEP, "").then((r) => {
          this.saveData(constants.SELECT_DOC_STEP, "").then((r) => {
            this.saveData(constants.DOC_DETAILS_STEP, "").then((r) => {
              this.saveData(constants.SELFIE_STEP, "").then((r) => {
                this.saveData(constants.FILE_DOC_STEP, "").then((r) => {
                  AsyncStorage.removeItem(constants.USER_DATA).then((r) => {
                    resolve(true);
                  });
                });
              });
            });
          });
        });
      });
    });
  }
  ParseFloatNumber(str, val) {
    // console.log('str typeof--', typeof str);
    // if (str.toString()?.includes('.')) {
    //   console.log('chcek string=-=-=', str);
    // } else {
    //   console.log('chcek string=-=-=else', str);
    // }
    // console.log('check str---', str, val);
    str = str?.toString();
    str = str?.slice(0, str?.indexOf(".") + val + 1);
    let a = str?.split(".");

    if (a[1] == undefined) {
      a = a[0];
      return a;
    } else {
      a = a[0] + "." + a[1].toString().padEnd(val, 0);
      return a;
    }
  }
  ParseFloatNumberOnly(str, val) {
    var re = new RegExp("^-?\\d+(?:.\\d{0," + (val || -1) + "})?");
    return str?.toString().match(re)[0];
  }
  numbersToBillion(labelValue) {
    return Math.abs(Number(labelValue)) >= 1.0e9
      ? (Math.abs(Number(labelValue)) / 1.0e9).toFixed(2) + "B"
      : // Six Zeroes for Millions
      Math.abs(Number(labelValue)) >= 1.0e6
      ? (Math.abs(Number(labelValue)) / 1.0e6).toFixed(2) + "M"
      : // Three Zeroes for Thousands
      Math.abs(Number(labelValue)) >= 1.0e3
      ? (Math.abs(Number(labelValue)) / 1.0e3).toFixed(2) + "K"
      : Math.abs(Number(labelValue));
  }
  isNewerVersion(oldVer, newVer) {
    const oldParts = oldVer.split(".");
    const newParts = newVer.split(".");
    for (var i = 0; i < newParts.length; i++) {
      const a = ~~newParts[i]; // parse int
      const b = ~~oldParts[i]; // parse int
      if (a > b) return true;
      if (a < b) return false;
    }
    return false;
  }
  saveData(key, value) {
    return new Promise(async (resolve, reject) => {
      // if (!value || value == '[]') value = value;
      // else value = encryptData(value);
      // console.log('saveData #### ------' + value);
      AsyncStorage.setItem(key, value)
        .then((response) => {
          resolve(value);
        })
        .catch((error) => {
          // console.log('error #### ' + key);
          reject(error);
        });
      // try {
      //   await EncryptedStorage.setItem(key, value);
      //   console.log("saveData response#### -value-----" + value);
      //   resolve(value);
      //   // Congrats! You've just stored your first value!
      // } catch (error) {
      //   reject(error);
      //   // There was an error on the native side
      // }
    });
  }
  saveDataSecure(key, value) {
    return new Promise(async (resolve, reject) => {
      // if (!value || value == '[]') value = value;
      // else value = encryptData(value);
      // console.log('saveData #### ------' + value);
      // AsyncStorage.setItem(key, value)
      //   .then((response) => {
      //     resolve(value);
      //   })
      //   .catch((error) => {
      //     // console.log('error #### ' + key);
      //     reject(error);
      //   });
      try {
        await EncryptedStorage.setItem(key, value);
        console.log("saveData response#### -value-----" + value);
        resolve(value);
        // Congrats! You've just stored your first value!
      } catch (error) {
        reject(error);
        // There was an error on the native side
      }
    });
  }

  getMarketData() {
    return new Promise((resolve, reject) => {
      fetch(`${END_POINT.COMMON_URL}/api/v2/peatio/public/markets`)
        .then((response) => response.json())
        .then((json) => {
          return resolve(json);
        })
        .catch((error) => {
          return reject(error);
        });
    });
  }
  getData(key) {
    return new Promise(async (resolve, reject) => {
      AsyncStorage.getItem(key)
        .then((response) => {
          // if (!response || response == '[]') return resolve(response);
          // response = DecryptDataSingle(response);
          // console.log('saveData response#### ------' + response);
          resolve(response);
        })
        .catch((error) => {
          reject(error);
        });
      // try {
      //   const keyValue = await EncryptedStorage.getItem(key);

      //   if (keyValue !== undefined) {
      //     console.log("getData response#### -keyValue-----" + keyValue);
      //     resolve(keyValue);
      //     // Congrats! You've just retrieved your first value!
      //   }
      // } catch (error) {
      //   reject(error);
      //   // There was an error on the native side
      // }
    });
  }
  getDataSecure(key) {
    return new Promise(async (resolve, reject) => {
      // AsyncStorage.getItem(key)
      //   .then((response) => {
      //     // if (!response || response == '[]') return resolve(response);
      //     // response = DecryptDataSingle(response);
      //     // console.log('saveData response#### ------' + response);
      //     resolve(response);
      //   })
      //   .catch((error) => {
      //     reject(error);
      //   });
      try {
        const keyValue = await EncryptedStorage.getItem(key);

        if (keyValue !== undefined) {
          console.log("getData response#### -keyValue-----" + keyValue);
          resolve(keyValue);
          // Congrats! You've just retrieved your first value!
        }
      } catch (error) {
        reject(error);
        // There was an error on the native side
      }
    });
  }
  funComma(num) {
    var str = num.split(".");
    if (str[0].length >= 4) {
      str[0] = str[0].replace(/(\d)(?=(\d{3})+$)/g, "$1,");
    }

    return str.join(".");
  }

  refreshToken(type) {
    return new Promise((resolve, reject) => {
      global.loaderVisible = true;
      if (this.refreshingToken) {
        resolve();
        return;
      } else {
        this.refreshingToken = true;
        this.getDataSecure(constants.REFRESH_TOKEN).then((res) => {
          reject("ERROR");

          if (type == 0) {
            fetch(`${END_POINT.BASE_URL}${END_POINT.REFRESH_SESSION}`, {
              method: "POST",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                "Refresh-Token": "Bearer " + res,
              },
            })
              .then(async (res) => {
                if (res?.ok) {
                  var data = res?.headers.map;
                  let access = "Bearer " + data["access-token"];
                  if (!access) {
                    reject("error");
                    return;
                  }
                  console.log("access=-=bearer savedata=-=-=>>>", access);
                  this.saveToken(access);
                  this.accessToken = access;
                  CoinCultApi.get(END_POINT.GET_USER_ME, {
                    headers: {
                      contentType: "application/json",
                      Authorization: access,
                    },
                  })
                    .then((userData) => {
                      resolve(userData);
                      type === 1 && Actions.reset("Main");
                      global.loaderVisible = false;
                      this.refreshingToken = false;
                    })
                    .catch((error) => {
                      reject(error);
                      // type === 1 && this.refreshToken(1);
                      global.loaderVisible = false;
                      this.refreshingToken = false;
                    });
                } else {
                  reject("ERROR");
                }
              })
              .catch((error) => {
                this.refreshingToken = false;
                // AsyncStorage.clear(res => {

                if (error?.response?.status == "401") {
                  Actions.currentScene != "Login" && Actions.reset("Login");
                  Alert.alert(constants.APP_NAME, "Session expired");
                  Singleton.getInstance().saveEmptyDefault();
                  reject(error);
                }
                //   this.accessToken = '';
                //   Actions.reset('Login');
                // });
                // saveEmptyDefault
              });
          }
        });
      }
    });
  }

  async checkSessionTimeout() {
    let sessionOutTime = await this.getData(constants.EXPIRE_TIME);
    sessionOutTime = 1 * sessionOutTime;
    let currentTime = new Date().getTime();
    let diff = sessionOutTime - currentTime;
    if (diff <= 600000 && global.fetchRefreshToken == "yes") {
      global.fetchRefreshToken = "no";
      let refreshToken = await this.getDataSecure(constants.REFRESH_TOKEN);
      let res = await fetch(
        `${END_POINT.BASE_URL}${END_POINT.REFRESH_SESSION}`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            "refresh-token": refreshToken,
          },
          // body: JSON.stringify(data),
        }
      );
      if (!res?.ok) {
        this.saveEmptyDefault();
        this.deleteOfflineStepsData().then((res) => {
          Actions.currentScene != "Login" && Actions.reset("Login");
        });
        return false;
      } else {
        var data = res?.headers.map;

        let expTime = data["access-expire"];

        let b = expTime.split(" ");
        expTime = b[0] + "T" + b[1];
        let checExpTime = new Date(expTime).getTime();

        this.saveData(constants.EXPIRE_TIME, `${checExpTime}`);

        this.accessToken = "Bearer " + data["access-token"];
        this.saveDataSecure(constants.ACCESS_TOKEN, this.accessToken);

        this.saveDataSecure(
          constants.REFRESH_TOKEN,
          `${data["refresh-token"]}`
        );

        setTimeout(() => {
          global.fetchRefreshToken = "yes";
        }, 10000);

        return true;
      }
    } else {
      return true;
    }
  }

  showError(errMsg) {
    showMessage({
      message: errMsg,
      backgroundColor: colors.appRed,
      autoHide: true,
      duration: 3000,
      type: "danger",
      onPress: () => {},
    });
  }
  showMsg(msg) {
    showMessage({
      message: msg,
      backgroundColor: colors.appGreen,
      autoHide: true,
      duration: 3000,
      type: "success",
      onPress: () => {},
    });
  }
  showWarn(msg) {
    showMessage({
      message: msg,
      backgroundColor: colors.warnClr,
      autoHide: true,
      duration: 3000,
      type: "danger",
      onPress: () => {},
    });
  }
  validateTexts(arrOfTexts, arrOfPlaceholders) {
    return new Promise((resolve, reject) => {
      for (let i = 0; i < arrOfTexts.length; i++) {
        if (arrOfTexts[i].length == 0) {
          return reject("Please enter " + arrOfPlaceholders[i]);
        }
        if (i == arrOfTexts.length - 1) {
          return resolve("Validations passed");
        }
      }
    });
  }
}
