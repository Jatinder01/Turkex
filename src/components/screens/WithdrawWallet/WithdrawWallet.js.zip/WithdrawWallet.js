/* eslint-disable react/self-closing-comp */
/* eslint-disable react-native/no-inline-styles */
import React, { Component, PureComponent } from "react";
import { connect } from "react-redux";
import { Actions } from "react-native-router-flux";
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableWithoutFeedback,
  Dimensions,
  ScrollView,
  FlatList,
  Modal,
  TouchableOpacity,
  Alert,
  StatusBar,
  Platform,
} from "react-native";

import {
  CurrencyType,
  ButtonSelectCurrency,
  Button,
  InputDark,
  Spinner,
  InputVerification,
  DropDownButton,
  Wrap,
  ButtonPrimary,
  Loader,
} from "../../common";

import {
  getCurrencyDetails,
  getBalanceDetails,
  withdrawFormUpdate,
  resetWithdrawalForm,
  getAllBenificiary,
  getFundsLimit,
  getProfile1,
} from "../../../Redux/Actions";

import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scrollview";
import Singleton from "../../../Singleton.js";

import * as constants from "../../../Constants";

import { Fonts, Images } from "../../../theme";
import { ThemeManager } from "../../../../ThemeManager";
import SimpleHeader from "../../common/SimpleHeader";
import { strings } from "../../../../Localization";
import WalletHeader from "../../common/WalletHeader";
import styles from "./WithdrawWalletStyle";
import { OptionsModal } from "../../common/OptionsModal";

const { height } = Dimensions.get("window");
const satoshiDivider = 100000000;
let nameJoin = [];
let combineValue;
class WithdrawWallet extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      loading: true,
      selectedCoin: this.props?.coin,
      isBackspace: false,
      userData: null,
      modalNetworkVisible: false,
      networkList: this.props?.coin?.networks,
      initialNetwork: this.props?.coin?.networks[0]?.blockchain_key,
      networkMessageModal: false,
      selectedNetwork: this.props?.coin?.networks[0],
      tierStatus: "",
      usdRate: "",
      calculatedWithdraw: "0",
      showTwoFaButton: false,
    };
  }

  componentDidMount() {
    let coinName = this.props?.coin?.id;

    var currentRoute = this.props?.navigation?.state?.routeName;
    this.props.navigation.addListener("didFocus", (event) => {
      if (currentRoute === event?.state?.routeName) {
        this.setState({
          usdRate: this.props?.coin?.price,
        });

        this.getCurrBalanceDetails(coinName);
        this.getUserData();
        this.props.getFundsLimit();
        this.props.getProfile1();
        this.checkUserVerificationStatus();
      }
    });
  }
  componentWillUnmount() {
    this.props.resetWithdrawalForm();
  }
  getUserData() {
    Singleton.getInstance()
      .getData(constants.USER_DATA)
      .then((res) => {
        this.setState({ userData: JSON.parse(res) });
      })
      .catch((err) => {});

    this.props.getAllBenificiary();
  }

  setModalVisible(visible) {
    this.setState({ modalVisible: visible });
  }

  getCurrBalanceDetails(coinName) {
    this.props.getBalanceDetails({ coinName });
  }

  submitButtonClicked() {
    Singleton.getInstance()
      .getData(constants.USER_DATA)
      .then((res) => {
        let totalBalance = this.props?.balanceDetails?.balance;

        if (this.props?.amount?.length <= 0) {
          Singleton.getInstance().showError("Enter withdrawal amount");
        } else if (
          this.props.amount < this.state.selectedCoin.min_withdraw_amount
        ) {
          Singleton.getInstance().showError(
            "Minimum withdrawal amount is " +
              this.state.selectedCoin?.min_withdraw_amount
          );
        } else if (
          this.props.amount >
          parseFloat(this.state.selectedNetwork.withdraw_fee) +
            parseFloat(totalBalance)
        ) {
          Singleton.getInstance().showError("Insufficient balance");
        } else if (this.props.amount > totalBalance) {
          Singleton.getInstance().showError("Insufficient balance");
        } else if (
          parseFloat(this.state.selectedNetwork.withdraw_fee) >=
          this.props.amount
        ) {
          Singleton.getInstance().showError(
            "Withdrawal amount should be greater than transaction fee."
          );
        } else if (
          this.props.amount >
          parseFloat(this.state.selectedNetwork.withdraw_fee) +
            parseFloat(this.state.selectedCoin.withdraw_limit_24h)
        ) {
          Singleton.getInstance().showError(
            "You can maximum withdraw upto " +
              this.state.selectedCoin.withdraw_limit_24h +
              " " +
              this.state.selectedCoin.id.toUpperCase()
          );
        } else if (this.props.withdrawAddress.length < 10) {
          Singleton.getInstance().showError("Select a valid receiving address");
        } else {
          Actions.currentScene != "WithdrawConfirmation" &&
            Actions.WithdrawConfirmation({
              deposit: false,
              address: this.props?.withdrawAddress,
              amt: this.props?.amount,
              transFee: this.state.selectedNetwork.withdraw_fee,
              coinType: this.state.selectedCoin,
              networkType: this.state.initialNetwork,
            });
        }
      })
      .catch((err) => {});
  }

  renderBalance() {
    if (this.props?.balanceDetails != null) {
      let totalBalance = this.props?.balanceDetails?.balance;
      return (
        <Text style={styles.helpText}>
          Available balance: <Text>{totalBalance}</Text>
          {" " + this.state.selectedCoin.id.toUpperCase()}
        </Text>
      );
    }
  }
  renderError() {
    if (this.props?.currencyError) {
      return (
        <View>
          <Text style={styles.errorMessageStyle}>
            {this.props?.currencyError}
          </Text>
        </View>
      );
    }
  }

  checkUserVerificationStatus = () => {
    return new Promise(async (resolve, rej) => {
      let tierStatusValue = "";
      var res = await Singleton.getInstance().getData(constants.USER_DATA);
      let parsedRes = JSON.parse(res);
      if (parsedRes?.otp === false) {
        // Alert.alert(constants.APP_NAME, 'Please enable 2FA.');
        this.setState({
          showTwoFaButton: true,
        });
      } else {
        try {
          let confirmations = parsedRes?.labels.find(
            (item) => item.value === "verified" && item.key === "tier_1"
          );
          let confirmations_tier2 = parsedRes?.labels.find(
            (item) => item.value === "verified" && item.key === "tier_2"
          );
          let confirmations_tier3 = parsedRes?.labels.find(
            (item) => item.value === "verified" && item.key === "tier_3"
          );
          let confirmations_tier4 = parsedRes?.labels.find(
            (item) => item.value === "verified" && item.key === "tier_4"
          );
          if (confirmations === undefined) {
            Alert.alert(constants.APP_NAME, "KYC is not verified.");
            tierStatusValue = "unverified";
          } else if (confirmations?.value === "verified") {
            tierStatusValue = "tier_1";
            this.setState({
              tierStatus: tierStatusValue,
            });
            // setCheckVerification(true);
            if (confirmations_tier2?.value === "verified") {
              tierStatusValue = "tier_2";
              this.setState({
                tierStatus: tierStatusValue,
              });
            }
            if (confirmations_tier3?.value === "verified") {
              tierStatusValue = "tier_3";
              this.setState({
                tierStatus: tierStatusValue,
              });
            }
            if (confirmations_tier4?.value === "verified") {
              tierStatusValue = "tier_3";
              this.setState({
                tierStatus: tierStatusValue,
              });
            }
          } else {
            Alert.alert(constants.APP_NAME, "KYC is not verified.");
          }
        } catch (err) {}
      }
      return resolve(this.state.tierStatus);
    });
  };
  handleKeyPress({ nativeEvent: { key: keyValue } }) {
    if (keyValue === "Backspace") {
      this.setState({ isBackspace: true });
    } else {
      this.setState({ isBackspace: false });
    }
  }
  getUsdPrice = (name) => {
    // let data = activeCoin?.activeCoinInfo?.find(value => value.id == name);
    // return data;
  };
  renderSpinner() {
    if (this.props.currencyDetailsLoading) {
      return (
        <View style={{ height: 40 }}>
          <Spinner />
        </View>
      );
    } else {
      let addArray = [];
      let addId = [];
      // debugger;
      nameJoin = [];
      for (let i = 0; i < this.props.allBenificiaries.length; i++) {
        if (
          this.props?.allBenificiaries[i]?.currency ==
          this.state.selectedCoin.id
        ) {
          if (
            this.props?.allBenificiaries[i]?.state != "pending" &&
            this.props?.allBenificiaries[i]?.blockchain_key ===
              this.state.initialNetwork
          ) {
            addArray.push({
              value: this.props?.allBenificiaries[i]?.data?.address,
            });
            addId.push({ value: this.props?.allBenificiaries[i]?.id });

            combineValue =
              this.props?.allBenificiaries[i]?.name +
              "(" +
              this.props?.allBenificiaries[i]?.blockchain_name
                .replace(" Testnet", "")
                .replace(" testnet", "")
                .replace(" Mainnet", "")
                .replace(" mainnet", "") +
              "):" +
              this.props?.allBenificiaries[i]?.data.address;
            nameJoin.push({
              label: combineValue,
              address: this.props?.allBenificiaries[i]?.data.address,
              name: this.props?.allBenificiaries[i]?.name,
              id: this.props?.allBenificiaries[i]?.id,
              coinType: this.props?.allBenificiaries[i]?.blockchain_name,
            });
          }
        }
      }

      return (
        <>
          <ButtonSelectCurrency
            styleDropDown={{
              backgroundColor: ThemeManager.colors.tabBackground,
            }}
            coinIcon={this.state.selectedCoin?.icon_url}
            coinName={this.state.selectedCoin?.name.toUpperCase()}
            coinSymbol={this.state.selectedCoin?.id.toUpperCase()}
            btnSelectCurrency={() => this.setModalVisible(true)}
          />
          <View
            style={{
              justifyContent: "flex-start",
              alignItems: "center",
              flexDirection: "row",
              marginTop: 20,
              marginBottom: 5,
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontFamily: Fonts.regular,
                color: ThemeManager.colors.inactiveTextColor,
              }}
            >
              {strings.spot.network}
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => {
              this.setState({
                modalNetworkVisible: true,
              });
            }}
            style={{
              height: 50,
              marginTop: 5,
              backgroundColor: ThemeManager.colors.inputBackground,
              justifyContent: "space-between",
              alignItems: "center",
              flexDirection: "row",
              borderRadius: 4,
            }}
          >
            <Text
              style={{
                color: ThemeManager.colors.placeholderTextColor,
                fontFamily: Fonts.regular,
                fontSize: 14,
                marginHorizontal: 10,
              }}
            >
              {this.state.initialNetwork.toUpperCase()}
            </Text>

            <Image
              source={{ uri: Images.icon_right_arrow }}
              style={{
                height: 20,
                width: 20,
                resizeMode: "contain",
                marginRight: 10,
              }}
            />
          </TouchableOpacity>
          <View style={{ marginTop: 20 }}>
            <Text
              style={{
                color: ThemeManager.colors.textColor5,
                marginBottom: 20,
              }}
            >
              Receiving Address
            </Text>
            {nameJoin.length > 0 ? (
              <TouchableOpacity
                style={{
                  justifyContent: "space-between",
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 15,
                  // marginTop: 5,
                  flex: 1,
                  height: 50,
                  backgroundColor: ThemeManager.colors.tabBackground,
                  borderRadius: 6,
                }}
                onPress={() => {
                  this.setState({
                    isVisible: true,
                  });
                }}
              >
                <Text
                  style={{
                    color: ThemeManager.colors.textColor1,
                    marginRight: 5,
                    flex: 0.9,
                    marginLeft: 10,
                    fontFamily: Fonts.regular,
                  }}
                >
                  {this.state.selectedAddress || "Please enter address"}
                </Text>
                <Image
                  // source={Images.icon_down}
                  source={{ uri: ThemeManager.ImageIcons.icon_dropdown }}
                  style={{
                    height: 20,
                    width: 20,
                    marginRight: 10,
                    resizeMode: "contain",
                    tintColor: ThemeManager.colors.textColor1,
                  }}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={{
                  justifyContent: "space-between",
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 15,
                  // marginTop: 5,
                  flex: 1,
                  height: 50,
                  backgroundColor: ThemeManager.colors.tabBackground,
                  borderRadius: 6,
                }}
                onPress={() => {
                  this.props.navigation.navigate("AddWithdrawAddress", {
                    selectedCoin: this.state.selectedCoin,
                    selectedBlockchainKey: this.state.initialNetwork,
                  });
                }}
              >
                <Text
                  style={{
                    color: this.state.selectedAddress
                      ? ThemeManager.colors.textColor1
                      : ThemeManager.colors.inactiveTextColor,
                    marginRight: 5,
                    flex: 0.9,
                    marginLeft: 10,
                    fontFamily: Fonts.regular,
                  }}
                >
                  {this.state.selectedAddress || "Please enter address"}
                </Text>
                <Image
                  // source={Images.icon_down}
                  source={{ uri: ThemeManager.ImageIcons.icon_dropdown }}
                  style={{
                    height: 20,
                    width: 20,
                    marginRight: 10,
                    resizeMode: "contain",
                    tintColor: ThemeManager.colors.textColor1,
                  }}
                />
              </TouchableOpacity>
            )}

            <OptionsModal
              listItemKeyName={"label"}
              dataList={nameJoin}
              modalVisible={this.state.isVisible}
              backgroundColor={ThemeManager.colors.SwapInput}
              textStyle={{ color: ThemeManager.colors.textColor1 }}
              onItemSelect={(item, index) => {
                this.setState({
                  onItemSelect: item.name,
                  selectedAddress: item.address,
                });
                this.props.withdrawFormUpdate({
                  prop: "withdrawAddress",
                  value: item.address,
                });
                this.props.withdrawFormUpdate({
                  prop: "withBeniId",
                  value: item.id,
                });
              }}
              onRequestClose={() => {
                this.setState({
                  isVisible: false,
                });
              }}
            />

            <TouchableOpacity
              style={{
                justifyContent: "center",
                alignSelf: "flex-end",
                position: "absolute",
                right: 0,
                top: 0,
              }}
              onPress={(res) =>
                this.props.navigation.navigate("AddWithdrawAddress", {
                  selectedCoin: this.state.selectedCoin,
                  selectedBlockchainKey: this.state.initialNetwork,
                })
              }
            >
              <Text
                style={[
                  styles.titleDepositLimt,
                  {
                    color: ThemeManager.colors.textRedColor,
                    fontFamily: Fonts.medium,
                    fontSize: 14,
                    textDecorationLine: "none",
                    fontWeight: "500",
                  },
                ]}
              >
                {strings.withdraw_screen.manage_address}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={{ marginTop: 10 }}>
            <InputVerification
              verifyLable={{
                fontSize: 14,
                fontFamily: Fonts.regular,
                color: ThemeManager.colors.textColor5,
              }}
              inputLabel={strings.withdraw_screen.amount}
              // onKeyPress={this.handleKeyPress.bind(this)}
              verifyInputStyle={{
                // paddingTop: 5,
                color: ThemeManager.colors.textColor1,
              }}
              placeHolder={
                this.state.selectedNetwork != null
                  ? "Min. withdrawal " +
                    this.state.selectedNetwork.min_withdraw_amount +
                    " " +
                    this.state.selectedCoin.id.toUpperCase()
                  : "Min. withdrawal "
              }
              value={this.props.amount}
              keyboardStyle={"numeric"}
              hideCounterBtns={{ top: 42 }}
              hideScan={{ display: "none" }}
              showButton={false}
              maxLength={15}
              maxTxt="MAX"
              maxOnPress={() => Alert.alert(constants.APP_NAME, "maxx")}
              onChangeText={(text) => {
                let overAllLimit = parseFloat(
                  this.props.fundsLimitInfo?.limits?.over_all_limit_in_usd
                );

                let totalTransaction = parseFloat(
                  this.props.fundsLimitInfo?.transactions?.total
                );
                let yearTransaction = parseFloat(
                  this.props.fundsLimitInfo?.transactions?.year
                );
                let dailyLimitUSD = parseFloat(
                  this.props.fundsLimitInfo?.limits?.daily_limit_in_usd
                );
                const countTransaction =
                  this.props.fundsLimitInfo?.transactions?.count;

                let dayTransaction = parseFloat(
                  this.props.fundsLimitInfo?.transactions?.h24
                );

                let val = parseFloat(this.state.usdRate) * parseFloat(text);

                this.setState({
                  calculatedWithdraw: val,
                });

                if (/^\d*\.?\d*$/.test(text)) {
                  var value = text;
                  if (value == ".") {
                    value = "0.";
                  }
                  if (this.state.tierStatus == "tier_1") {
                    // alert('tier1');
                    let totalAmount =
                      parseFloat(val) + parseFloat(totalTransaction);
                    if (
                      1 * totalAmount > 1 * overAllLimit ||
                      countTransaction > 2
                    ) {
                      this.setState({
                        calculatedWithdraw: "0",
                      });
                      Singleton.getInstance().showError(
                        "Limit exceeded. Upgrade to KYC tier 2."
                      );
                    } else {
                      this.props.withdrawFormUpdate({ prop: "amount", value });
                    }
                  } else if (this.state.tierStatus == "tier_2") {
                    let totalAmount =
                      parseFloat(val) + parseFloat(yearTransaction);
                    if (1 * totalAmount > 1 * overAllLimit) {
                      this.setState({
                        calculatedWithdraw: "0",
                      });
                      Singleton.getInstance().showError(
                        "Limit exceeded. Upgrade to KYC tier 3."
                      );
                    } else {
                      this.props.withdrawFormUpdate({ prop: "amount", value });
                    }
                  } else if (this.state.tierStatus == "tier_3") {
                    let totalAmount =
                      parseFloat(val) + parseFloat(yearTransaction);

                    let dailyLimit =
                      parseFloat(val) + parseFloat(dayTransaction);

                    if (1 * dailyLimit > 1 * dailyLimitUSD) {
                      this.setState({
                        calculatedWithdraw: "0",
                      });
                      Singleton.getInstance().showError(
                        "Daily limit exceeded."
                      );
                    } else {
                      if (1 * totalAmount > 1 * overAllLimit) {
                        Singleton.getInstance().showError("Limit exceeded.");
                      } else {
                        // setWithdrawAmount(text);
                        this.props.withdrawFormUpdate({
                          prop: "amount",
                          value,
                        });
                      }
                    }
                  }
                }
              }}
            />
            <View style={{ alignItems: "flex-end" }}>
              <Text
                style={{
                  color: ThemeManager.colors.textColor5,
                  fontSize: 10,
                  fontFamily: Fonts.regular,
                  marginVertical: 5,
                  // textAlign: 'right',
                }}
              >
                {strings.trade_tab.equals}
                {": $"}
                {this.state.calculatedWithdraw
                  ? parseFloat(this.state.calculatedWithdraw).toFixed(2)
                  : 0}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                // marginTop: -20,
              }}
            >
              <Text
                style={[
                  styles.helpText,
                  { color: ThemeManager.colors.textColor5 },
                ]}
              >
                {this.state.selectedNetwork != null
                  ? "Transaction fee: " +
                    this.state.selectedNetwork.withdraw_fee
                  : "Transaction fee: 0.00"}
              </Text>
              {/* <Text style={styles.helpText}>
                {this.state.selectedCoin != null
                  ? 'Min:' +
                    this.state.selectedCoin.min_withdraw_amount +
                    ' ' +
                    this.state.selectedCoin.id.toUpperCase()
                  : 'Min'}
              </Text> */}
            </View>
            {/* {this.renderBalance()} */}
          </View>
        </>
      );
    }
  }

  renderFlatList() {
    if (this.props.coinList != null) {
      return (
        <FlatList
          data={this.props.coinList}
          renderItem={(item) => {
            return (
              <CurrencyType
                coinIcon={item.item.icon_url}
                CoinFullName={item.item.name}
                CoinShortName={item.item.id}
                BoldTitleStyle={{
                  color: ThemeManager.colors.cryptoAmountTextColor,
                }}
                buttonClicked={() => {
                  let value = item.item;

                  this.setState({ selectedCoin: value });
                  // this.props.setSelectedCoin({ prop: 'selectedCoin', value })
                  // this.props.getCoinAddressDetails({ value })
                  let coinName = value.id;
                  this.props.resetWithdrawalForm();
                  // this.props.getCurrencyDetails({ coinName })
                  // this.props.getBalanceDetails({ coinName })
                  this.getCurrBalanceDetails(coinName);
                  this.setModalVisible(false);
                }}
              />
            );
          }}
          keyExtractor={(item, index) => index.toString()}
        />
      );
    }
  }

  renderCoinAddress() {
    if (this.props.coinAddressLoading) {
      return (
        <View style={{ height: 40 }}>
          <Spinner />
        </View>
      );
    } else {
      return (
        <InputDark
          labelText={
            this.state.selectedCoin.id.toUpperCase() + " deposit address"
          }
          value={
            this.props.coinAddressInfo != null
              ? this.props.coinAddressInfo.address
              : ""
          }
          customLableStyle={styles.labelStyle}
          darkCustomStyle={styles.inputStyle}
          placeholderCustomStyle={ThemeManager.colors.selectedTextColor}
        />
      );
    }
  }

  render() {
    let balance = 0.0;
    let totalBalance = 0.0;
    let lockedBalance = 0.0;
    if (this.props?.balanceDetails != null) {
      balance = this.props.balanceDetails;
      totalBalance = this.props?.balanceDetails?.balance;
      lockedBalance = this.props?.balanceDetails?.locked;
    }
    console.log(
      "this.props.currencyDetailsLoading-=-=>>",
      this.props.currencyDetailsLoading
    );

    return (
      <>
        <Wrap
          style={{ backgroundColor: ThemeManager.colors.dashboardSubViewBg }}
          screenStyle={[
            styles.screenStyle,
            { backgroundColor: ThemeManager.colors.dashboardSubViewBg },
          ]}
          bottomStyle={{
            backgroundColor: ThemeManager.colors.dashboardSubViewBg,
          }}
        >
          <WalletHeader
            onBackPress={() => Actions.pop()}
            onHistoryPress={() => {
              Actions.currentScene != "HistoryWallet" &&
                Actions.push("HistoryWallet");
            }}
          />
          <Text
            style={{
              fontSize: 26,
              fontFamily: Fonts.medium,
              color: ThemeManager.colors.textColor,
              marginTop: 10,
              marginLeft: 15,
            }}
          >
            {strings.spot.withdraw} {this.state.selectedCoin.id.toUpperCase()}
          </Text>
          {this.props?.balanceDetails == null && <Loader isLoading={true} />}
          <Loader isLoading={this.props.currencyDetailsLoading} />
          {this.props.currencyDetailsLoading === false && (
            <KeyboardAwareScrollView
              bounces={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={{ paddingVertical: 5 }} />
              <View style={[styles.middleBlock, { paddingVertical: 10 }]}>
                <>
                  <View
                    style={{
                      backgroundColor: ThemeManager.colors.tabBackground,
                      padding: 15,
                      borderRadius: 6,
                    }}
                  >
                    <View style={styles.availStatusView}>
                      <Text style={styles.titleAvailStatus}>
                        {strings.withdraw_screen.available_balance}
                      </Text>
                      <Text
                        style={[
                          styles.titleAvailStatus,
                          {
                            textAlign: "right",
                            color: ThemeManager.colors.anouncementtextColour,
                          },
                        ]}
                      >
                        {this.props?.balanceDetails != null &&
                          balance?.balance +
                            " " +
                            balance?.currency?.toUpperCase()}
                      </Text>
                    </View>

                    <View style={styles.availStatusView}>
                      <Text style={styles.titleAvailStatus}>
                        {strings.withdraw_screen.in_order}
                      </Text>
                      <Text
                        style={[
                          styles.titleAvailStatus,
                          {
                            textAlign: "right",
                            color: ThemeManager.colors.anouncementtextColour,
                          },
                        ]}
                      >
                        {this.props?.balanceDetails != null &&
                          lockedBalance +
                            " " +
                            balance?.currency?.toUpperCase()}
                      </Text>
                    </View>

                    <View style={styles.availStatusView}>
                      <Text style={styles.titleAvailStatus}>
                        {strings.withdraw_screen.total_balance}
                      </Text>
                      <Text
                        style={[
                          styles.titleAvailStatus,
                          {
                            textAlign: "right",
                            color: ThemeManager.colors.anouncementtextColour,
                          },
                        ]}
                      >
                        {this.props?.balanceDetails != null &&
                          parseFloat(totalBalance - lockedBalance).toFixed(8) +
                            " " +
                            balance?.currency?.toUpperCase()}
                      </Text>
                    </View>
                    <View style={styles.availStatusView}>
                      <Text style={styles.titleAvailStatus}>
                        {strings.trade_tab.total_transactions}
                      </Text>
                      <Text
                        style={[
                          styles.titleAvailStatus,
                          {
                            textAlign: "right",
                            color: ThemeManager.colors.anouncementtextColour,
                          },
                        ]}
                      >
                        {"$"}
                        {this.props.fundsLimitInfo != null
                          ? Singleton.getInstance().ParseFloatNumberOnly(
                              this.props.fundsLimitInfo?.transactions?.total,
                              4
                            )
                          : 0}
                      </Text>
                    </View>
                    <View style={styles.availStatusView}>
                      <Text style={styles.titleAvailStatus}>
                        {strings.trade_tab.total_limits}
                      </Text>
                      <Text
                        style={[
                          styles.titleAvailStatus,
                          {
                            textAlign: "right",
                            color: ThemeManager.colors.anouncementtextColour,
                          },
                        ]}
                      >
                        {"$"}
                        {this.props?.fundsLimitInfo != null
                          ? parseFloat(
                              this.props?.fundsLimitInfo?.limits
                                ?.over_all_limit_in_usd
                            )
                          : 0}
                      </Text>
                    </View>
                  </View>
                </>
              </View>
              <View
                style={{
                  backgroundColor: ThemeManager.colors.lightdark,
                  paddingVertical: 5,
                }}
              />

              <View style={styles.middleBlock}>
                {this.renderError()}
                {this.renderSpinner()}
                <View style={styles.helpTextBlock}>
                  <Text
                    style={[
                      styles.helpText,
                      {
                        fontSize: 14,
                        letterSpacing: -0.35,
                        color: ThemeManager.colors.inactiveTextColor,
                      },
                    ]}
                  >
                    {strings.withdraw_screen.with_only +
                      this.state.selectedCoin.id.toUpperCase() +
                      strings.withdraw_screen.address_sending}
                  </Text>
                </View>
                <View style={{ marginTop: 30 }} />
                {this.state.showTwoFaButton ? (
                  <ButtonPrimary
                    style={{ marginTop: 8, borderRadius: 6, marginBottom: 30 }}
                    title={"Enable 2FA"}
                    onPress={() => {
                      global.twoFaFromScreen = "WithdrawWallet";
                      Actions.currentScene != " GoogleAuthenticatorStep01" &&
                        Actions.GoogleAuthenticatorStep01();
                    }}
                  />
                ) : (
                  <ButtonPrimary
                    style={styles.btnBottomActive}
                    title={"Confirm"}
                    onPress={() => {
                      this.submitButtonClicked();
                    }}
                  />
                )}
              </View>

              <Modal
                animationType="slide"
                transparent={true}
                visible={this.state.modalVisible}
              >
                <View style={styles.modelContainer}>
                  <TouchableOpacity
                    style={{ width: "100%", height: "100%" }}
                    onPress={() => this.setModalVisible(false)}
                  />
                  <View
                    style={[
                      styles.modelContainerChild,
                      { backgroundColor: ThemeManager.colors.lightdark },
                    ]}
                  >
                    <View style={styles.slideContainer}>
                      <Text
                        style={[
                          styles.titleCurrency,
                          { color: ThemeManager.colors.cryptoAmountTextColor },
                        ]}
                      >
                        Select Currency
                      </Text>
                      <Text style={styles.subTitleCurrency}>
                        Select the cryptocurrency you want to buy or sell
                      </Text>
                      <View
                        style={{
                          width: "100%",
                          marginBottom: 15,
                          paddingLeft: 25,
                        }}
                      >
                        {this.renderFlatList()}
                      </View>
                    </View>
                  </View>
                </View>
              </Modal>
            </KeyboardAwareScrollView>
          )}
          <Modal
            animationType="fade"
            transparent={true}
            visible={this.state.modalNetworkVisible}
            onRequestClose={() => {
              this.setState({
                modalNetworkVisible: false,
              });
            }}
          >
            <Wrap
              darkMode={
                ThemeManager.colors.themeColor === "light" ? false : true
              }
              style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
              screenStyle={[
                styles.screenStyle,
                { backgroundColor: "transparent" },
              ]}
              bottomStyle={{ backgroundColor: ThemeManager.colors.DashboardBG }}
            >
              <View
                style={{
                  backgroundColor: "rgba(255,255,255,0.1)",
                  flex: 1,
                  justifyContent: "flex-end",
                }}
              >
                <TouchableOpacity
                  style={{ flex: 1 }}
                  onPress={() => {
                    this.setState({
                      modalNetworkVisible: false,
                    });
                  }}
                ></TouchableOpacity>
                <View
                  style={{
                    backgroundColor: ThemeManager.colors.whiteScreen,

                    borderTopRightRadius: 15,
                    borderTopLeftRadius: 15,
                  }}
                >
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                      marginHorizontal: 15,
                      marginVertical: 15,
                    }}
                  >
                    <View style={{ width: 40 }} />
                    <Text
                      style={{
                        fontSize: 16,
                        fontFamily: Fonts.regular,
                        color: ThemeManager.colors.textColor,
                      }}
                    >
                      {strings.spot.choose_network}
                    </Text>
                    <TouchableOpacity
                      onPress={() => {
                        this.setState({
                          modalNetworkVisible: false,
                        });
                      }}
                    >
                      <Image
                        source={{ uri: Images.icon_cancel_light }}
                        style={{
                          height: 20,
                          width: 20,
                          resizeMode: "contain",
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                  <View style={{ marginHorizontal: 10 }}>
                    <Text
                      style={{
                        fontSize: 14,
                        fontFamily: Fonts.regular,
                        color: ThemeManager.colors.inactiveTextColor,
                      }}
                    >
                      {strings.spot.ensure_the_network_withdrawal}
                    </Text>
                    <FlatList
                      data={this.state.networkList}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item, index }) => {
                        return (
                          <TouchableOpacity
                            onPress={() => {
                              this.setState({ selectedNetwork: item });
                              this.setState({
                                initialNetwork: item?.blockchain_key,
                              });
                              this.setState({
                                modalNetworkVisible: false,
                                selectedAddress: "",
                              });
                            }}
                            style={{
                              height: 50,
                              marginTop: 5,
                              backgroundColor:
                                ThemeManager.colors.tabBackground,

                              justifyContent: "center",
                            }}
                          >
                            <Text
                              style={{
                                fontSize: 16,
                                fontFamily: Fonts.regular,
                                color: ThemeManager.colors.textColor1,
                                marginLeft: 10,
                              }}
                            >
                              {item.blockchain_key.toUpperCase()}
                            </Text>
                          </TouchableOpacity>
                        );
                      }}
                      ListFooterComponent={() => {
                        return <View style={{ marginBottom: 20 }} />;
                      }}
                    />
                  </View>
                </View>
              </View>
            </Wrap>
          </Modal>
          <Modal
            animationType="slide"
            transparent={true}
            visible={this.state.networkMessageModal}
          >
            <View style={styles.modelContainer}>
              <TouchableOpacity
                style={{ width: "100%", height: "100%" }}
                onPress={() =>
                  this.setState({
                    networkMessageModal: false,
                  })
                }
              />
              <View
                style={[
                  {
                    backgroundColor: ThemeManager.colors.DashboardBG,
                    marginHorizontal: 20,
                    borderRadius: 10,
                    padding: 14,
                  },
                ]}
              >
                <Text
                  style={{
                    color: ThemeManager.colors.textColor1,
                    fontSize: 24,
                    fontFamily: Fonts.bold,
                    alignSelf: "center",
                  }}
                >
                  Transfer Network
                </Text>
                <Text
                  style={{
                    color: ThemeManager.colors.textColor1,
                    fontSize: 16,
                    fontFamily: Fonts.regular,
                    alignSelf: "center",
                    marginVertical: 10,
                    textAlign: "center",
                  }}
                >
                  Please make sure that the currency is charged and withdrawn on
                  the same network, otherwise the currency withdrawal cannot be
                  successful. The different effects of the network are the rate,
                  the minimum amount of money withdrawn and the transfer time.
                </Text>
                <ButtonPrimary
                  style={{ marginTop: 8, borderRadius: 6 }}
                  title={"I Understand"}
                  onPress={() => {
                    this.setState({
                      networkMessageModal: false,
                    });
                  }}
                />
              </View>
              <TouchableOpacity
                style={{ width: "100%", height: "100%" }}
                onPress={() =>
                  this.setState({
                    networkMessageModal: false,
                  })
                }
              />
            </View>
          </Modal>
        </Wrap>
      </>
    );
  }
}

const mapStateToProps = (state) => {
  const {
    currencyDetails,
    currencyError,
    currencyDetailsLoading,
    balanceDetails,
    withdrawAddress,
    amount,
    withBeniId,
  } = state.withDetails;
  const { fundsLimitInfo } = state.fundsLimitReducer;
  const { allBenificiaries, isLoadingBeni, beniError } =
    state.benificiaryReducer;

  return {
    currencyDetails,
    currencyError,
    currencyDetailsLoading,
    balanceDetails,
    withdrawAddress,
    amount,
    withBeniId,

    allBenificiaries,
    isLoadingBeni,
    beniError,
    fundsLimitInfo,
  };
};
export default connect(mapStateToProps, {
  getCurrencyDetails,
  getBalanceDetails,
  withdrawFormUpdate,
  resetWithdrawalForm,
  getAllBenificiary,
  getFundsLimit,
  getProfile1,
})(WithdrawWallet);
