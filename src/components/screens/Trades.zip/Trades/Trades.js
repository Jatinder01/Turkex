/* eslint-disable no-unused-vars */
/* eslint-disable react/self-closing-comp */
/* eslint-disable react-native/no-inline-styles */
import React, {useRef, useEffect, useState} from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  Image,
  Touchable,
  TextInput,
  ScrollView,
  Modal,
  SafeAreaView,
  Alert,
} from 'react-native';
import styles from './TradesStyle';
import {
  Wrap,
  TabIcon,
  AskBook,
  BidsBook,
  Spinner,
  Loader,
  TradeOpenOrder,
} from '../../common';
import {ThemeManager} from '../../../../ThemeManager';
import PagerView from 'react-native-pager-view';

import TradeHeader from '../../common/TradeHeader';
import {strings} from '../../../../Localization';
import BorderLine from '../../common/BorderLine';
import {Fonts, Images} from '../../../theme';
import SelectDropdown from 'react-native-select-dropdown';
import TradeInput from '../../common/TradeInput';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import {FlatList} from 'react-native-gesture-handler';
import {Actions} from 'react-native-router-flux';
import ActionSheet from 'react-native-actionsheet';
import fonts from '../../../theme/fonts';
import {useDispatch, useSelector} from 'react-redux';
import Singleton from '../../../Singleton';
import {getMultiLingualData} from '../../../../Utils';

import {
  getMarketList,
  getOrderHistory,
  orderHistoryUpdate,
  getBalanceDetails,
  tradeValuesUpdate,
  placeTradeOrder,
  stopPreviousConnection,
  tradeSocketClose,
  callOrderSocket,
  buySellSocket,
  getUserAllBalance,
  getTreadingFeee,
  getPublicTrade,
  callTradeSocket,
  getTreadingRules,
  getDepositCoinListPairs,
  resetDepositList,
  getOpenOrders,
} from '../../../Redux/Actions';

import * as constants from '../../../Constants';
import {event} from 'react-native-reanimated';
import TradingRules from './TradingRule';
import PercentageChange from './PercentageChange';
const pricePrecision = [
  {title: 0.0001, value: 4},
  {title: 0.001, value: 3},
  {title: 0.01, value: 2},
  {title: 0.1, value: 1},
];
const listLimit = [
  {title: strings.trade_tab.limit, value: 0},
  {title: strings.trade_tab.market, value: 1},
];
// let dArray = [];
let coinToDollar = 0;
const Trades = props => {
  const pagerRef = useRef(null);
  const pagerRef2 = useRef(null);

  const dispatch = useDispatch();

  const ActionSheetBuySell = useRef(null);
  const ActionSheetDepositTransfer = useRef(null);
  const [actionSheetBuySell, setActionSheetBuySell] = useState('');

  const [selectedLimitedIndex, setSelectedLimitedIndex] = useState(0);
  const [userPricePrecision, setuserPricePrecision] = useState(2);

  const [spotPageSelected, setSpotPageSelected] = useState(1);
  const [limitValue, setLimitValue] = useState('0');
  const [selectedPercentage, setSelectedPercentage] = useState();
  const [btnOneSelected, setBtnOneSelected] = useState(false);
  const [btnTwoSelected, setBtnTwoSelected] = useState(false);
  const [isShowRules, setShowRules] = useState(false);

  const [btnThreeSelected, setBtnThreeSelected] = useState(false);
  const [btnFourSelected, setBtnFourSelected] = useState(false);
  const [selectedButton, setSelectedButton] = useState('0%');
  //buysell btn
  const [buySellBtnSelect, setBuySellBtnSelect] = useState(false);
  const [sellButtonSelected, setSellButtonSelected] = useState(true);
  const [openOrderPageSelected, setOpenOrderPageSelected] = useState(false);
  const [showConvertModal, setShowConvertModal] = useState(false);
  const [openOrderList, setOpenOrderList] = useState([]);
  const [amount, setAmount] = useState(0);
  const [showBuyOrder, setShowBuyOrder] = useState(true);
  const [showSellOrder, setShowSellOrder] = useState(true);
  const [isArrowClicked, setArrowClicked] = useState(false);
  const [limitSelected, setLimitSelected] = useState(true);
  const [amountSelected, setAmountSelected] = useState(false);
  const [priceChange, setPriceChange] = useState('');
  const [currentSelectedBalance, setCurrentSelectedBalance] = useState(0.0);
  const [fundsArray, setFundsArray] = useState([]);
  //reducers
  const marketSocketReducer = useSelector(state => state?.marketSocketReducer);
  const FundsReducer = useSelector(state => state?.FundsReducer);
  const tradeReducer = useSelector(state => state?.tradeReducer);
  const orderHistoryReducer = useSelector(state => state?.orderHistoryReducer);
  const withDetails = useSelector(state => state.withDetails);
  const depositListReducer = useSelector(state => state.depositListReducer);
  const [pairModelVisible, setPairModelVisible] = useState(false);
  useEffect(() => {
    var currentRoute = props?.navigation?.state?.routeName;
    dispatch(getDepositCoinListPairs('deposit'));
    props.navigation.addListener('didFocus', async event => {
      setShowRules(false);
      dispatch(getDepositCoinListPairs('deposit'));
      // alert('ASdsd');
      setTimeout(async () => {
        await updateSocket(
          tradeReducer?.selectedCoinPair?.base_unit +
            tradeReducer?.selectedCoinPair?.quote_unit,
        );
      }, 100);
      // }
      if (currentRoute === event.state.routeName) {
        console.log('VIEW DID APPEARR');
        resetData1();
        Actions.refresh();
      }
    });
    props.navigation.addListener('didBlur', event => {
      dispatch(
        orderHistoryUpdate({
          prop: 'orderHistory',
          value: [],
        }),
      );
    });

    dispatch(getUserAllBalance()).then(res => {
      openOderDetails(res, true);
    });

    dispatch(
      buySellSocket({
        pair:
          tradeReducer?.selectedCoinPair?.base_unit +
          tradeReducer?.selectedCoinPair?.quote_unit,
      }),
    );

    return () => {
      dispatch(stopPreviousConnection());
      dispatch(tradeSocketClose());
      dispatch(resetDepositList);
    };
  }, []);
  useEffect(() => {
    // props.navigation.addListener('didFocus', event => {
    //   openOderDetails(true);
    // });

    dispatch(getTreadingFeee())
      .then(res => {
        tradeFeesFun(
          tradeReducer?.selectedCoinPair?.base_unit +
            tradeReducer?.selectedCoinPair?.quote_unit,
          res,
        );
        dispatch(
          getTreadingRules(
            tradeReducer?.selectedCoinPair?.base_unit +
              tradeReducer?.selectedCoinPair?.quote_unit,
          ),
        );
      })
      .catch(errr => {
        // alert('edfs');
      });

    return () => {
      dispatch(stopPreviousConnection());
      dispatch(tradeSocketClose());
      dispatch(
        orderHistoryUpdate({
          prop: 'orderHistory',
          value: [],
        }),
      );
    };
  }, [tradeReducer?.selectedCoinPair?.name]);

  const updateSocket = async pair => {
    dispatch(callOrderSocket({pair: pair}));
  };
  const resetData1 = () => {
    dispatch(tradeValuesUpdate({prop: 'tradeAmount', value: ''}));
    dispatch(tradeValuesUpdate({prop: 'totalAmount', value: '0.0'}));
    dispatch(tradeValuesUpdate({prop: 'priceTrade', value: ''}));
    setSelectedButton('0%');
  };

  useEffect(() => {
    if (props?.item === 'buy') {
      setBuySellBtnSelect(true);
      setSellButtonSelected(false);
    } else {
      setBuySellBtnSelect(false);
      setSellButtonSelected(true);
    }
    return () => {};
  }, [props.item]);

  const tradeFeesFun = async (pair, allPairData) => {
    let data = allPairData;
    let pairData = data.find(item => item.id == pair);
    console.log('TRADE_DATE------', pairData, pair);

    dispatch(
      tradeValuesUpdate({
        prop: 'tradeFees',
        value: pairData,
      }),
    );
    dispatch(
      tradeValuesUpdate({
        prop: 'amountDecimalValue',
        value: pairData?.amount_precision,
      }),
    );
    dispatch(
      tradeValuesUpdate({
        prop: 'priceDecimalValue',
        value: pairData?.price_precision,
      }),
    );
  };

  const percentageSelection = value => {
    let balance = renderUserTotalBalance(
      sellButtonSelected
        ? tradeReducer?.selectedCoinPair?.base_unit
        : tradeReducer?.selectedCoinPair?.quote_unit,
    );
    console.log('blalcedasdhas', balance);
    if (sellButtonSelected) {
      var text = ((value * balance) / 100).toFixed(
        tradeReducer.amountDecimalValue,
      );

      console.log('text amount', text, balance, currentSelectedBalance);

      if (/^\d*\.?\d*$/.test(text) && text > 0) {
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: text,
          }),
        );

        let tradePrice = 0;
        if (1 * tradeReducer.priceTrade > 0) {
          tradePrice = 1 * tradeReducer.priceTrade;
          //alert(tradePrice)
        } else {
          tradePrice =
            renderLastPrice(tradeReducer?.selectedCoinPair?.name) != undefined
              ? renderLastPrice(tradeReducer?.selectedCoinPair?.name).last
              : ' ';
        }
        dispatch(
          tradeValuesUpdate({
            prop: 'priceTrade',
            value: tradePrice.toString(),
          }),
        );

        dispatch(
          tradeValuesUpdate({
            prop: 'totalAmount',
            value: (text * tradePrice).toFixed(5),
          }),
        );
      }
      return text;
    } else {
      var text = (value * balance) / 100;
      if (/^\d*\.?\d*$/.test(text) && text > 0) {
        console.log('text amount', text, balance);
        let tradePrice = 0;
        if (1 * tradeReducer.priceTrade > 0) {
          tradePrice = 1 * tradeReducer.priceTrade;
        } else {
          tradePrice =
            renderLastPrice(tradeReducer?.selectedCoinPair?.name) != undefined
              ? renderLastPrice(tradeReducer?.selectedCoinPair?.name).last
              : ' ';
        }
        dispatch(
          tradeValuesUpdate({
            prop: 'totalAmount',
            value: (1 * text).toFixed(5),
          }),
        );

        dispatch(
          tradeValuesUpdate({
            prop: 'priceTrade',
            value: tradePrice.toString(),
          }),
        );
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: (text / tradePrice)
              .toFixed(tradeReducer.amountDecimalValue)
              .toString(),
          }),
        );

        return text;
      }
    }
  };

  const openOderDetails = (data, loader) => {
    // alert('hello');
    let dArray = [];

    dArray = data.filter(
      res =>
        res.currency == tradeReducer?.selectedCoinPair?.base_unit ||
        res.currency == tradeReducer?.selectedCoinPair?.quote_unit,
    );
    console.log('====================================');
    console.log(dArray);
    console.log('====================================');
    // FundsReducer.fundsUserDetails &&
    //   FundsReducer?.fundsUserDetails?.map((item, index) => {
    //     console.log(
    //       'item-------111',
    //       item.id,
    //       '-------tradeReducer.selectedCoinPair.base_unit',
    //       tradeReducer?.selectedCoinPair?.base_unit,
    //       'tradeReducer.selectedCoinPair.quote_unit--',
    //       tradeReducer?.selectedCoinPair?.quote_unit,
    //     );

    //     if (item.id === tradeReducer?.selectedCoinPair?.base_unit) {
    //       let price = FundsReducer.coinToUsdData[item.id.toUpperCase()];
    //       item.usdPrice = price ? price.USD : 1;
    //       coinToDollar = parseFloat(item.balance.balance) * item.usdPrice;
    //       dArray.push({item: item, currencyPrice: coinToDollar});
    //     } else if (item.id === tradeReducer?.selectedCoinPair?.quote_unit) {
    //       let price = FundsReducer.coinToUsdData[item.id.toUpperCase()];
    //       item.usdPrice = price ? price.USD : 1;
    //       coinToDollar = parseFloat(item.balance.balance) * item.usdPrice;
    //       dArray.push({item: item, currencyPrice: coinToDollar});
    //     } else {
    //       return;
    //     }
    //   });
    setFundsArray(dArray);

    // console.log('dArray---', dArray);
    dispatch(
      orderHistoryUpdate({
        prop: 'openOrders',
        value: [],
      }),
    );
    dispatch(getMarketList());
    let params = {
      page: `1`,
      limit: '5',
    };
    //https://exchange.coincult.io/api/v2/peatio/market/orders?page=1&limit=50&market=btcusdt&state=wait
    //                                   /peatio/market/orders?page=1&limit=50&market=btcusdt&state=wait
    //https://exchange.coincult.io/api/v2/peatio/market/orders?limit=50&page=1&state=wait
    dispatch(
      getOpenOrders(
        params,
        `&market=${
          tradeReducer?.selectedCoinPair?.base_unit +
          tradeReducer?.selectedCoinPair?.quote_unit
        }&state=wait`,
        loader,
      ),
    );
  };
  const onIncDecAmount = type => {
    if (type === 'Dec') {
      if (amount && amount > 0) {
        let newAmount = parseFloat(amount) - 1;
        setAmount(newAmount + '');
      } else return;
    } else {
      let newAmount = parseFloat(amount) + 1;
      setAmount(newAmount + '');
    }
  };

  const onIncDec = type => {
    if (type === 'Dec') {
      if (limitValue && limitValue > 0) {
        let newAmount = parseFloat(limitValue) - parseFloat(0.00000001);
        setLimitValue(newAmount.toFixed(8));
        if (tradeReducer.tradeAmount != '') {
          let amt = parseFloat(tradeReducer.tradeAmount);

          if (amt > 0) {
            amt = amt - 0.0001;
          }
          if (amt > 0) {
            updateTotalAmountOnIncDec(
              amt.toFixed(tradeReducer.amountDecimalValue).toString(),
            );
          }
        } else {
          let amt = parseFloat('0.0');

          if (amt > 0) {
            amt = amt - 0.0001;
          }
          if (amt > 0) {
            updateTotalAmountOnIncDec(amt.toString());
          }
        }
      } else return;
    } else {
      let newAmount = parseFloat(limitValue) + parseFloat(0.00000001);
      setLimitValue(newAmount.toFixed(8));
    }
  };

  const renderLastPrice = type => {
    for (var index in marketSocketReducer.marketData) {
      if (marketSocketReducer.marketData[index].name == type) {
        // console.log(
        //   'marketSocketReducer.marketData[index].name',
        //   marketSocketReducer.marketData[index],
        // );
        return marketSocketReducer.marketData[index];
      }
    }
  };
  const renderUsdPrice = type => {
    if (
      tradeReducer?.selectedCoinPair?.quote_unit == type &&
      FundsReducer?.coinToUsdData[type?.toUpperCase()]
    ) {
      return FundsReducer?.coinToUsdData[type?.toUpperCase()].USD;
    } else {
      return 1;
    }
  };
  var volumeCheck = tradeReducer?.selectedCoinPair?.price_change_percent?.slice(
    0,
    -1,
  );
  const getUserBalance = coinName => {
    dispatch(getBalanceDetails({coinName}));
  };
  const resetData = type => {
    dispatch(tradeValuesUpdate({prop: 'tradeAmount', value: ''}));
    dispatch(tradeValuesUpdate({prop: 'totalAmount', value: ''}));
    type == type &&
      dispatch(tradeValuesUpdate({prop: 'priceTrade', value: ''}));
    setSelectedButton('0%');
    setBtnOneSelected(false);
    setBtnTwoSelected(false);
    setBtnThreeSelected(false);
    setBtnFourSelected(false);
    setSelectedButton('0%');
  };

  const renderUserTotalBalance = type => {
    // console.log('tradeReducer.allBalance', tradeReducer.allBalance, type);
    if (tradeReducer.allBalance.length != 0) {
      for (var index in tradeReducer.allBalance) {
        if (tradeReducer.allBalance[index].currency == type) {
          var balance = tradeReducer.allBalance[index].balance;
          if (balance != currentSelectedBalance) {
            setCurrentSelectedBalance(tradeReducer.allBalance[index].balance);
          }
          var totalValue = balance;
          totalValue == undefined ? 0.0 : totalValue;
          return parseFloat(totalValue)?.toFixed(4);
        }
      }
    } else {
      return parseFloat('0.00')?.toFixed(4);
    }
  };

  const pickPriceFromBook = (price, amount) => {
    console.log('------', price, amount);
    dispatch(
      tradeValuesUpdate({
        prop: 'priceTrade',
        value: price,
      }),
    );
    var totalTrade = (parseFloat(price) * parseFloat(amount)).toFixed(5);
    let userBalance = renderUserTotalBalance(
      sellButtonSelected
        ? tradeReducer?.selectedCoinPair?.base_unit
        : tradeReducer?.selectedCoinPair?.quote_unit,
    );

    // let userBalance = 1500
    console.log('d------', totalTrade, userBalance);
    if (sellButtonSelected) {
      if (amount <= userBalance || userBalance == 0 || !limitSelected) {
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: amount,
          }),
        );
      } else {
        console.log('TEMP----', parseFloat(userBalance), amount);
        amount = (99 * userBalance) / 100;
        console.log('amoun-----', amount);
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: amount.toFixed(tradeReducer.amountDecimalValue),
          }),
        );
      }
    } else {
      if (
        !limitSelected ||
        userBalance == 0 ||
        userBalance >= parseFloat(totalTrade)
      ) {
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: amount,
          }),
        );
      } else {
        amount = (parseFloat(userBalance) / parseFloat(price)).toFixed(
          tradeReducer.amountDecimalValue,
        );

        let tempTotal = (parseFloat(price) * parseFloat(amount)).toFixed(5);
        if (tempTotal <= parseFloat(userBalance)) {
          dispatch(
            tradeValuesUpdate({
              prop: 'tradeAmount',
              value: amount,
            }),
          );
        } else {
          amount = (99 * amount) / 100;
          dispatch(
            tradeValuesUpdate({
              prop: 'tradeAmount',
              value: amount.toFixed(2),
            }),
          );
        }
      }
    }
    dispatch(
      tradeValuesUpdate({
        prop: 'totalAmount',
        value: (parseFloat(price) * parseFloat(amount)).toFixed(5),
      }),
    );
  };
  function updateTotalTrade(text) {
    let balance = renderUserTotalBalance(
      sellButtonSelected
        ? tradeReducer?.selectedCoinPair?.base_unit
        : tradeReducer?.selectedCoinPair?.quote_unit,
    );
    if (text != '') {
      var priceTrade = 0;
      var amount = 0;

      priceTrade =
        tradeReducer.priceTrade == ''
          ? this.renderLastPrice(tradeReducer?.selectedCoinPair?.name) !=
            undefined
            ? this.renderLastPrice(tradeReducer?.selectedCoinPair?.name).last
            : ''
          : this.props.priceTrade;
      priceTrade = 1 * priceTrade;
      dispatch(
        tradeValuesUpdate({
          prop: 'priceTrade',
          value: priceTrade.toFixed(tradeReducer?.priceDecimalValue),
        }),
      );
      if (parseFloat(text) <= parseFloat(balance)) {
        amount = parseFloat(text) / priceTrade;
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: amount.toFixed(tradeReducer?.amountDecimalValue),
          }),
        );
        dispatch(
          tradeValuesUpdate({
            prop: 'totalAmount',
            value: text,
          }),
        );
        console.log('parseFloat----', parseFloat(text), balance);
      } else {
        amount = balance / priceTrade;
        let totalAmount = (
          amount.toFixed(tradeReducer.amountDecimalValue) *
          priceTrade.toFixed(tradeReducer.priceDecimalValue)
        ).toFixed(5);

        if (totalAmount > parseFloat(balance)) {
          amount = (99 * amount) / 100;
          totalAmount = (
            amount.toFixed(tradeReducer.amountDecimalValue) *
            priceTrade.toFixed(tradeReducer.priceDecimalValue)
          ).toFixed(5);
        }
        console.log('AMOUNT-----', amount, totalAmount);

        amount > 0 &&
          dispatch(
            tradeValuesUpdate({
              prop: 'tradeAmount',
              value: amount.toFixed(tradeReducer.amountDecimalValue),
            }),
          );
        dispatch(
          tradeValuesUpdate({
            prop: 'totalAmount',
            value: amount > 0 ? totalAmount : text,
          }),
        );

        console.log('priceTrade----', parseFloat(text), balance);
      }
    } else {
      dispatch(
        tradeValuesUpdate({
          prop: 'totalAmount',
          value: '',
        }),
      );
      dispatch(
        tradeValuesUpdate({
          prop: 'tradeAmount',
          value: '',
        }),
      );
    }
  }
  function updateTotalAmountOnIncDec(text) {
    console.log('TEST-----', text);
    let balance = renderUserTotalBalance(
      sellButtonSelected
        ? tradeReducer?.selectedCoinPair?.base_unit
        : tradeReducer?.selectedCoinPair?.quote_unit,
    );
    let tradeVal = 0;
    if (text != '') {
      if (sellButtonSelected) {
        var priceTrade = 0;
        var textAmt = 1 * text;
        if (textAmt > parseFloat(balance) && parseFloat(balance) > 0) {
          tradeVal = parseFloat(balance).toFixed(
            tradeReducer?.amountDecimalValue,
          );
        } else {
          tradeVal = text;
        }
        console.log('------', tradeVal);
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: tradeVal,
          }),
        );
      } else {
        let priceTrade = parseFloat(tradeReducer?.priceTrade);
        console.log('PRICR_-----', priceTrade, text, balance);

        if (priceTrade * parseFloat(text) <= balance) {
          dispatch(
            tradeValuesUpdate({
              prop: 'tradeAmount',
              value: text,
            }),
          );
          tradeVal = parseFloat(text);
        } else {
          let amount = (parseFloat(balance) / parseFloat(priceTrade))
            .toFixed(tradeReducer?.amountDecimalValue)
            .toString();
          if (amount == 'NaN' || amount == 0) {
            amount = text;
          }
          console.log('AMOUNt---', amount);
          dispatch(
            tradeValuesUpdate({
              prop: 'tradeAmount',
              value: amount,
            }),
          );
          tradeVal = parseFloat(amount);
        }
      }
    } else {
      dispatch(
        tradeValuesUpdate({
          prop: 'tradeAmount',
          value: text,
        }),
      );
      tradeVal = 0;
    }

    let priceVal = 0;
    if (parseFloat(tradeReducer?.priceTrade) > 0) {
      priceVal = parseFloat(tradeReducer?.priceTrade);
    }
    console.log('priceVal---', priceVal, tradeVal);

    dispatch(
      tradeValuesUpdate({
        prop: 'totalAmount',
        value: (tradeVal * priceVal).toFixed(5),
      }),
    );
  }
  function setPercentageToDefault() {
    setBtnOneSelected(false);
    setBtnTwoSelected(false);
    setBtnThreeSelected(false);
    setBtnFourSelected(false);
    setSelectedButton('0%');
  }
  function requestPlaceOrder() {
    // console.log("hiiiiiiiiiiiiiiiiiiiiii")

    //  let param = { "market": "ethusdt", "side": "sell", "volume": "0.1480", "ord_type": "limit", "price": "281" }
    // debugger;
    let param = {};

    let userBalance =
      renderUserTotalBalance(
        sellButtonSelected
          ? tradeReducer?.selectedCoinPair?.base_unit
          : tradeReducer?.selectedCoinPair?.quote_unit,
      ) +
      ' ' +
      (sellButtonSelected
        ? tradeReducer?.selectedCoinPair?.base_unit?.toUpperCase()
        : tradeReducer?.selectedCoinPair?.quote_unit?.toUpperCase());
    let floatTotalValue = parseFloat(userBalance);

    console.log('USER_BAL-----', userBalance, floatTotalValue);

    if (limitSelected) {
      if (tradeReducer?.priceTrade <= 0) {
        Alert.alert(constants.APP_NAME, 'Please enter valid value in price');
        return;
      }

      if (tradeReducer?.tradeAmount <= 0) {
        Alert.alert(constants.APP_NAME, 'Please enter valid value in amount');
        return;
      }

      if (floatTotalValue <= 0) {
        Alert.alert(constants.APP_NAME, 'Insufficient balance');
        return;
      }

      if (tradeReducer?.tradeAmount.includes('.')) {
        var e = tradeReducer?.tradeAmount.split('.');
        if (e[1].length > tradeReducer?.amountDecimalValue) {
          Alert.alert(
            constants.APP_NAME,
            `Volume decimal value can't be greater then ${tradeReducer?.amountDecimalValue}`,
          );
          return;
        }
      }
      if (tradeReducer?.totalAmount < 1 * tradeReducer?.tradeFees?.min_total) {
        var str = `Total must be greater than ${
          tradeReducer?.tradeFees?.min_total +
          ' ' +
          tradeReducer?.tradeFees?.quote_unit.toUpperCase()
        }
         \n`;
        Alert.alert(constants.APP_NAME, str);
        return;
      }

      param = {
        market: `${
          tradeReducer?.selectedCoinPair?.base_unit +
          tradeReducer?.selectedCoinPair?.quote_unit
        }`,
        side: sellButtonSelected ? 'sell' : 'buy',
        //    volume: `${this.props.tradeAmount}`,
        volume: parseFloat(tradeReducer?.tradeAmount).toFixed(
          tradeReducer?.amountDecimalValue,
        ),
        ord_type: 'limit',
        price: `${tradeReducer?.priceTrade}`,
      };
    } else {
      if (tradeReducer?.tradeAmount <= 0) {
        Alert.alert(constants.APP_NAME, 'Please enter valid value in amount');
        return;
      }

      if (floatTotalValue <= 0) {
        Alert.alert(constants.APP_NAME, 'Insufficient balance');
        return;
      }

      if (tradeReducer?.tradeAmount.includes('.')) {
        var e = tradeReducer?.tradeAmount.split('.');
        if (e[1].length > 5) {
          Alert.alert(
            constants.APP_NAME,
            `Volume decimal value can't be greater then ${tradeReducer?.amountDecimalValue}`,
          );
          return;
        }
      }

      param = {
        market: `${
          tradeReducer?.selectedCoinPair?.base_unit +
          tradeReducer?.selectedCoinPair?.quote_unit
        }`,
        side: sellButtonSelected ? 'sell' : 'buy',
        volume: parseFloat(tradeReducer?.tradeAmount).toFixed(
          tradeReducer?.amountDecimalValue,
        ),
        ord_type: 'market',
      };
    }
    console.log('--------->   ' + JSON.stringify(param) + '   <---------');
    dispatch(placeTradeOrder(param))
      .then(res => {
        Alert.alert(constants.APP_NAME, 'Order placed');
        resetData(false);
        let params = {
          page: `1`,
          limit: '5',
        };
        dispatch(getUserAllBalance(false)).then(res => {
          openOderDetails(res, true);
        });
      })
      .catch(err => {
        console.log('error message', err);
        Alert.alert(constants.APP_NAME, err.replace('account.', ''));
      });
  }
  function updatePriceValue(text) {
    dispatch(
      tradeValuesUpdate({
        prop: 'priceTrade',
        value: text,
      }),
    );

    if (text == '') {
      dispatch(
        tradeValuesUpdate({
          prop: 'tradeAmount',
          value: '',
        }),
      );
      dispatch(
        tradeValuesUpdate({
          prop: 'totalAmount',
          value: '',
        }),
      );
    } else {
      if (parseFloat(tradeReducer?.tradeAmount) > 0) {
        let balance = renderUserTotalBalance(
          sellButtonSelected
            ? tradeReducer?.selectedCoinPair?.base_unit
            : tradeReducer?.selectedCoinPair?.quote_unit,
        );
        if (
          parseFloat(tradeReducer?.tradeAmount) * parseFloat(text) >
          balance
        ) {
          let trade = (parseFloat(balance) / parseFloat(text)).toFixed(
            tradeReducer?.amountDecimalValue,
          );
          if (parseFloat(trade) <= 0) {
            trade = '0';
          }
          dispatch(
            tradeValuesUpdate({
              prop: 'tradeAmount',
              value: trade,
            }),
          );
          dispatch(
            tradeValuesUpdate({
              prop: 'totalAmount',
              value: (parseFloat(trade) * parseFloat(text)).toFixed(5),
            }),
          );
        } else {
          dispatch(
            tradeValuesUpdate({
              prop: 'totalAmount',
              value: (
                parseFloat(tradeReducer?.tradeAmount) * parseFloat(text)
              ).toFixed(5),
            }),
          );
        }
      } else {
        dispatch(
          tradeValuesUpdate({
            prop: 'tradeAmount',
            value: '',
          }),
        );
        dispatch(
          tradeValuesUpdate({
            prop: 'totalAmount',
            value: '',
          }),
        );
      }
    }
  }
  const getClickedItem = data => {
    console.log('chcek data value=-=-=--0-0>>>', data);
    if (sellButtonSelected) {
      let item = data?.find(
        value => value.id == tradeReducer?.selectedCoinPair.base_unit,
      );
      return item;
    } else {
      let item = data?.find(
        value => value.id == tradeReducer?.selectedCoinPair.quote_unit,
      );
      return item;
    }
  };
  const setPairModal = visible => {
    setPairModelVisible(visible);
  };
  return (
    <Wrap
      style={{backgroundColor: ThemeManager.colors.DashboardBG}}
      screenStyle={[
        styles.screenStyle,
        {backgroundColor: ThemeManager.colors.DashboardBG},
      ]}
      bottomStyle={{backgroundColor: ThemeManager.colors.DashboardBG}}>
      <View style={{flex: 1}}>
        <View
          style={{marginHorizontal: 20, marginTop: 20, flexDirection: 'row'}}>
          <TouchableOpacity
            onPress={() => {
              // setSpotPageSelected(0);

              // setShowConvertModal(true);
              Actions.push('ConvertTrade');
              setSpotPageSelected(1);
              // pagerRef.current.setPage(1);
            }}
            style={{marginRight: 30}}>
            <TradeHeader
              title={strings.trade_tab.convert}
              underLine={spotPageSelected === 0 ? true : false}
            />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setSpotPageSelected(1);
              // pagerRef.current.setPage(1);
            }}>
            <TradeHeader
              title={strings.trade_tab.spot}
              underLine={spotPageSelected === 1 ? true : false}
            />
          </TouchableOpacity>
        </View>
        <BorderLine />
        <ScrollView
          key="2"
          // style={{backgroundColor: ThemeManager.colors.whiteScreen}}
          // contentContainerStyle={{flex: 1}}
        >
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View
              style={{
                justifyContent: 'flex-start',
                alignItems: 'center',
                flexDirection: 'row',
                marginVertical: 20,
                marginLeft: 15,
              }}>
              <Image
                source={{uri: ThemeManager.ImageIcons.icon_swap}}
                style={{
                  height: 20,
                  width: 20,
                  marginRight: 10,
                  tintColor: ThemeManager.colors.selectedTextColor,
                }}
              />
              <Text
                style={{
                  fontSize: 20,
                  fontFamily: Fonts.medium,
                  color: ThemeManager.colors.headTxt,
                }}>
                {tradeReducer?.selectedCoinPair?.base_unit.toUpperCase()}/
                {tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase()}
              </Text>
              {/* <Text
               >
                {tradeReducer?.selectedCoinPair?.price_change_percent}
              </Text> */}
              <PercentageChange
                pair={`${tradeReducer?.selectedCoinPair?.base_unit.toUpperCase()}/${tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase()}`}
              />
            </View>
            <TouchableOpacity
              onPress={() => {
                Actions.BuySellMarket();
              }}>
              <Image
                source={{uri: ThemeManager.ImageIcons.icon_spot_right}}
                style={{
                  height: 20,
                  width: 20,
                  resizeMode: 'contain',
                  marginRight: 20,
                  tintColor: ThemeManager.colors.selectedTextColor,
                }}
              />
            </TouchableOpacity>
          </View>

          <View
            style={{
              backgroundColor: ThemeManager.colors.dashboardSubViewBg,
              flex: 1,
              borderTopLeftRadius: 40,
              borderTopRightRadius: 40,
            }}>
            <View style={{margin: 10, marginTop: 20, flex: 1}}>
              <View
                style={{
                  flexGrow: 1,
                  flexDirection: 'row',
                  justifyContent: 'center',
                  // backgroundColor: 'yellow',
                  // alignItems: 'center',
                }}>
                <View style={{flex: 5.5}}>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'center',
                      // alignItems: 'center',
                      // flex: 1,
                    }}>
                    <TouchableOpacity
                      onPress={() => {
                        setBuySellBtnSelect(true);
                        setSellButtonSelected(false);
                        getUserBalance(
                          tradeReducer?.selectedCoinPair?.quote_unit,
                        );
                        resetData(0);
                      }}
                      disabled={buySellBtnSelect ? true : false}
                      style={{
                        height: 40,
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: buySellBtnSelect
                          ? ThemeManager.colors.textGreenColor
                          : ThemeManager.colors.tabBackground,
                      }}>
                      <Text
                        style={{
                          fontSize: 16,
                          fontFamily: Fonts.regular,
                          color: buySellBtnSelect
                            ? ThemeManager.colors.textColor
                            : ThemeManager.colors.CoinColor,
                        }}>
                        {strings.trade_tab.buy}
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => {
                        setBuySellBtnSelect(false);
                        setSellButtonSelected(true);
                        getUserBalance(
                          tradeReducer?.selectedCoinPair?.quote_unit,
                        );
                        resetData(0);
                      }}
                      disabled={buySellBtnSelect ? false : true}
                      style={{
                        height: 40,
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: buySellBtnSelect
                          ? ThemeManager.colors.tabBackground
                          : ThemeManager.colors.textRedColor,
                      }}>
                      <Text
                        style={{
                          fontSize: 16,
                          fontFamily: Fonts.regular,
                          color:
                            buySellBtnSelect == false
                              ? ThemeManager.colors.textColor
                              : ThemeManager.colors.CoinColor,
                        }}>
                        {strings.trade_tab.sell}
                      </Text>
                    </TouchableOpacity>
                  </View>
                  <View style={{width: '100%', marginTop: 10}}>
                    <SelectDropdown
                      data={listLimit}
                      // defaultValueByIndex={1}
                      onSelect={(selectedItem, index) => {
                        console.log(selectedItem, index);
                        if (index == 0) {
                          setLimitSelected(true);
                        } else {
                          setLimitSelected(false);
                        }
                        setSelectedLimitedIndex(index);
                        setuserPricePrecision(selectedItem.value);
                        getUserBalance(
                          tradeReducer?.selectedCoinPair?.quote_unit,
                        );
                        resetData(0);
                      }}
                      buttonStyle={styles.dropdown3BtnStyle}
                      renderCustomizedButtonChild={(selectedItem, index) => {
                        return (
                          <View
                            style={[
                              styles.dropdown3BtnChildStyle,
                              {
                                backgroundColor:
                                  ThemeManager.colors.tabBackground,
                              },
                            ]}>
                            <TouchableOpacity
                              onPress={() => {
                                console.log(
                                  'TRADE----',
                                  tradeReducer.tradeFees,
                                );
                                setShowRules(!isShowRules);
                              }}>
                              <Image
                                // source={{uri: Images.icon_dropDown}}
                                source={{uri: Images.icon_info}}
                                style={{
                                  height: 22,
                                  width: 22,
                                  resizeMode: 'contain',
                                  tintColor:
                                    ThemeManager.colors.inactiveTextColor,
                                }}
                              />
                            </TouchableOpacity>

                            <Text
                              style={[
                                styles.dropdown3BtnTxt,
                                {color: '#707988'},
                              ]}>
                              {selectedItem ? selectedItem.title : 'Limit'}
                            </Text>

                            <Image
                              source={{uri: Images.icon_dropDown}}
                              style={{
                                height: 15,
                                width: 15,
                                resizeMode: 'contain',
                                tintColor:
                                  ThemeManager.colors.inactiveTextColor,
                                // tintColor: 'black',
                              }}
                            />
                          </View>
                        );
                      }}
                      // dropdownStyle={styles.dropdown3DropdownStyle}
                      dropdownStyle={[
                        styles.dropdown3DropdownStyle,
                        {
                          backgroundColor: ThemeManager.colors.tabBackground,
                        },
                      ]}
                      // rowStyle={styles.dropdown3RowStyle}
                      rowStyle={[
                        styles.dropdown3RowStyle,
                        {
                          backgroundColor: ThemeManager.colors.tabBackground,
                        },
                      ]}
                      renderCustomizedRowChild={(item, index) => {
                        return (
                          <View style={styles.dropdown3RowChildStyle}>
                            {/* <Image
                                source={item.image}
                                style={styles.dropdownRowImage}
                              /> */}
                            <Text
                              style={[
                                styles.dropdown3RowTxt,
                                {
                                  color:
                                    selectedLimitedIndex === item.value
                                      ? ThemeManager.colors.Depositbtn
                                      : ThemeManager.colors.headTxt,
                                },
                              ]}>
                              {item.title}
                            </Text>
                          </View>
                        );
                      }}
                    />
                  </View>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        marginVertical: 10,
                      }}>
                      {limitSelected ? (
                        <TradeInput
                          keyboardType="decimal-pad"
                          placeholder={limitValue}
                          placeholderTextColor={
                            ThemeManager.colors.inactiveTextColor
                          }
                          value={limitSelected ? tradeReducer?.priceTrade : ''}
                          onChangeText={text => {
                            if (/^\d*\.?\d*$/.test(text)) {
                              setPercentageToDefault();

                              if (text.includes('.')) {
                                // alert('shashi');
                                let e = text.split('.');

                                if (e[0].length == 0) {
                                  dispatch(
                                    tradeValuesUpdate({
                                      prop: 'priceTrade',
                                      value: '0' + text,
                                    }),
                                  );
                                } else if (
                                  e[1].length <= tradeReducer?.priceDecimalValue
                                ) {
                                  updatePriceValue(text);
                                }
                              } else {
                                // alert('shashi1');
                                updatePriceValue(text);
                              }
                            }
                          }}
                          onPressMinus={() => {
                            onIncDec('Dec');
                          }}
                          onPressPlus={() => {
                            onIncDec('Inc');
                          }}
                          textInputStyle={{
                            color: ThemeManager.colors.textColor1,
                          }}
                        />
                      ) : (
                        <View
                          style={{
                            // flexDirection: 'row',
                            //   flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center',
                            height: 40,
                            backgroundColor: ThemeManager.colors.tabBackground,
                            paddingHorizontal: 10,
                          }}>
                          <Text
                            style={{
                              fontSize: 14,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.textColor1,
                            }}>
                            {strings.trade_tab.market_price}
                          </Text>
                        </View>
                      )}

                      <View style={{marginVertical: 5}} />
                      {limitSelected ? (
                        <TradeInput
                          placeholder={
                            'Amount' +
                            ' (' +
                            tradeReducer?.selectedCoinPair?.base_unit.toUpperCase() +
                            ')'
                          }
                          placeholderTextColor={
                            ThemeManager.colors.inactiveTextColor
                          }
                          keyboardType="decimal-pad"
                          // value={amount}
                          value={tradeReducer?.tradeAmount}
                          onChangeText={text => {
                            if (/^\d*\.?\d*$/.test(text)) {
                              if (limitSelected) {
                                if (text.includes('.')) {
                                  var e = text.split('.');
                                  console.log(
                                    'SPLIT----',
                                    e,
                                    tradeReducer?.amountDecimalValue,
                                  );
                                  if (e[0].length == 0) {
                                    dispatch(
                                      tradeValuesUpdate({
                                        prop: 'tradeAmount',
                                        value: '0' + text,
                                      }),
                                    );
                                  } else if (
                                    e[1].length <=
                                    tradeReducer?.amountDecimalValue
                                  ) {
                                    updateTotalAmountOnIncDec(text);
                                  }
                                } else {
                                  updateTotalAmountOnIncDec(text);
                                }
                              }
                            }
                          }}
                          onPressMinus={() => {
                            // onIncDecAmount('Dec');
                          }}
                          onPressPlus={() => {
                            // onIncDecAmount('Inc');
                          }}
                          textInputStyle={{
                            color: ThemeManager.colors.textColor1,
                          }}
                          maxLength={9}
                        />
                      ) : null}
                      {limitSelected === false ? (
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                          }}>
                          <TouchableOpacity
                            onPress={() => {
                              setAmountSelected(true);
                            }}
                            style={{
                              height: 20,
                              justifyContent: 'center',
                              alignItems: 'center',
                              width: '49%',
                              marginLeft: 1,
                              backgroundColor:
                                ThemeManager.colors.tabBackground,
                            }}>
                            <Text
                              style={{
                                color: amountSelected
                                  ? ThemeManager.colors.textColor1
                                  : ThemeManager.colors.inactiveTextColor,
                                fontSize: 11,
                                fontFamily: Fonts.regular,
                              }}>
                              {strings.trade_tab.amount}
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            onPress={() => {
                              setAmountSelected(false);
                            }}
                            style={{
                              height: 20,
                              justifyContent: 'center',
                              alignItems: 'center',
                              width: '49%',

                              marginRight: 1,
                              backgroundColor:
                                ThemeManager.colors.tabBackground,
                            }}>
                            <Text
                              style={{
                                color: amountSelected
                                  ? ThemeManager.colors.inactiveTextColor
                                  : ThemeManager.colors.textColor1,
                                fontSize: 11,
                                fontFamily: Fonts.regular,
                              }}>
                              {strings.trade_tab.total}
                            </Text>
                          </TouchableOpacity>
                        </View>
                      ) : null}
                      {limitSelected === false ? (
                        <View style={{marginVertical: 5}}>
                          <TradeInput
                            keyboardType={'decimal-pad'}
                            placeholder={
                              buySellBtnSelect
                                ? amountSelected
                                  ? '(' +
                                    tradeReducer?.selectedCoinPair?.base_unit.toUpperCase() +
                                    ')'
                                  : '(' +
                                    tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase() +
                                    ')'
                                : amountSelected
                                ? '(' +
                                  tradeReducer?.selectedCoinPair?.base_unit.toUpperCase() +
                                  ')'
                                : '(' +
                                  tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase() +
                                  ')'
                            }
                            placeholderTextColor={
                              ThemeManager.colors.inactiveTextColor
                            }
                            value={
                              amountSelected
                                ? tradeReducer?.tradeAmount
                                : tradeReducer?.totalAmount
                            }
                            maxLength={10}
                            onChangeText={e => {
                              // setAmount(e);
                              if (/^\d*\.?\d*$/.test(e)) {
                                setPercentageToDefault();
                                let currentPrice =
                                  renderLastPrice(
                                    tradeReducer?.selectedCoinPair?.name,
                                  ) != undefined
                                    ? renderLastPrice(
                                        tradeReducer?.selectedCoinPair?.name,
                                      ).last
                                    : ' ';

                                if (amountSelected) {
                                  let amount;
                                  if (e.includes('.')) {
                                    let temp = e.split('.');
                                    if (
                                      temp[1].length <=
                                      tradeReducer.amountDecimalValue
                                    ) {
                                      amount = e;
                                    } else {
                                      console.log('RETURn------');
                                      return;
                                    }
                                  } else {
                                    amount = e;
                                  }

                                  dispatch(
                                    tradeValuesUpdate({
                                      prop: 'tradeAmount',
                                      value: amount,
                                    }),
                                  );
                                  var total = parseFloat(amount) * currentPrice;
                                  console.log('totaltotaltotal', total);
                                  // alert(total);
                                  dispatch(
                                    tradeValuesUpdate({
                                      prop: 'totalAmount',
                                      value: (amount <= 0 || amount.length == 0
                                        ? ' '
                                        : total
                                      ).toString(),
                                    }),
                                  );
                                } else {
                                  dispatch(
                                    tradeValuesUpdate({
                                      prop: 'totalAmount',
                                      value: e,
                                    }),
                                  );
                                  let amount = (1 * e) / (1 * currentPrice);
                                  console.log(
                                    '========',
                                    tradeReducer?.amountDecimalValue,
                                  );
                                  dispatch(
                                    tradeValuesUpdate({
                                      prop: 'tradeAmount',
                                      value: amount.toFixed(
                                        tradeReducer?.amountDecimalValue,
                                      ),
                                    }),
                                  );
                                }
                              }
                            }}
                            onPressMinus={() => {
                              onIncDecAmount('Dec');
                            }}
                            onPressPlus={() => {
                              onIncDecAmount('Inc');
                            }}
                            textInputStyle={{
                              color: ThemeManager.colors.textColor1,
                            }}
                          />
                        </View>
                      ) : null}
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          // backgroundColor: 'red',
                          // height: 15,
                          marginTop: 10,
                        }}>
                        <TouchableOpacity
                          style={{width: '23%'}}
                          onPress={() => {
                            // setSelectedPercentage(1);

                            if (btnTwoSelected) {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(false);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('25%');
                              percentageSelection(25);
                            } else if (!btnTwoSelected && !btnOneSelected) {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(false);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('25%');
                              percentageSelection(25);
                            } else {
                              setBtnOneSelected(false);
                              setBtnTwoSelected(false);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('0%');
                            }
                          }}>
                          <View
                            style={{
                              backgroundColor:
                                btnOneSelected === true
                                  ? buySellBtnSelect
                                    ? ThemeManager.colors.btnGreenColor
                                    : ThemeManager.colors.textRedColor
                                  : ThemeManager.colors.tabBackground,
                              height: 15,
                              // width: '23%',
                            }}
                          />
                          <Text
                            style={{
                              fontSize: 14,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.inactiveTextColor,
                            }}>
                            25%
                          </Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                          onPress={() => {
                            // setSelectedPercentage(1);
                            if (btnThreeSelected) {
                              // alert(0);
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('50%');
                              percentageSelection(50);
                            } else if (!btnThreeSelected && !btnTwoSelected) {
                              // alert(1);
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('50%');
                              percentageSelection(50);
                            } else if (!btnFourSelected && btnTwoSelected) {
                              setBtnOneSelected(true);
                              setSelectedButton('25%');
                              percentageSelection(25);

                              setBtnTwoSelected(false);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                            } else {
                              // alert(3);
                              setBtnOneSelected(false);
                              setBtnTwoSelected(false);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('0%');
                            }
                          }}
                          style={{width: '23%'}}>
                          <View
                            style={{
                              backgroundColor: btnTwoSelected
                                ? buySellBtnSelect
                                  ? ThemeManager.colors.btnGreenColor
                                  : ThemeManager.colors.textRedColor
                                : ThemeManager.colors.tabBackground,
                              height: 15,
                              // width: '%',
                            }}
                          />
                          <Text
                            style={{
                              fontSize: 14,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.inactiveTextColor,
                            }}>
                            50%
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={{width: '23%'}}
                          onPress={() => {
                            if (btnFourSelected) {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(true);
                              setBtnFourSelected(false);
                              setSelectedButton('75%');
                              percentageSelection(75);
                            } else if (!btnFourSelected && !btnThreeSelected) {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(true);
                              setBtnFourSelected(false);
                              setSelectedButton('75%');
                              percentageSelection(75);
                            } else if (!btnFourSelected && btnThreeSelected) {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('50%');
                              percentageSelection(50);
                            } else {
                              setBtnOneSelected(false);
                              setBtnTwoSelected(false);
                              setBtnThreeSelected(false);
                              setBtnFourSelected(false);
                              setSelectedButton('0%');
                            }
                          }}>
                          <View
                            style={{
                              backgroundColor: btnThreeSelected
                                ? buySellBtnSelect
                                  ? ThemeManager.colors.btnGreenColor
                                  : ThemeManager.colors.textRedColor
                                : ThemeManager.colors.tabBackground,
                              height: 15,
                              // width: '23%',
                            }}
                          />
                          <Text
                            style={{
                              fontSize: 14,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.inactiveTextColor,
                            }}>
                            75%
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={{width: '23%'}}
                          onPress={() => {
                            if (btnFourSelected) {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(true);
                              setBtnFourSelected(false);
                              setSelectedButton('75%');
                              percentageSelection(75);
                            } else {
                              setBtnOneSelected(true);
                              setBtnTwoSelected(true);
                              setBtnThreeSelected(true);
                              setBtnFourSelected(true);
                              setSelectedButton('100%');
                              percentageSelection(99.8);
                            }
                          }}>
                          <View
                            style={{
                              backgroundColor: btnFourSelected
                                ? buySellBtnSelect
                                  ? ThemeManager.colors.btnGreenColor
                                  : ThemeManager.colors.textRedColor
                                : ThemeManager.colors.tabBackground,
                              height: 15,
                              // width: '23%',
                            }}
                          />
                          <Text
                            style={{
                              fontSize: 14,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.inactiveTextColor,
                            }}>
                            100%
                          </Text>
                        </TouchableOpacity>
                      </View>
                      {limitSelected ? (
                        <View
                          style={{
                            height: 40,
                            backgroundColor: ThemeManager.colors.tabBackground,
                            justifyContent: 'center',
                            alignItems: 'center',
                            marginTop: 10,
                          }}>
                          <TextInput
                            value={tradeReducer.totalAmount}
                            keyboardType="decimal-pad"
                            placeholder={
                              strings.trade_tab.total +
                              '(' +
                              tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase() +
                              ')'
                            }
                            placeholderTextColor={
                              ThemeManager.colors.inactiveTextColor
                            }
                            style={{
                              fontSize: 15,
                              fontFamily: Fonts.regular,
                              // backgroundColor: ThemeManager.colors.tabBackground,
                              color: ThemeManager.colors.inactiveTextColor,
                            }}
                            onChangeText={text => {
                              if (/^\d*\.?\d*$/.test(text)) {
                                if (text.includes('.')) {
                                  var e = text.split('.');
                                  console.log(
                                    'SPLIT----',
                                    e[0].length,
                                    e[1].length,
                                    tradeReducer?.priceDecimalValue,
                                  );
                                  if (e[0].length == 0) {
                                    dispatch(
                                      tradeValuesUpdate({
                                        prop: 'totalAmount',
                                        value: '0' + text,
                                      }),
                                    );
                                  } else if (
                                    e[1].length <=
                                    tradeReducer?.priceDecimalValue
                                  ) {
                                    updateTotalTrade(text);
                                  }
                                } else {
                                  updateTotalTrade(text);
                                }
                              }
                            }}
                            maxLength={15}
                          />
                        </View>
                      ) : null}
                      <View
                        style={{
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          flexDirection: 'row',
                          marginVertical: 10,
                        }}>
                        <Text
                          style={{
                            fontSize: 15,
                            fontFamily: Fonts.regular,
                            // backgroundColor: ThemeManager.colors.tabBackground,
                            color: ThemeManager.colors.inactiveTextColor,
                          }}>
                          {strings.trade_tab.available}
                        </Text>
                        <View
                          style={{
                            justifyContent: 'flex-end',
                            alignItems: 'center',
                            flexDirection: 'row',
                          }}>
                          <Text
                            style={{
                              fontSize: 15,
                              fontFamily: Fonts.regular,
                              // backgroundColor:
                              //   ThemeManager.colors.tabBackground,
                              color: ThemeManager.colors.inactiveTextColor,
                            }}>
                            {(sellButtonSelected
                              ? tradeReducer?.selectedCoinPair?.base_unit?.toUpperCase()
                              : tradeReducer?.selectedCoinPair?.quote_unit?.toUpperCase()) +
                              ' ' +
                              renderUserTotalBalance(
                                sellButtonSelected
                                  ? tradeReducer?.selectedCoinPair?.base_unit
                                  : tradeReducer?.selectedCoinPair?.quote_unit,
                              )}
                          </Text>
                          <TouchableOpacity
                            onPress={() => {
                              ActionSheetDepositTransfer.current.show();
                            }}
                            style={{
                              alignItems: 'center',
                              justifyContent: 'center',
                              borderRadius: 10,
                              height: 20,
                              width: 20,
                              marginLeft: 5,
                              backgroundColor:
                                ThemeManager.colors.tabBottomBorder,
                            }}>
                            <Image
                              source={{uri: Images.icon_plus}}
                              style={{
                                height: 12,
                                width: 12,
                                resizeMode: 'contain',
                                tintColor: 'black',
                              }}
                            />
                          </TouchableOpacity>
                        </View>
                      </View>
                      <TouchableOpacity
                        onPress={() => {
                          console.log(
                            'sellButtonSelected---->>>',
                            sellButtonSelected,
                          );
                          requestPlaceOrder();
                        }}
                        style={{
                          justifyContent: 'center',
                          alignItems: 'center',
                          backgroundColor: buySellBtnSelect
                            ? ThemeManager.colors.btnGreenColor
                            : ThemeManager.colors.textRedColor,
                          height: 40,
                        }}>
                        <Text
                          style={{
                            fontFamily: Fonts.regular,
                            fontSize: 16,
                            color: 'white',
                          }}>
                          {buySellBtnSelect
                            ? strings.trade_tab.buy
                            : strings.trade_tab.sell}{' '}
                          {tradeReducer?.selectedCoinPair?.base_unit.toUpperCase()}
                        </Text>
                      </TouchableOpacity>
                    </View>
                    <View></View>
                  </View>
                </View>
                <View style={{flex: 4.5}}>
                  <View style={{flex: 1}}>
                    <View
                      style={{
                        flex: 1,
                        backgroundColor: 'black',
                        marginLeft: 3,
                      }}>
                      <View
                        style={{
                          justifyContent: 'space-between',
                          // alignItems: 'center',
                          flexDirection: 'row',
                          // marginHorizontal: 5,
                        }}>
                        <View style={{alignItems: 'center'}}>
                          <Text
                            style={{
                              color: ThemeManager.colors.anouncementtextColour,
                              fontFamily: Fonts.regular,
                              fontSize: 16,
                            }}>
                            {strings.trade_tab.price}
                          </Text>
                          <Text
                            style={{
                              fontSize: 15,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.textColor,
                            }}>
                            (
                            {tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase()}
                            )
                          </Text>
                        </View>
                        <View style={{alignItems: 'flex-end'}}>
                          <Text
                            style={{
                              color: ThemeManager.colors.anouncementtextColour,
                              fontFamily: Fonts.regular,
                              fontSize: 16,
                            }}>
                            {strings.trade_tab.amount}
                          </Text>
                          <Text
                            style={{
                              fontSize: 15,
                              fontFamily: Fonts.regular,
                              color: ThemeManager.colors.textColor,
                            }}>
                            (
                            {tradeReducer?.selectedCoinPair?.base_unit.toUpperCase()}
                            )
                          </Text>
                        </View>
                      </View>
                      {showBuyOrder &&
                        orderHistoryReducer?.marketCoinInfo != null && (
                          <AskBook
                            pricePrecision={userPricePrecision}
                            lisView={{paddingTop: 2, marginRight: 3}}
                            selectedCoinPair={tradeReducer?.selectedCoinPair}
                            marketCoinInfo={orderHistoryReducer?.marketCoinInfo}
                            onPress={(price, amount) => {
                              if (!sellButtonSelected) {
                                pickPriceFromBook(price, amount);
                                setBtnOneSelected(false);
                                setBtnTwoSelected(false);
                                setBtnThreeSelected(false);
                                setBtnFourSelected(false);
                                setSelectedButton('0%');
                              }
                            }}
                          />
                        )}

                      <View style={{alignItems: 'center', marginTop: 10}}>
                        <Text
                          style={{
                            color: ThemeManager.colors.textRedColor,
                            fontFamily: Fonts.regular,
                            fontSize: 16,
                          }}>
                          {renderLastPrice(
                            tradeReducer?.selectedCoinPair?.name,
                          ) != undefined
                            ? renderLastPrice(
                                tradeReducer?.selectedCoinPair?.name,
                              ).last
                            : ' '}
                        </Text>
                        <Text
                          style={{
                            color: ThemeManager.colors.inactiveTextColor,
                            fontFamily: Fonts.regular,
                            fontSize: 14,
                            marginBottom: 5,
                          }}>
                          $
                          {Singleton.getInstance().funComma(
                            renderUsdPrice(
                              tradeReducer?.selectedCoinPair?.quote_unit,
                            ) != undefined &&
                              renderLastPrice(
                                tradeReducer?.selectedCoinPair?.name,
                              ) != undefined
                              ? (
                                  renderLastPrice(
                                    tradeReducer?.selectedCoinPair?.name,
                                  ).last *
                                  renderUsdPrice(
                                    tradeReducer?.selectedCoinPair?.quote_unit,
                                  )
                                )?.toFixed(4)
                              : ' ',
                          )}
                        </Text>
                      </View>
                      {showSellOrder &&
                        orderHistoryReducer?.marketCoinInfo != null && (
                          <View>
                            <BidsBook
                              pricePrecision={userPricePrecision}
                              lisView={{paddingTop: 2, marginRight: 3}}
                              selectedCoinPair={tradeReducer?.selectedCoinPair}
                              marketCoinInfo={
                                orderHistoryReducer?.marketCoinInfo
                              }
                              onPress={(price, amount) => {
                                if (sellButtonSelected) {
                                  pickPriceFromBook(price, amount);
                                  setBtnOneSelected(false);
                                  setBtnTwoSelected(false);
                                  setBtnThreeSelected(false);
                                  setBtnFourSelected(false);
                                  setSelectedButton('0%');
                                }
                              }}
                            />
                          </View>
                        )}
                    </View>
                    <View
                      style={{
                        justifyContent: 'space-between',
                        flexDirection: 'row',
                        alignItems: 'center',
                      }}>
                      <View
                        style={{
                          width: '68%',
                          marginTop: 10,
                          alignItems: 'center',
                          marginLeft: 10,
                        }}>
                        <SelectDropdown
                          data={pricePrecision}
                          defaultValueByIndex={1}
                          onSelect={(selectedItem, index) => {
                            console.log(selectedItem, index);
                            setSelectedLimitedIndex(index);
                            setuserPricePrecision(selectedItem.value);
                          }}
                          buttonStyle={styles.dropdown3BtnStyle}
                          renderCustomizedButtonChild={(
                            selectedItem,
                            index,
                          ) => {
                            return (
                              <View
                                style={[
                                  styles.dropdown3BtnChildStyle,
                                  {
                                    backgroundColor:
                                      ThemeManager.colors.tabBackground,
                                  },
                                ]}>
                                <Text
                                  style={[
                                    styles.dropdown4BtnTxt,
                                    {
                                      color:
                                        ThemeManager.colors
                                          .anouncementtextColour,
                                    },
                                  ]}>
                                  {selectedItem
                                    ? selectedItem.title
                                    : '0.00001'}
                                </Text>
                                <Image
                                  source={{uri: Images.icon_dropDown}}
                                  style={{
                                    height: 15,
                                    width: 15,
                                    resizeMode: 'contain',
                                    tintColor:
                                      ThemeManager.colors.inactiveTextColor,

                                    // tintColor: 'black',
                                  }}
                                />
                              </View>
                            );
                          }}
                          dropdownStyle={[
                            styles.dropdown3DropdownStyle,
                            {
                              backgroundColor:
                                ThemeManager.colors.tabBackground,
                            },
                          ]}
                          rowStyle={[
                            styles.dropdown3RowStyle,
                            {
                              backgroundColor:
                                ThemeManager.colors.tabBackground,
                            },
                          ]}
                          renderCustomizedRowChild={(item, index) => {
                            return (
                              <View style={styles.dropdown3RowChildStyle}>
                                {/* <Image
                                source={item.image}
                                style={styles.dropdownRowImage}
                              /> */}
                                <Text
                                  style={[
                                    styles.dropdown4RowTxt,
                                    {
                                      color:
                                        selectedLimitedIndex === item.value
                                          ? ThemeManager.colors.Depositbtn
                                          : ThemeManager.colors.headTxt,
                                    },
                                  ]}>
                                  {item.title}
                                </Text>
                              </View>
                            );
                          }}
                        />
                      </View>
                      <TouchableOpacity
                        style={{
                          alignItems: 'center',
                          marginTop: 8,
                          height: 30,
                          width: 30,
                          marginLeft: 10,
                          justifyContent: 'center',
                          backgroundColor: ThemeManager.colors.tabBackground,
                        }}
                        onPress={() => {
                          ActionSheetBuySell.current.show();
                        }}>
                        <Image
                          source={{uri: Images.icon_buy_sell}}
                          style={{
                            height: 20,
                            width: 20,
                            resizeMode: 'contain',
                            tintColor:
                              ThemeManager.colors.themeColor === 'dark'
                                ? ThemeManager.colors.inactiveTextColor
                                : null,
                          }}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
              <View style={{flex: 1}}>
                <View
                  style={{
                    marginTop: 10,
                    flex: 1,
                    justifyContent: 'space-between',
                    flexDirection: 'row',
                    alignItems: 'center',
                    // backgroundColor: 'red',
                  }}>
                  <View
                    style={{
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                    }}>
                    <View
                      style={{
                        // marginHorizontal: 10,
                        marginTop: 20,
                        flexDirection: 'row',
                      }}>
                      <TouchableOpacity
                        onPress={() => {
                          setOpenOrderPageSelected(false);
                          // pagerRef2.current.setPage(0);
                        }}
                        style={{marginRight: 10}}>
                        <TradeHeader
                          title={strings.trade_tab.open_orders}
                          custmTabTxt={{
                            color: ThemeManager.colors.textColor,
                          }}
                          underLine={
                            openOrderPageSelected === false ? true : false
                          }
                        />
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => {
                          setOpenOrderPageSelected(true);
                          // alert('2');

                          // pagerRef2.current.setPage(1);
                        }}>
                        <TradeHeader
                          title={strings.trade_tab.funds}
                          custmTabTxt={{
                            color: ThemeManager.colors.textColor,
                          }}
                          underLine={
                            openOrderPageSelected === true ? true : false
                          }
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                  <TouchableOpacity
                    onPress={() => {
                      Actions.push('SpotTrade');
                    }}>
                    <Image
                      source={{uri: ThemeManager.ImageIcons.icon_note}}
                      style={{
                        height: 20,
                        width: 20,
                        resizeMode: 'contain',
                        tintColor: ThemeManager.colors.inactiveTextColor,
                      }}
                    />
                  </TouchableOpacity>
                </View>
                <BorderLine />
                {openOrderPageSelected === false ? (
                  <TradeOpenOrder />
                ) : (
                  <View style={{marginBottom: 20}}>
                    {fundsArray.map(item => {
                      return (
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            marginTop: 10,
                          }}>
                          <View
                            style={{
                              justifyContent: 'flex-start',
                              alignItems: 'center',
                              flexDirection: 'row',
                            }}>
                            <Image
                              style={{
                                height: 20,
                                width: 20,
                                borderRadius: 10,
                                resizeMode: 'contain',
                                // tintColor:
                                //   ThemeManager.colors.inactiveTextColor,
                              }}
                              source={{uri: Images.Home_Active}}
                            />
                            <View style={{alignItems: 'flex-start'}}>
                              <Text
                                style={{
                                  fontSize: 16,
                                  color: ThemeManager.colors.textColor,
                                  fontFamily: Fonts.regular,
                                  marginLeft: 10,
                                }}>
                                {item.currency.toUpperCase()}
                              </Text>
                              <Text
                                style={{
                                  fontSize: 12,
                                  color:
                                    ThemeManager.colors.anouncementtextColour,
                                  fontFamily: Fonts.regular,
                                  marginLeft: 10,
                                }}>
                                Full name
                              </Text>
                            </View>
                          </View>
                          <View>
                            <Text
                              style={{
                                fontSize: 16,
                                color: ThemeManager.colors.textColor,
                                fontFamily: Fonts.regular,
                              }}>
                              {item.balance}
                            </Text>
                            <View style={{alignItems: 'flex-end'}}>
                              <Text
                                style={{
                                  fontSize: 13,
                                  color: ThemeManager.colors.inactiveTextColor,
                                  fontFamily: Fonts.regular,
                                }}>
                                USD Price
                              </Text>
                            </View>
                          </View>
                        </View>
                      );
                    })}
                  </View>
                )}
              </View>
            </View>
          </View>
        </ScrollView>
        <ActionSheet
          ref={ActionSheetBuySell}
          // title={strings.profile.chooseBackUpoption}
          options={[
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: ThemeManager.colors.dashboardSearchBarBg,
                width: '100%',
                flex: 1,
                borderBottomWidth: 0.5,
                borderBottomColor: '#707988',
              }}>
              <Text
                style={{
                  color:
                    actionSheetBuySell === strings.buy_sell_market.default
                      ? ThemeManager.colors.selectedTextColor
                      : ThemeManager.colors.textColor1,
                }}>
                {strings.buy_sell_market.default}
              </Text>
            </View>,
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: ThemeManager.colors.dashboardSearchBarBg,
                width: '100%',
                flex: 1,

                borderBottomWidth: 0.5,
                borderBottomColor: '#707988',
              }}>
              <Text
                style={{
                  color:
                    actionSheetBuySell === strings.buy_sell_market.sell_order
                      ? ThemeManager.colors.selectedTextColor
                      : ThemeManager.colors.textColor1,
                }}>
                {strings.buy_sell_market.sell_order}
              </Text>
            </View>,

            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: ThemeManager.colors.dashboardSearchBarBg,
                width: '100%',
                flex: 1,
                borderBottomWidth: 0.5,
                borderBottomColor: '#707988',
              }}>
              <Text
                style={{
                  color:
                    actionSheetBuySell === strings.buy_sell_market.buy_order
                      ? ThemeManager.colors.selectedTextColor
                      : ThemeManager.colors.textColor1,
                }}>
                {strings.buy_sell_market.buy_order}
              </Text>
            </View>,
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: ThemeManager.colors.dashboardSearchBarBg,
                width: '100%',
                flex: 1,
              }}>
              <Text
                style={{
                  color: ThemeManager.colors.textColor1,
                }}>
                {strings.buy_sell_market.cancel}
              </Text>
            </View>,
          ]}
          cancelButtonIndex={3}
          styles={{
            messageBox: {height: '100'},
            body: {
              backgroundColor: ThemeManager.colors.dashboardSearchBarBg,
            },
            titleBox: {
              backgroundColor: '#2D2D2D',
            },
          }}
          tintColor={ThemeManager.colors.selectedTextColor}
          //destructiveButtonIndex={1}
          onPress={index => {
            if (index !== 3) {
              if (index === 0) {
                setShowBuyOrder(true);
                setShowSellOrder(true);
                setActionSheetBuySell(strings.buy_sell_market.default);
              } else if (index === 1) {
                setActionSheetBuySell(strings.buy_sell_market.sell_order);

                setShowBuyOrder(true);
                setShowSellOrder(false);
              } else if (index === 2) {
                setActionSheetBuySell(strings.buy_sell_market.buy_order);

                setShowBuyOrder(false);
                setShowSellOrder(true);
              }
            }
          }}
        />
        <ActionSheet
          ref={ActionSheetDepositTransfer}
          // title={strings.profile.chooseBackUpoption}
          options={[
            strings.buy_sell_market.deposit,
            // strings.buy_sell_market.transfer,

            strings.buy_sell_market.cancel,
          ]}
          cancelButtonIndex={1}
          //destructiveButtonIndex={1}
          onPress={index => {
            if (index !== 1) {
              if (index === 0) {
                const item = getClickedItem(
                  depositListReducer?.depositCoinListInfo,
                );
                console.log('deposit=--=item-=->>>>', item);

                Actions.DepositWallet({coin: item});
              } else if (index === 1) {
              }
            }
          }}
        />

        {isArrowClicked ? (
          <View
            style={{
              justifyContent: 'flex-end',
              backgroundColor: ThemeManager.colors.whiteScreen,
              paddingTop: 5,
            }}>
            <BorderLine />
            <View style={{marginTop: 10}} />
            <View
              style={{
                height: 200,
                flexDirection: 'row',
                justifyContent: 'space-between',
                // marginHorizontal: 15,
                backgroundColor: ThemeManager.colors.dashboardSubViewBg,
                paddingHorizontal: 15,
                // alignItems: 'center',
              }}>
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: Fonts.regular,
                  color: ThemeManager.colors.textColor,
                }}>
                {tradeReducer?.selectedCoinPair?.base_unit.toUpperCase()}/
                {tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase()}{' '}
                {strings.trade_tab.chart}
              </Text>
              <TouchableOpacity
                onPress={() => setArrowClicked(!isArrowClicked)}>
                <Image
                  source={{uri: Images.icon_image_down_light}}
                  style={{
                    height: 20,
                    width: 20,
                    resizeMode: 'contain',
                    tintColor: ThemeManager.colors.inactiveTextColor,
                  }}
                />
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View
            style={{
              justifyContent: 'flex-end',
              backgroundColor: ThemeManager.colors.whiteScreen,
            }}>
            <BorderLine />
            <View
              style={{
                height: 40,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                backgroundColor: ThemeManager.colors.dashboardSubViewBg,
                paddingHorizontal: 15,
                // marginHorizontal: 15,
              }}>
              <Text
                style={{
                  fontSize: 15,
                  fontFamily: fonts.regular,
                  color: ThemeManager.colors.textColor,
                }}>
                {tradeReducer?.selectedCoinPair?.base_unit.toUpperCase()}/
                {tradeReducer?.selectedCoinPair?.quote_unit.toUpperCase()}{' '}
                {strings.trade_tab.chart}
              </Text>
              <TouchableOpacity
                onPress={() => setArrowClicked(!isArrowClicked)}>
                <Image
                  source={{uri: Images.icon_arrow_up}}
                  style={{
                    height: 20,
                    width: 20,
                    resizeMode: 'contain',
                    tintColor: ThemeManager.colors.inactiveTextColor,
                  }}
                />
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* <PagerView
          ref={pagerRef}
          style={{flex: 1}}
          initialPage={1}
          scrollEnabled={false}
          onPageScroll={event => {
            // EventRegister.emit('clearData', '');
          }}
          onPageSelected={event => {
            // setSelectedPage(event.nativeEvent.position);
            setSpotPageSelected(event.nativeEvent.position);
          }}>
          <View key="1" style={{flex: 1}}>
            <Text>Email</Text>
          </View>
           </PagerView> */}

        {/* <PagerView style={{flex: 1}} initialPage={0}>
          <View key="1" style={{flex: 1, backgroundColor: 'red'}}>
            <Text>First page</Text>
          </View>
          <View key="2" style={{flex: 1, backgroundColor: 'yellow'}}>
            <Text>Second page</Text>
          </View>
        </PagerView> */}
      </View>
      <Loader isLoading={tradeReducer?.isLoading} />
      <TradingRules
        closePress={() => {
          setShowRules(!isShowRules);
        }}
        isRuleShow={isShowRules}
        tradeRule={tradeReducer?.tradeFees}
        tradingFees={tradeReducer?.tradeRule}
      />
      <Modal
        animationType="fade"
        transparent={true}
        visible={pairModelVisible}
        onRequestClose={() => {
          setPairModal(false);
        }}>
        <Wrap
          style={{backgroundColor: 'rgba(0,0,0,0.5)'}}
          screenStyle={[styles.screenStyle, {backgroundColor: 'transparent'}]}
          bottomStyle={{backgroundColor: ThemeManager.colors.DashboardBG}}>
          <View
            style={{
              backgroundColor: 'rgba(255,255,255,0.1)',
              flex: 1,
              justifyContent: 'flex-end',
            }}>
            <TouchableOpacity
              style={{flex: 1}}
              onPress={() => {
                setPairModal(false);
              }}></TouchableOpacity>
            <View
              style={{
                backgroundColor: ThemeManager.colors.whiteScreen,

                borderTopRightRadius: 15,
                borderTopLeftRadius: 15,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginHorizontal: 15,
                  marginVertical: 15,
                }}>
                <View style={{width: 40}} />
                <Text
                  style={{
                    fontSize: 16,
                    fontFamily: Fonts.regular,
                    color: ThemeManager.colors.textColor,
                    // marginHorizontal: 25,
                  }}>
                  {'Select Pair'}
                </Text>
                <TouchableOpacity
                  onPress={() => {
                    setPairModal(false);
                  }}>
                  <Image
                    source={{uri: Images.icon_cancel_light}}
                    style={{
                      height: 20,
                      width: 20,
                      resizeMode: 'contain',
                      // marginRight: 15,
                    }}
                  />
                </TouchableOpacity>
              </View>
              <FlatList
                data={props.marketData}
                renderItem={({item}) => {
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        // this.props.stopPreviousConnection().then(res => {
                        //   setPairModal(false);
                        //   let pairValue = item.base_unit + item.quote_unit;
                        //   this.resetData(1);
                        //   // this.tradeRuleFunction(pairValue);
                        //   this.tradeFeesFun(pairValue);
                        //   this.updateSocket(pairValue, item?.name);
                        //   this.props.tradeValuesUpdate({
                        //     prop: 'selectedCoinPair',
                        //     value: item,
                        //   });
                        //   this.getUserBalance(
                        //     this.props.selectedCoinPair.quote_unit,
                        //   );
                        //   this.props.tradeValuesUpdate({
                        //     prop: 'publicTrade',
                        //     value: [],
                        //   });
                        //   setTimeout(() => {
                        //     this.getSavedFav();
                        //     this.openOderDetails(true);
                        //   }, 100);
                        //   setTimeout(() => {
                        //     this.props.getPublicTrade(
                        //       this.props.selectedCoinPair.base_unit +
                        //         this.props.selectedCoinPair.quote_unit,
                        //     );
                        //     this.getFundList();
                        //   }, 1000);
                        // });
                      }}>
                      <View
                        style={{
                          width: '100%',
                          height: 40,
                          justifyContent: 'center',
                        }}>
                        <Text
                          style={{
                            color: ThemeManager.colors.textColor,
                            fontSize: 18,
                            textAlign: 'center',
                            fontFamily: Fonts.bold,
                          }}>
                          {item.name}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
              />
            </View>
          </View>
        </Wrap>
      </Modal>
    </Wrap>
  );
};

Trades.navigationOptions = ({navigation}) => {
  // console.log(Utils.testVariable);
  return {
    header: null,
    tabBarLabel: ' ',
    tabBarIcon: ({focused}) => (
      <TabIcon
        focused={focused}
        title={strings.bottom_tab.Trades}
        ImgSize={{width: 19.8, height: 20}}
        activeImg={{uri: Images.Trades_Active}}
        defaultImg={{uri: Images.Trades_InActive}}
      />
    ),
    tabBarOptions: {
      style: {
        backgroundColor: ThemeManager.colors.tabBackground,
        // bottom: 5,
      },
    },
  };
};
export default Trades;
