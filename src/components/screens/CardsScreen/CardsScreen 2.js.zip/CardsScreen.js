/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from "react";
import {
  Text,
  TouchableOpacity,
  View,
  Image,
  ScrollView,
  TextInput,
  Alert,
  AppState,
  FlatList,
  RefreshControl,
  StyleSheet,
  Modal,
  Dimensions,
} from "react-native";

import { Wrap } from "../../common/Wrap";
import { ThemeManager } from "../../../../ThemeManager";
import TradeHeader from "../../common/TradeHeader";
import { strings } from "../../../../Localization";
import { Fonts, Images } from "../../../theme";
import BorderLine from "../../common/BorderLine";
import { Actions } from "react-native-router-flux";
import Singleton from "../../../Singleton";
import { ButtonPrimary, TabIcon, Loader } from "../../common";
import { useDispatch, useSelector } from "react-redux";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scrollview";
import {
  getCardHolderDetails,
  getProfile1,
  getCheckDocumentSumSubDetails,
  getCardBindAction,
  getCardFees,
  getCurrencyDetails,
  getCurrencyConversionDetails,
  cardCostCheckAction,
  getCardList,
} from "../../../Redux/Actions";
import * as constants from "../../../Constants";
import { EventRegister } from "react-native-event-listeners";
import LinearGradient from "react-native-linear-gradient";
import LottieView from "lottie-react-native";

const { height, width } = Dimensions.get("window");

//view component
const ManageView = ({ icon, text, viewStyle }) => {
  const styles = useStyles(ThemeManager);
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: ThemeManager.colors.tabBackground,
        flex: 1,
      }}
    >
      <View
        style={[
          styles.recentView,
          {
            flexDirection: "row",
            justifyContent: "flex-start",
            alignItems: "center",
            marginTop: 0,
          },
          viewStyle,
        ]}
      >
        <Image
          style={{
            height: 18,
            width: 18,
            resizeMode: "contain",
            tintColor: ThemeManager.colors.textColor,
            marginRight: 10,
          }}
          source={{ uri: icon }}
        />
        <Text
          style={[styles.recentText, { color: ThemeManager.colors.headerText }]}
        >
          {text}
        </Text>
      </View>
      <Image
        source={{ uri: ThemeManager.ImageIcons.icon_forward }}
        style={{
          height: 20,
          width: 20,
          resizeMode: "contain",
          marginRight: 15,
        }}
      />
    </View>
  );
};
const CardsScreen = (props) => {
  const dispatch = useDispatch();
  const styles = useStyles(ThemeManager);
  const { isCardHolderLoading, cardHolderError, cardHolderInfo } = useSelector(
    (state) => state.cardHolderDetailsReducer
  );
  const { checkDocumentError, checkDocumentInfo, isCheckDocumentLoading } =
    useSelector((state) => state.cardCheckDocumentReducer);
  const [kycStatus, setKycStatus] = useState(false);
  const [isProfileFilled, setIsProfileFilled] = useState(false);
  const [userData, setuserData] = useState({});
  const [address, setAddress] = useState("");
  const { currentTheme, currentLanguage } = useSelector(
    (state) => state.AuthReducer
  );
  const { isCardBindLoading, cardBindError, cardBindInfo } = useSelector(
    (state) => state.cardBindReducer
  );
  const { cardFeesInfo, cardFeesError, isCardFeesLoading } = useSelector(
    (state) => state.cardFeesReducer
  );
  console.log("cardFeesInfo=-=-=>>", cardFeesInfo);
  console.log("cardBindInfo=-=-=>>", cardBindInfo);

  const [countryCode, setCountryCode] = useState("");
  const [eaa, setEaa] = useState(false);
  const [loader, setLoader] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalCostVisible, setModalCostVisible] = useState(false);
  const [infoUploaded, setInfoUploaded] = useState(false);
  const [buttonChange, setButtonChange] = useState(false);
  const { currencyDetailsLoading, currencyDetails } = useSelector(
    (state) => state?.withDetails
  );
  const [viewDashboard, setViewDashboard] = useState(false);
  const getProfileData = () => {
    setLoader(true);
    dispatch(getProfile1())
      .then((res) => {
        console.log("getProfileInfo=-=-=res-=->>", res);
        getProfileInfo();
      })
      .catch((err) => console.log("getProfileInfo=-=-=err-=->>", err));
  };
  useEffect(() => {
    getProfileData();
    let coinName = "usdt";
    dispatch(getCurrencyDetails({ coinName }));
    props.navigation.addListener("didFocus", () => {
      getProfileData();
      dispatch(getCurrencyDetails({ coinName }));
    });
  }, []);
  const getUserCardDetails = () => {
    if (kycStatus) {
      dispatch(getCardHolderDetails())
        .then((response) => {
          console.log("----getCardHolderDetails-22 res-->", response);

          if (
            response?.description == "Selfie upload successfully" &&
            response?.audit_status == "under_review"
          ) {
            setLoader(false);
            setInfoUploaded(true);
            setModalVisible(true);
          } else if (response?.audit_status == "activation_successful") {
            setInfoUploaded(false);

            dispatch(getCardBindAction())
              .then((resp) => {
                console.log("getCardBindAction=-=-=---resp", resp);
                if (resp != null) {
                  if (resp?.next_charge_on == null) {
                    console.log(
                      "getCardBindAction=-=-=---resp.fee_status",
                      resp?.fee_status
                    );
                    getCardFeeList();
                  } else if (
                    resp?.fee_status == "paid" &&
                    resp?.next_charge_on
                  ) {
                    Actions.currentScene != "CardInitial" &&
                      Actions.push("CardInitial");
                  }
                }
              })
              .catch((err) => {
                console.log("getCardBindAction=-=-=---err", err);
                Singleton.getInstance().showError(err);
              });
            //
          } else {
            setModalVisible(false);
            Actions.currentScene != "UserDetails" &&
              Actions.push("UserDetails");
            // Actions.currentScene != "UploadFiles" &&
            //   Actions.push("UploadFiles");
          }
        })
        .catch((err) => {
          console.log("----getCardHolderDetails-22 err-->", err);
        });
      // Actions.currentScene != "UploadFiles" && Actions.push("UploadFiles");
    } else {
      Alert.alert(
        constants.APP_NAME,
        "KYC is not verified. Please verify your KYC before moving further."
      );
    }
  };
  const getUserDetails = () => {
    dispatch(getCardHolderDetails())
      .then((response) => {
        console.log("----getCardHolderDetails-44 res-->", response);

        if (
          response?.description == "Selfie upload successfully" &&
          response?.audit_status == "under_review"
        ) {
          setLoader(false);
          setInfoUploaded(true);
          setModalVisible(true);
        } else if (response?.audit_status == "activation_successful") {
          setInfoUploaded(true);

          setModalVisible(false);

          dispatch(getCardBindAction())
            .then((resp) => {
              console.log("getCardBindAction=-=-=---resp", resp);
              if (resp != null) {
                if (resp?.next_charge_on == null) {
                  console.log(
                    "getCardBindAction=-=-=---resp.fee_status",
                    resp?.fee_status
                  );
                  getCardFeeList();
                } else if (
                  resp?.fee_status == "paid" &&
                  resp?.next_charge_on &&
                  resp?.card_verify != true
                ) {
                  Actions.currentScene != "CardInitial" &&
                    Actions.push("CardInitial");
                } else {
                  setViewDashboard(true);
                  // Actions.currentScene != "ActivatedCards" &&
                  //   Actions.push("ActivatedCards");
                }
              }
            })
            .catch((err) => {
              console.log("getCardBindAction=-=-=---err", err);
              Singleton.getInstance().showError(err);
            });
          // dispatch(getCardBindAction())
          //   .then((resp) => {
          //     console.log("getCardBindAction=-=-=---resp", resp);
          //     if (resp.next_charge_on == null) {
          //       console.log(
          //         "getCardBindAction=-=-=---resp.fee_status",
          //         resp.fee_status
          //       );
          //       getCardFeeList();
          //     }
          //   })
          //   .catch((err) => {
          //     console.log("getCardBindAction=-=-=---err", err);
          //     Singleton.getInstance().showError(err);
          //   });
        } else {
          setInfoUploaded(false);
          setLoader(false);
          setModalVisible(false);
          // Actions.currentScene != "UserDetails" &&
          //   Actions.push("UserDetails");
        }
      })
      .catch((err) => {
        setLoader(false);
        setModalVisible(false);
        console.log("----getCardHolderDetails-44err-->", err);
      });
    // Actions.currentScene != "UploadFiles" && Actions.push("UploadFiles");
  };
  const getCardFeeList = () => {
    console.log("hit get card list=--=");
    dispatch(getCardFees())
      .then((res) => {
        console.log("card fees list=-=-=-=-res", res);
        setModalCostVisible(true);
        setInfoUploaded(false);
        setButtonChange(true);
        setLoader(false);
      })
      .catch((err) => {
        console.log("card fees list=-=-=-=-err", err);
        setLoader(false);
      });
  };
  const getProfileInfo = () => {
    console.log("getProfileInfo=-=-=>>");
    Singleton.getInstance()
      .getData(constants.USER_DATA)
      .then(async (res) => {
        setuserData(JSON.parse(res));
        let userData = JSON.parse(res);

        console.log("userdata=-=-=-=---profile=-=>", JSON.parse(res));
        // setKycPending(userData?.kyc_panding);
        if (JSON.parse(res)?.level == 2 || JSON.parse(res)?.level == 1) {
          // setIsDocumentVerified(true);
          setKycStatus(false);
        } else if (JSON.parse(res)?.level == 3) {
          setKycStatus(true);
          getUserDetails();
          // setIsDocumentVerified(true);
        }

        if (JSON.parse(res)?.profiles[0]?.gender != null) {
          setIsProfileFilled(true);
          let pro = JSON.parse(res)?.profiles[0];
          let firstName = pro?.first_name;
          let lastName = pro?.last_name;
          let addr = pro?.address;
          let city = pro?.city;
          let postcode = pro?.postcode;
          let country = pro?.country;
          setCountryCode(country);
          let fullAddress = `${firstName} ${lastName} \n${addr} \n${city} ${postcode}`;
          setAddress(fullAddress);
          // getUserDetails();
          console.log("user profile=-=gender>55");
          setLoader(false);
        } else {
          setIsProfileFilled(false);
          console.log("user profile=-=gender>66");
        }
      })
      .catch((err) => {
        console.log("----value- err-->", err);
      });
  };
  const onButtonPress = () => {
    // Actions.currentScene != "CardInitial" && Actions.push("CardInitial");
    getUserCardDetails();
  };
  const onClickConfirm = () => {
    // setModalCostVisible(false);
    console.log(
      "balance check=-=->>>",
      parseFloat(currencyDetails?.balance) >= parseFloat(cardFeesInfo?.fee)
    );
    if (parseFloat(currencyDetails?.balance) >= parseFloat(cardFeesInfo?.fee)) {
      dispatch(cardCostCheckAction(cardBindInfo?.card_number))
        .then((res) => {
          // console.log("card_number-----card cost-", res);
          setModalCostVisible(false);
          Actions.currentScene != "CardInitial" && Actions.push("CardInitial");
        })
        .catch((err) => {
          console.log("card_number-----card cost-err", err);
        });
    } else {
    }
  };
  return (
    <Wrap
      style={{ backgroundColor: ThemeManager.colors.DashboardBG }}
      screenStyle={[
        styles.screenStyle,
        { backgroundColor: ThemeManager.colors.DashboardBG },
      ]}
      darkMode={ThemeManager.colors.themeColor === "light" ? false : true}
      bottomStyle={{ backgroundColor: ThemeManager.colors.DashboardBG }}
    >
      {infoUploaded ? (
        <View>
          <Loader
            isLoading={loader || isCardBindLoading || isCardFeesLoading}
          />
        </View>
      ) : (
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="handled"
          nestedScrollEnabled={true}
          // style={{flex: 1}}
          contentContainerStyle={{ flex: 1 }}
        >
          <View style={styles.mainContainer}>
            <Text style={styles.moreText}>
              {strings.cardScreen.there_s_more}
            </Text>
            <Text style={styles.classyText}>
              {strings.cardScreen.obtain_a_classy}
            </Text>
            <Image
              source={{ uri: Images.cardBanner }}
              style={styles.bannerStyle}
            />
            {/* <Text style={styles.shippingText}>
              {strings.cardScreen.shipping_address}
            </Text>
            <View style={styles.addressViewStyle}>
              <Text style={styles.shippingText}>{address}</Text>
            </View> */}
          </View>
          <ButtonPrimary
            style={{ marginBottom: 50 }}
            title={
              buttonChange
                ? strings.cardScreen.pay_your_card_cost
                : strings.enterAccountDetails.applyForYourPhysicalCard
            }
            onPress={() => {
              onButtonPress();
            }}
          />
          <Loader
            isLoading={loader || isCardBindLoading || isCardFeesLoading}
          />
        </KeyboardAwareScrollView>
      )}

      {/* <Modal
        animationType="Slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(false);
        }}
      > */}
      {modalVisible && (
        <View
          style={{ position: "absolute", top: 0, bottom: 0, left: 0, right: 0 }}
        >
          <Wrap
            style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
            screenStyle={[
              styles.screenStyle,
              { backgroundColor: "transparent" },
            ]}
            bottomStyle={{ backgroundColor: ThemeManager.colors.DashboardBG }}
          >
            <View
              style={{
                backgroundColor: "rgba(255,255,255,0.1)",
                flex: 1,
                justifyContent: "center",
              }}
            >
              <TouchableOpacity
                style={{ flex: 1 }}
                onPress={() => {
                  // setModalVisible(false);
                  // getUserCardDetails();
                }}
              ></TouchableOpacity>
              <View style={{ justifyContent: "center", alignItems: "center" }}>
                <View
                  style={{
                    //   height: 200,
                    width: width - 60,
                    backgroundColor: ThemeManager.colors.modalBg,
                    alignItems: "center",
                    borderRadius: 8,
                  }}
                >
                  <LottieView
                    style={{ height: 100, width: 100 }}
                    source={Images.timerLottie}
                    autoPlay
                    loop={false}
                  />
                  <Text
                    style={{
                      color: ThemeManager.colors.modalTitle,
                      fontSize: 16,
                      fontFamily: Fonts.regular,
                    }}
                  >
                    {strings.cardScreen.verificationPending}
                  </Text>
                  <Text
                    style={{
                      color: ThemeManager.colors.modalTitle1,
                      fontSize: 14,
                      fontFamily: Fonts.light,
                      textAlign: "center",
                      margin: 10,
                    }}
                  >
                    {strings.cardScreen.thankYou}
                  </Text>
                  <ButtonPrimary
                    title={strings.cardScreen.ok}
                    style={{
                      height: 50,
                      marginVertical: 20,
                      width: "100%",
                      backgroundColor: ThemeManager.colors.selectedTextColor,
                      borderRadius: 4,
                    }}
                    textstyle={{ paddingHorizontal: 50 }}
                    onPress={() => {
                      // setModalVisible(false);
                      // Actions.pop();
                      // getUserCardDetails();
                      Actions.currentScene != "Main" && Actions.Main();
                    }}
                  />
                </View>
              </View>

              <TouchableOpacity
                style={{ flex: 1 }}
                onPress={() => {
                  // setModalVisible(false);
                  // getUserCardDetails();
                }}
              ></TouchableOpacity>
            </View>
          </Wrap>
        </View>
      )}
      {/* </Modal> */}
      <Modal
        animationType="Slide"
        transparent={true}
        visible={modalCostVisible}
        onRequestClose={() => {
          setModalCostVisible(false);
        }}
      >
        <Wrap
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
          screenStyle={[styles.screenStyle, { backgroundColor: "transparent" }]}
          bottomStyle={{ backgroundColor: ThemeManager.colors.DashboardBG }}
        >
          <View
            style={{
              backgroundColor: "rgba(255,255,255,0.1)",
              flex: 1,
              justifyContent: "center",
            }}
          >
            <TouchableOpacity
              style={{ flex: 1 }}
              onPress={() => {
                setModalCostVisible(false);
              }}
            ></TouchableOpacity>
            <View style={{ justifyContent: "center", alignItems: "center" }}>
              <View
                style={{
                  //   height: 200,
                  width: width,
                  backgroundColor: ThemeManager.colors.modalBg,
                  // alignItems: "center",
                  borderRadius: 8,
                }}
              >
                <View
                  style={{
                    justifyContent: "space-between",
                    flexDirection: "row",
                    alignItems: "center",
                    width: width,
                  }}
                >
                  <Image
                    // source={{ uri: ThemeManager.ImageIcons.icon_close_main }}
                    style={{ height: 20, width: 20, resizeMode: "contain" }}
                  />
                  <Text
                    style={{
                      color: ThemeManager.colors.modalTitle,
                      fontSize: 16,
                      fontFamily: Fonts.regular,
                      marginTop: 15,
                    }}
                  >
                    {strings.cardScreen.cardCost}
                  </Text>
                  <TouchableOpacity
                    style={{
                      height: 30,
                      width: 30,
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                    onPress={() => {
                      setModalCostVisible(false);
                    }}
                  >
                    <Image
                      source={{ uri: ThemeManager.ImageIcons.icon_close_main }}
                      style={{
                        height: 20,
                        width: 20,
                        resizeMode: "contain",
                        marginRight: 15,
                        marginTop: 10,
                      }}
                    />
                  </TouchableOpacity>
                </View>
                <BorderLine style={{ width: width, marginVertical: 10 }} />
                <View style={{ marginHorizontal: 15 }}>
                  <Text
                    style={{
                      color: ThemeManager.colors.modalTitle1,
                      fontSize: 16,
                      fontFamily: Fonts.medium,
                    }}
                  >
                    {"USDT Wallet"}
                  </Text>
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor,
                      fontSize: 15,
                      fontFamily: Fonts.regular,
                    }}
                  >
                    {strings.cardScreen.balance}{" "}
                    {currencyDetails?.balance
                      ? parseFloat(currencyDetails?.balance)
                      : 0}
                  </Text>
                </View>
                <BorderLine style={{ width: width, marginVertical: 10 }} />
                <Text style={[styles.shippingText, { marginHorizontal: 15 }]}>
                  {strings.cardScreen.shipping_address}
                </Text>
                <View style={styles.addressViewStyle}>
                  <Text style={styles.shippingText}>{address}</Text>
                </View>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    width: width,
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.modalTitle1,
                      fontSize: 14,
                      fontFamily: Fonts.light,
                      textAlign: "center",
                      // margin: 10,
                      width: width / 2 - 30,
                    }}
                  >
                    {strings.cardScreen.amount}:
                    <Text
                      style={{
                        color: ThemeManager.colors.textColor,
                        fontFamily: Fonts.medium,
                      }}
                    >
                      {" $"}
                      {cardFeesInfo?.fee}
                    </Text>
                  </Text>

                  <ButtonPrimary
                    title={strings.cardScreen.confirm}
                    style={{
                      height: 50,
                      marginVertical: 20,
                      marginRight: 10,
                      width: width / 2 - 30,
                      backgroundColor: ThemeManager.colors.selectedTextColor,
                      borderRadius: 4,
                    }}
                    textstyle={{ paddingHorizontal: 10 }}
                    onPress={() => {
                      onClickConfirm();
                    }}
                  />
                  {<Loader isLoading={currencyDetailsLoading} />}
                </View>
              </View>
            </View>
          </View>
        </Wrap>
      </Modal>
    </Wrap>
  );
};

export default CardsScreen;

const useStyles = (theme) =>
  StyleSheet.create({
    mainContainer: { flex: 1, marginTop: 20, marginHorizontal: 15 },
    moreText: { color: ThemeManager.colors.textColor, fontSize: 25 },
    classyText: {
      color: ThemeManager.colors.headerText,
      fontSize: 14,
      marginTop: 10,
    },
    bannerStyle: {
      width: "100%",
      height: 180,
      resizeMode: "cover",
      marginTop: 20,
      borderRadius: 6,
    },
    shippingText: {
      color: ThemeManager.colors.headerText,
      fontSize: 14,
      marginTop: 5,
    },
    addressViewStyle: {
      backgroundColor: ThemeManager.colors.tabBackground,
      padding: 15,
      marginVertical: 15,
      borderRadius: 6,
      minHeight: 150,
      marginHorizontal: 15,
    },
  });
