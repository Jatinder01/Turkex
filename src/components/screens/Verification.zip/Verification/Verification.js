/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {
  Text,
  SafeAreaView,
  Modal,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import {View} from 'native-base';
import {ThemeManager} from '../../../../ThemeManager';
import {Fonts, Images, colors} from '../../../theme';
import fonts from '../../../theme/fonts';
import styles from './VerificationStyle';
import {InputField, ButtonPrimary, Header, Wrap, Loader} from '../../common';
import * as constants from '../../../Constants';
import Moment from 'moment';
import SNSMobileSDK from '@sumsub/react-native-mobilesdk-module';
import {Actions} from 'react-native-router-flux';
import {strings} from '../../../../Localization';
import {FlatList, ScrollView, TextInput} from 'react-native-gesture-handler';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scrollview';
import {useDispatch, useSelector} from 'react-redux';
import {countryFlags} from '../../common/CountryFlags';
import {
  kycFirstFormUpdate,
  submitKycDetails,
  resetKYCForm,
  getSumSubToken,
  updateSumSubApplicantId,
} from '../../../Redux/Actions';
import Singleton from '../../../Singleton';
import END_POINT from '../../../EndPoints';
import DatePicker from 'react-native-date-picker';
// import moment from 'moment';
import {color} from 'react-native-reanimated';

const Verification = props => {
  const dispatch = useDispatch();
  const kycFirst = useSelector(state => state.kycFirst);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('Select Country');
  const [selectedDob, setSelectedDob] = useState('DD/MM/YYYY');

  const [countryData, setCountryData] = useState(countryFlags);
  const [searchData, setSearchData] = useState(countryFlags);
  const [userData, setuserData] = useState(null);
  const [resubmit, setresubmit] = useState(false);
  const [isUpdate, setisUpdate] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  useEffect(() => {
    Singleton.getInstance()
      .getData(constants.USER_DATA)
      .then(res => {
        if (res != null && JSON.parse(res).profile != null) {
          let uData = JSON.parse(res);

          setuserData(uData);

          uData.labels.filter(item => {
            if (item.value == 'pending' && item.key == 'document') {
              setresubmit(true);
            }
          });
          if (uData.profile?.country) {
            let countryData = countryFlags.find(
              res => res?.countryCode == uData.profile?.country,
            );

            dispatch(
              kycFirstFormUpdate({
                prop: 'kycCountry',
                value: countryData.countryNameEn,
              }),
            );
          }
          setisUpdate(true);
          dispatch(kycFirstFormUpdate({prop: 'kycError', value: ''}));
          dispatch(
            kycFirstFormUpdate({
              prop: 'kycFirstName',
              value: JSON.parse(res).profile.first_name,
            }),
          );
          dispatch(kycFirstFormUpdate({prop: 'kycLoading', value: false}));
          dispatch(
            kycFirstFormUpdate({
              prop: 'kycMiddleName',
              value: JSON.parse(res).profile.middle_name,
            }),
          );
          dispatch(
            kycFirstFormUpdate({
              prop: 'kycLastName',
              value: JSON.parse(res).profile.last_name,
            }),
          );
          dispatch(
            kycFirstFormUpdate({
              prop: 'kycDob',
              value: JSON.parse(res).profile.dob,
            }),
          );
          dispatch(
            kycFirstFormUpdate({
              prop: 'kycCountryId',
              value: JSON.parse(res).profile.country,
            }),
          );
        } else {
          setisUpdate(false);
        }
      });
  }, []);

  const onSearch = value => {
    setCountryData(
      searchData.filter(
        i =>
          i.countryNameEn.toLowerCase().includes(value.toLowerCase()) ||
          i.countryCallingCode.toLowerCase().includes(value.toLowerCase()),
      ),
    );
  };
  const renderError = () => {
    if (kycFirst.kycError) {
      return (
        <View>
          <Text style={styles.errorMessageStyle}>
            {capitalize(kycFirst.kycError)}
          </Text>
        </View>
      );
    }
  };
  const capitalize = s => {
    if (typeof s !== 'string') return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
  };

  const dobButtonClicked = () => {
    let value = true;
    dispatch(kycFirstFormUpdate({prop: 'KycShowDatePicker', value}));
  };
  const renderDatePicker = () => {
    var date1 = new Date();
    date1.setFullYear(date1.getFullYear() - 18);
    return (
      <DatePicker
        modal
        fadeToColor="white"
        open={showDatePicker}
        mode="date"
        date={date1}
        maximumDate={date1}
        theme={ThemeManager.colors.themeColor === 'dark' ? 'dark' : 'light'}
        textColor={ThemeManager.colors.textColor1}
        onConfirm={date => {
          let value = Moment(date).format('DD-MM-YYYY');
          dispatch(kycFirstFormUpdate({prop: 'kycDob', value}));
          dispatch(kycFirstFormUpdate({prop: 'kycLoading', value: false}));
          setShowDatePicker(false);
        }}
        onCancel={() => {
          setShowDatePicker(false);
          dispatch(kycFirstFormUpdate({prop: 'kycLoading', value: false}));
        }}
      />
    );
  };

  const submitButtonClicked = () => {
    dispatch(kycFirstFormUpdate({prop: 'kycLoading', value: false}));

    const {
      kycFirstName,
      kycGender,
      kycMiddleName,
      kycLastName,
      kycDob,
      kycCountry,
      kycCountryId,
      kycZip,
      kycCity,
      KycShowDatePicker,
      kycAddress,
    } = kycFirst;

    let param = {
      kycFirstName: kycFirstName,
      kycGender: kycGender,
      kycMiddleName: kycMiddleName,
      kycLastName: kycLastName,
      kycDob: kycDob,
      kycCountry: kycCountry,
      kycCountryId: kycCountryId,
      kycZip: kycZip,
      kycCity: kycCity,
      kycAddress: kycAddress,
    };
    Singleton.getInstance().saveData(
      constants.VERIFY_INFO_STEP,
      JSON.stringify(param),
    );
    console.log('verification params', param);
    let isEdit = isUpdate;
    dispatch(
      submitKycDetails({
        kycFirstName,
        kycGender,
        kycMiddleName,
        kycLastName,
        kycDob,
        kycCountry,
        kycCountryId,
        kycZip,
        kycCity,
        KycShowDatePicker,
        isEdit,
        kycAddress,
      }),
    )
      .then(res => {
        setisUpdate(true);
        // console.log('RESPONSE-----', res?.token);
        dispatch(getSumSubToken())
          .then(res => {
            console.log('RESPONSE-----', res);
            //_act-b1bb0a12-1e3e-4c34-b2b6-2c036a5b0426
            renderSumSub(res?.token);
          })
          .catch(err => {
            console.log('ERR----', err);
          });
      })
      .catch(err => {
        console.log('ERR_PROFILE----', err, isEdit);
      });
  };

  function renderSumSub(accessToken) {
    console.log('dsa======', accessToken);
    let apiUrl = 'https://api.sumsub.com';
    // let apiUrl = 'https://test-api.sumsub.com';
    // or https://api.sumsub.com
    let flowName = 'msdk-basic-kyc';
    // or set up your own with the dashboard
    let snsMobileSDK = SNSMobileSDK.Builder(apiUrl)
      .withAccessToken(accessToken, () => {
        return Singleton.getInstance()
          .getData(constants.ACCESS_TOKEN)
          .then(res => {
            fetch(END_POINT.BASE_URL + END_POINT.GET_SUM_SUB_TOKEN, {
              method: 'GET',
              headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                Authorization: res,
              },
            }).then(resp => {
              return resp.token;
            });
          });
      })
      .withHandlers({
        // Optional callbacks you can use to get notified of the corresponding events
        onStatusChanged: event => {
          console.log(
            'onStatusChanged11: [' +
              event.prevStatus +
              '] => [' +
              event.newStatus +
              ']',
          );
        },
        onLog: event => {
          console.log('onLog:' + event.message);
          if (event.message.includes('SDK is prepared. Applicant - ')) {
            var applicantId = event.message.replace(
              'SDK is prepared. Applicant - ',
              '',
            );
            //  console.log("Sd===========", dd)
            dispatch(updateSumSubApplicantId(applicantId));
          }
        },
        onEvent: event => {
          console.log('onEvent111: ' + JSON.stringify(event));
        },
      })
      .withDebug(true)
      .withLocale('en') // Optional, for cases when you need to override system locale
      .build();

    snsMobileSDK
      .launch()
      .then(result => {
        console.log('SumSub SDK State111: ' + JSON.stringify(result));
      })
      .catch(err => {
        console.log('SumSub SDK Error011: ', err);
      });
  }

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: ThemeManager.colors.DashboardBG,
      }}>
      <View style={{justifyContent: 'space-between', flex: 1}}>
        <View>
          <Header
            mainView={{paddingHorizontal: 16}}
            customCenterTitle={{fontSize: 18}}
            leftImage={{uri: Images.icon_back}}
            titleCenter="Verification"
            btnTextLeft=" "
            btnTextRight=" "
            leftButtonClicked={() => {
              Actions.pop();
            }}
          />
          <Text style={styles.inputTitle}>First Name</Text>
          <InputField
            editable={true}
            value={kycFirst.kycFirstName}
            title="Enter First name"
            onChangeText={text => {
              if (/^[a-zA-Z]+$/.test(text) || text == '') {
                let value = text;
                dispatch(
                  kycFirstFormUpdate({
                    prop: 'kycFirstName',
                    value,
                  }),
                );
              } else {
                // Alert.alert(
                //   constants.APP_NAME,
                //   'First name accept only alphabets.',
                // );
                Singleton.getInstance().showError(
                  'First name accept only alphabets.',
                );
              }
            }}
            maxlength={100}
          />
          <Text style={styles.inputTitle}>Middle Name</Text>
          <InputField
            editable={true}
            value={kycFirst.kycMiddleName}
            title="Enter Middle name"
            onChangeText={text => {
              if (/^[a-zA-Z]+$/.test(text) || text == '') {
                let value = text;
                dispatch(
                  kycFirstFormUpdate({
                    prop: 'kycMiddleName',
                    value,
                  }),
                );
              } else {
                // Alert.alert(
                //   constants.APP_NAME,
                //   'Middle name accept only alphabets.',
                // );
                Singleton.getInstance().showError(
                  'Middle name accept only alphabets.',
                );
              }
            }}
            maxlength={100}
          />
          <Text style={styles.inputTitle}>Last Name</Text>
          <InputField
            editable={true}
            title="Enter last name"
            value={kycFirst.kycLastName}
            onChangeText={text => {
              if (/^[a-zA-Z]+$/.test(text) || text == '') {
                let value = text;
                dispatch(kycFirstFormUpdate({prop: 'kycLastName', value}));
              } else {
                // Alert.alert(
                //   constants.APP_NAME,
                //   'Last name accept only alphabets.',
                // );
                Singleton.getInstance().showError(
                  'Last name accept only alphabets.',
                );
              }
            }}
            maxlength={100}
          />
          <Text style={styles.inputTitle}>Date of birth</Text>
          <InputField
            editable={false}
            value={kycFirst.kycDob}
            image={{uri: Images.icon_selectCountry_RightArrow}}
            rightImageStyle={{resizeMode: 'contain'}}
            Next={() => {
              setShowDatePicker(true);
              dobButtonClicked();
            }}
          />
          <Text style={styles.inputTitle}>Country</Text>
          <InputField
            editable={false}
            title={'Select Country'}
            value={kycFirst.kycCountry ? kycFirst.kycCountry : 'Select Country'}
            image={{uri: Images.icon_selectCountry_RightArrow}}
            rightImageStyle={{resizeMode: 'contain'}}
            Next={() => {
              setModalVisible(true);
            }}
          />
        </View>
        {renderError()}
        <View style>
          <ButtonPrimary
            style={{marginBottom: 30}}
            title={'Save & Continue'}
            onPress={() => {
              // Actions.SelectCountry();
              submitButtonClicked();
            }}
          />
        </View>
      </View>
      {renderDatePicker()}
      <Loader isLoading={kycFirst.kycLoading} />

      <Modal
        animationType="Slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}>
        <Wrap
          // darkMode={ThemeManager.colors.themeColor === 'light' ? false : true}
          style={{backgroundColor: ThemeManager.colors.modalBox}}
          screenStyle={[styles.screenStyle, {backgroundColor: 'transparent'}]}
          bottomStyle={{backgroundColor: ThemeManager.colors.DashboardBG}}>
          <View
            style={{
              backgroundColor: ThemeManager.colors.modalBox,
              flex: 1,
              // justifyContent: 'center',
            }}>
            <View style={{flex: 1}}>
              <View>
                <View style={styles.searchContainer}>
                  <View style={styles.searchView}>
                    <Image
                      source={{uri: ThemeManager.ImageIcons.icon_search_text}}
                      style={styles.searchIcon}
                    />
                    <TextInput
                      value={searchData}
                      onChangeText={onSearch}
                      style={{
                        width: '80%',
                        color: ThemeManager.colors.textColor1,
                        fontSize: 14,
                        fontFamily: Fonts.regular,
                      }}
                      placeholder={strings.currencyDetails.search}
                      placeholderTextColor={
                        ThemeManager.colors.inactiveTextColor
                      }
                    />
                  </View>
                  <View>
                    <TouchableOpacity
                      // style={{flex: 0.3}}
                      onPress={() => {
                        setModalVisible(false);
                      }}>
                      <Text style={styles.cancelText}>
                        {strings.currencyDetails.cancel}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
              <View style={{marginHorizontal: 15}}>
                <Text
                  style={{
                    marginTop: 15,
                    fontSize: 16,
                    fontFamily: Fonts.regular,
                    color: ThemeManager.colors.inactiveTextColor,
                  }}>
                  {strings.location.location}
                </Text>
                <Text
                  style={{
                    marginTop: 15,
                    fontSize: 16,
                    fontFamily: Fonts.regular,
                    color: ThemeManager.colors.selectedTextColor,
                  }}>
                  {selectedCountry}
                </Text>
                <Text
                  style={{
                    marginTop: 15,
                    fontSize: 16,
                    fontFamily: Fonts.regular,
                    color: ThemeManager.colors.inactiveTextColor,
                  }}>
                  {strings.location.countryRegion}
                </Text>
                <FlatList
                  style={styles.countryList}
                  data={countryData}
                  renderItem={({item}) => (
                    <TouchableOpacity
                      style={{
                        justifyContent: 'flex-start',
                        alignItems: 'center',
                        flexDirection: 'row',
                      }}
                      onPress={() => {
                        // setSelectedCountry(item.countryNameEn);
                        setModalVisible(false);

                        dispatch(
                          kycFirstFormUpdate({
                            prop: 'kycCountry',
                            value: item.countryNameEn,
                          }),
                        );

                        dispatch(
                          kycFirstFormUpdate({
                            prop: 'kycCountryId',
                            value: item.countryCode,
                          }),
                        );
                      }}>
                      <View style={{borderRadius: 15, marginRight: 10}}>
                        <Text style={{fontSize: 16, marginTop: 10}}>
                          {item.flag}
                        </Text>
                      </View>
                      <Text
                        style={{
                          marginTop: 15,
                          fontSize: 16,
                          fontFamily: Fonts.regular,
                          color: ThemeManager.colors.textColor1,
                        }}>
                        {item.countryNameEn}
                      </Text>
                    </TouchableOpacity>
                  )}
                  scrollEnabled={true}
                  keyExtractor={(item, index) => index.toString()}
                  // extraData={this.props.selected}
                />
              </View>
            </View>
          </View>
        </Wrap>
      </Modal>
    </SafeAreaView>
  );
};

export default Verification;
