/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from "react";
import {
  View,
  TouchableOpacity,
  Text,
  Image,
  FlatList,
  TextInput,
} from "react-native";
import { Actions } from "react-native-router-flux";
import { strings } from "../../../../Localization";
import { ThemeManager } from "../../../../ThemeManager";
import { colors, Fonts, Images } from "../../../theme";
import {
  ButtonPrimary,
  ConvertInput,
  CustomEmptyView,
  Wrap,
} from "../../common";
import ConvertHeader from "../../common/ConvertHeader";
import styles from "./SearchCoinPairStyle";
import LinearGradient from "react-native-linear-gradient";
import TradeHeader from "../../common/TradeHeader";
import { useDispatch, useSelector } from "react-redux";
import Singleton from "../../../Singleton";
import { EventRegister } from "react-native-event-listeners";
import { tradeValuesUpdate, getMarketList } from "../../../Redux/Actions";

const SearchCoinPair = () => {
  const dispatch = useDispatch();
  // const marketSocketReducer = useSelector((state) => state.marketSocketReducer);
  const { marketData } = useSelector((state) => state.marketSocketReducer);

  const [favArray, setFavArray] = useState([]);
  const [pairData, setPairData] = useState(marketData);
  const [searchData, setSearchData] = useState(marketData);
  const { marketCoinInfo } = useSelector((state) => state?.orderHistoryReducer);
  const getSavedFav = () => {
    Singleton.getInstance()
      .getData("favArr")
      .then((res) => {
        if (res != null && res != "[]") {
          let favData = JSON.parse(res);
          console.log("favData=-=-=-", favData);
          setFavArray(favData);
        } else {
          setFavArray([]);
        }
      });
  };
  useEffect(() => {
    getSavedFav();
    return () => {};
  }, []);
  // const onSearch = value => {
  //   setPairData(
  //     searchData.filter(i =>
  //       i.name.toLowerCase().includes(value.toLowerCase()),
  //     ),
  //   );
  // };
  const onSearch = (value) => {
    setPairData(
      searchData.filter((i) => {
        // console.log("text name-=-=-=>>", i.name);
        const subText = i.name.toLowerCase().replace("/", "");

        return (
          i.name.toLowerCase().includes(value.toLowerCase()) ||
          subText.includes(value.toLowerCase())
        );
      })
    );
  };
  return (
    <Wrap
      style={{ backgroundColor: ThemeManager.colors.DashboardBG }}
      screenStyle={[
        styles.screenStyle,
        { backgroundColor: ThemeManager.colors.DashboardBG },
      ]}
      bottomStyle={{ backgroundColor: ThemeManager.colors.dashboardSubViewBg }}
    >
      <View>
        <View style={styles.searchContainer}>
          <View
            style={[
              styles.searchView,
              { backgroundColor: ThemeManager.colors.dashboardSearchBarBg },
            ]}
          >
            <Image
              source={{ uri: ThemeManager.ImageIcons.icon_search_text }}
              style={styles.searchIcon}
            />
            <TextInput
              value={searchData}
              onChangeText={onSearch}
              style={{ width: "80%", color: ThemeManager.colors.textColor1 }}
              placeholder={strings.currencyDetails.search}
              placeholderTextColor={ThemeManager.colors.inactiveTextColor}
            />
          </View>
          <View>
            <TouchableOpacity
              // style={{flex: 0.3}}
              onPress={() => {
                Actions.pop();
              }}
            >
              <Text
                style={[
                  styles.cancelText,
                  { color: ThemeManager.colors.Depositbtn },
                ]}
              >
                {strings.currencyDetails.cancel}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={{ alignItems: "flex-start", marginLeft: 15 }}>
        <View style={{ marginRight: 10, marginTop: 20 }}>
          <TradeHeader
            title={strings.currencyDetails.top_search}
            underLine={true}
          />
        </View>
      </View>
      <View
        style={{
          flex: 1,
          backgroundColor: ThemeManager.colors.dashboardSubViewBg,
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          paddingTop: 20,
          // flex: 1,
          // height: 30,
        }}
      >
        <FlatList
          data={pairData}
          keyboardShouldPersistTaps={"handled"}
          showsVerticalScrollIndicator={false}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={{
            flexGrow: 1,
            // backgroundColor: ThemeManager.colors.whiteScreen,
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
            // marginTop: 20,
          }}
          // style={{flexGrow: 1}}
          renderItem={({ item, index }) => {
            return (
              <TouchableOpacity
                onPress={() => {
                  dispatch(
                    tradeValuesUpdate({
                      prop: "selectedCoinPair",
                      value: item,
                    })
                  );

                  Actions.currentScene != "Trades" && Actions.Trades();
                }}
                style={
                  {
                    // backgroundColor: ThemeManager.colors.inputColor,
                    // borderTopLeftRadius: 30,
                    // borderTopRightRadius: 30,
                  }
                }
              >
                <View style={styles.viewContainer}>
                  <View style={[styles.flexStart]}>
                    <Text
                      style={[
                        styles.indexStyle,
                        { color: ThemeManager.colors.inactiveTextColor },
                      ]}
                    >
                      {index + 1}
                    </Text>
                    <Text
                      style={[
                        styles.activeTextStyle,
                        { color: ThemeManager.colors.textColor },
                      ]}
                    >
                      {item.base_unit.toUpperCase()}
                    </Text>
                    <Text style={styles.inactiveTextStyle}>
                      {"/"}
                      {item.quote_unit.toUpperCase()}
                    </Text>
                    <Text style={styles.xStyle}>{item.xValue}</Text>
                  </View>
                  <View
                    style={{
                      // alignItems: 'flex-end',
                      // justifyContent: 'flex-end',
                      flexDirection: "row",
                      // justifyContent: 'flex-start',
                      //tradeReducer.selectedCoinPair.price_change_percent.slice(0,-1,);
                    }}
                  >
                    <View
                      style={{
                        alignItems: "flex-end",
                        // justifyContent: 'flex-start',
                      }}
                    >
                      <Text
                        style={[
                          styles.valueText,
                          { color: ThemeManager.colors.textColor },
                        ]}
                      >
                        {parseFloat(item.avg_price).toFixed(4)}
                      </Text>
                      <Text
                        style={[
                          styles.fluctuateText,
                          {
                            color:
                              item?.price_change_percent?.slice(0, -1) >= 0
                                ? colors.appGreen
                                : colors.appRed,
                          },
                        ]}
                      >
                        {item.price_change_percent}
                      </Text>
                    </View>
                    <TouchableOpacity
                      onPress={() => {
                        Singleton.getInstance()
                          .saveToFav(item)
                          .then((res) => {
                            getSavedFav();
                            EventRegister.emit("favRefresh", "it works!!!");
                          })
                          .catch((err) => {});
                      }}
                    >
                      <Image
                        source={
                          favArray.filter(
                            (e) => e != null && e.name == item.name
                          ).length > 0
                            ? { uri: ThemeManager.ImageIcons.icon_star }
                            : { uri: ThemeManager.ImageIcons.icon_star }
                        }
                        style={{
                          height: 20,
                          width: 20,
                          resizeMode: "contain",
                          marginLeft: 15,
                          tintColor:
                            favArray.filter((e) => e.name === item.name)
                              .length > 0
                              ? ThemeManager.colors.selectedTextColor
                              : null,
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={() => {
            return (
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: 90,
                }}
              >
                <CustomEmptyView />
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: Fonts.regular,
                    color: ThemeManager.colors.inactiveTextColor,
                  }}
                >
                  {strings.cardScreen.no_record_found}
                </Text>
              </View>
            );
          }}
        />
      </View>
    </Wrap>
  );
};
export default SearchCoinPair;
