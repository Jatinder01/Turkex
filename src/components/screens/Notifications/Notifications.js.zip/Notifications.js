/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from "react";
import {
  Text,
  SafeAreaView,
  View,
  Image,
  FlatList,
  TouchableOpacity,
} from "react-native";
import styles from "./NotificationsStyle";
import { Wrap } from "../../common/Wrap";
import { ButtonPrimary, Header, Loader } from "../../common";
import { ThemeManager } from "../../../../ThemeManager";
import { Actions } from "react-native-router-flux";
import { Images, colors, Fonts } from "../../../theme";
import { strings } from "../../../../Localization";
import { string } from "prop-types";
import SimpleHeader from "../../common/SimpleHeader";
import {
  getNotificationList,
  resetNotificationHistory,
} from "../../../Redux/Actions";
import { useDispatch, useSelector } from "react-redux";
import Singleton from "../../../Singleton";
import moment from "moment";

import * as constants from "../../../Constants";
const Notifications = (props) => {
  const [pageNumber, setPageNumber] = useState(1);
  const [pageLimit, setPageLImit] = useState(10);
  const { notifyLoader, notifyErr, notifyData, totalrecords } = useSelector(
    (state) => state?.accountRed
  );
  console.log("notifyData=-=-=>>>", notifyData);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(resetNotificationHistory());
    Singleton.getInstance()
      .getData(constants.USER_DATA)
      .then((res) => {
        global.checkNotify = null;
        var data = JSON.parse(res);

        dispatch(getNotificationList(pageNumber, pageLimit)).then((res) => {});
      })
      .catch((err) => {});
  }, []);
  const isCloseToBottom = () => {
    let page = pageNumber + 1;

    if (notifyData.length != totalrecords) {
      setPageNumber(page);
      dispatch(getNotificationList(page, pageLimit));
    }
  };
  return (
    <Wrap
      style={{ backgroundColor: ThemeManager.colors.bgDarkwhite }}
      screenStyle={[
        styles.screenStyle,
        { backgroundColor: ThemeManager.colors.bgDarkwhite },
      ]}
      darkMode={ThemeManager.colors.themeColor === "light" ? false : true}
      bottomStyle={{ backgroundColor: ThemeManager.colors.bgDarkwhite }}
    >
      <View
        style={{ marginHorizontal: 16, marginBottom: 15, marginVertical: 10 }}
      >
        <SimpleHeader
          backImageColor={{ tintColor: ThemeManager.colors.headTxt }}
          onBackPress={() => {
            Actions.pop();
          }}
        />
      </View>

      <Text
        style={{
          marginHorizontal: 16,
          fontFamily: Fonts.medium,
          fontSize: 22,
          color: ThemeManager.colors.textColor1,
        }}
      >
        {strings.titleName.notifications}
      </Text>
      <View style={{ marginHorizontal: 16, marginVertical: 20, flexGrow: 1 }}>
        <FlatList
          bounces={false}
          keyboardShouldPersistTaps={"handled"}
          keyExtractor={(item, index) => index.toString()}
          style={{ flexGrow: 1 }}
          data={notifyData}
          onEndReached={() => {
            isCloseToBottom();
          }}
          onEndReachedThreshold={0.9}
          renderItem={({ item, index }) => {
            return (
              <TouchableOpacity
                style={[
                  styles.viewMainContainer,
                  { backgroundColor: ThemeManager.colors.dashboardDarkBg },
                ]}
                onPress={() => {
                  if (item?.notification?.data?.type == "Deposits") {
                    global.fromNotification = true;

                    Actions.currentScene != "HistoryWallet" &&
                      Actions.HistoryWallet();
                  } else if (item?.notification?.data?.type == "Trade") {
                    Actions.currentScene != "NotificationTradeHistory" &&
                      Actions.NotificationTradeHistory({
                        market: item?.notification?.data?.market,
                      });
                  } else if (
                    item?.notification?.data?.type == "Withdraws" ||
                    item?.notification?.data?.type == "OrderAsk" ||
                    item?.notification?.data?.type == "OrderBid"
                  ) {
                    global.fromNotification = false;
                    Actions.currentScene != "HistoryWallet" &&
                      Actions.HistoryWallet();
                  } else if (item?.notification?.data?.type == "Kyc") {
                  }
                }}
              >
                <Image
                  style={{
                    width: 20,
                    height: 20,
                    resizeMode: "contain",
                    tintColor: ThemeManager.colors.textColor1,
                  }}
                  source={{ uri: Images.icon_email }}
                />
                <View style={{ width: "90%", paddingHorizontal: 10 }}>
                  <Text
                    style={[
                      styles.headStyle,
                      {
                        color: ThemeManager.colors.textColor1,
                        textTransform: "capitalize",
                      },
                    ]}
                  >
                    {item?.notification?.notification?.title}
                  </Text>
                  <Text
                    style={[
                      styles.textStyle,
                      { color: ThemeManager.colors.textColor1 },
                    ]}
                  >
                    {typeof item?.notification?.notification?.body ===
                      "string" && item?.notification?.notification?.body}
                  </Text>
                  <Text
                    style={[
                      styles.textStyle,
                      {
                        color: ThemeManager.colors.textColor1,
                        fontSize: 9,
                        marginTop: 10,
                        // alignSelf: 'flex-end',
                      },
                    ]}
                  >
                    {moment(item.created_at).format("DD MMM, hh:mm A")}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
          ListFooterComponent={() => {
            return <View style={{ height: 50 }} />;
          }}
          ListEmptyComponent={
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                marginTop: 250,

                flexGrow: 1,
              }}
            >
              <Text
                style={{
                  color: ThemeManager.colors.textColor1,
                  fontFamily: Fonts.regular,
                  fontSize: 16,
                }}
              >
                {"No record found"}
              </Text>
            </View>
          }
        />
      </View>
      <Loader isLoading={notifyLoader} />
    </Wrap>
  );
};

export default Notifications;
