/* eslint-disable react-native/no-inline-styles */
import React, { useState, useEffect, useRef } from "react";
import {
  Text,
  SafeAreaView,
  BackHandler,
  TouchableOpacity,
  Image,
  Modal,
  Alert,
} from "react-native";
import styles from "./LoginStyle";
import { Wrap } from "../../common/Wrap";
import { View } from "native-base";
import { ThemeManager } from "../../../../ThemeManager";
import { Fonts, Images, colors } from "../../../theme";
import fonts from "../../../theme/fonts";
import { Tab, Tabs } from "native-base";
import Singleton from "../../../Singleton";
import * as constants from "../../../Constants";
import { useDispatch, useSelector } from "react-redux";
import {
  forgotPasswordFormUpdate,
  forgotPasswordUser,
} from "../../../Redux/Actions";
import {
  SubHeaderLinks,
  InputField,
  ButtonPrimary,
  PhoneNumberInput,
  HeaderCancel,
  CountryList,
  Header,
  Loader,
  MaintenanceScreen,
} from "../../common";
import PagerView from "react-native-pager-view";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scrollview";
import { Actions } from "react-native-router-flux";
import {
  loginFormUpdate,
  loginUser,
  logoutUserSuccess,
  resetGAuth,
} from "../../../Redux/Actions";
import ConfirmGoogleCaptcha from "react-native-google-recaptcha-v2";
import END_POINT from "../../../EndPoints";
import { strings } from "../../../../Localization";
import { log } from "react-native-reanimated";
import moment from "moment";
import { CoinCultApi } from "../../../api";

let pagera = null;
const NAVDATA = [
  {
    title: "Email",
  },
  // {
  //   title: 'Phone Number',
  // },
];
let captchaForm;
let status;
const Login = (props) => {
  // let captchaForm = useRef(null);
  const [ViewPassword, setViewPassword] = useState(false);
  const [selectedPage, setSelectedPage] = useState(0);
  const [modalCountryVisible, setModalCountryVisible] = useState(false);
  const [otp, setOtp] = useState("");
  const AuthReducer = useSelector((state) => state?.AuthReducer);
  const [loader, setLoader] = useState(false);
  const [showMaintaining, setShowMaintaining] = useState(false);
  const dispatch = useDispatch();

  const onMessage = (event) => {
    if (event && event.nativeEvent.data) {
      if (["cancel", "error", "expired"].includes(event.nativeEvent.data)) {
        captchaForm.hide();
        return;
      } else {
        const token = event.nativeEvent.data;
        setTimeout(() => {
          actionOnSuccess(token);
        }, 200);
      }
    }
  };
  const actionOnSuccess = (value) => {
    dispatch(loginFormUpdate({ prop: "recaptchaData", value }));
    dispatch(loginFormUpdate({ prop: "recaptchaCheck", value: true }));
    captchaForm.hide();
  };
  useEffect(() => {
    const backAction = () => {
      const { navigation } = props;
      var currentRoute = navigation.state?.routeName;
      if (Actions.currentScene === "Login") {
        Actions.currentScene != "Main" && Actions.reset("Main");
        return true;
      }
      return false;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => {
      backHandler.remove();
      resetReducer();
    };
  }, []);

  const onButtonPress = () => {
    let reg = /^\w+([\.-\.+\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    let passReg =
      /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-.]).{8,}$/;

    let errcheck = checkSessionMaintaining()
      .then((res) => {
        if (res === false) {
          if (reg.test(AuthReducer?.loginEmail) == false) {
            dispatch(
              loginFormUpdate({
                prop: "loginError",
                value: constants.VALID_EMAIL,
              })
            );
          } else if (AuthReducer?.loginPassword.length <= 0) {
            dispatch(
              loginFormUpdate({
                prop: "loginError",
                value: "Please enter password.",
              })
            );
          } else if (
            AuthReducer?.gAuthEnable == true &&
            AuthReducer?.gOtpCode.length < 6
          ) {
            dispatch(
              loginFormUpdate({
                prop: "loginError",
                value: "Please enter correct google code.",
              })
            );
          }
          // else if (passReg.test(AuthReducer.loginPassword) == false) {
          //   dispatch(
          //     loginFormUpdate({prop: 'loginError', value: constants.VALID_PASSWORD}),
          //   );
          // }
          else if (!AuthReducer?.recaptchaCheck) {
            dispatch(loginFormUpdate({ prop: "loginError", value: "" }));
            captchaForm.show();
          } else {
            dispatch(
              loginUser({
                loginEmail: AuthReducer?.loginEmail,
                loginPassword: AuthReducer?.loginPassword,
                recaptchaCheck: AuthReducer?.recaptchaCheck,
                recaptchaData: AuthReducer?.recaptchaData,
                gOtpCode: AuthReducer?.gOtpCode,
                gAuthEnable: AuthReducer?.gAuthEnable,
              })
            );
          }
        }
      })
      .catch((err) => {
        console.log("checkSessionMaintaining=-=-=-=->>>>", err);
      });
  };

  const renderError = () => {
    if (AuthReducer?.loginError) {
      if (
        AuthReducer?.loginError == "Captcha_Session_failed" ||
        AuthReducer?.loginError ==
          "Captcha session expired, please verify captcha again"
      ) {
        dispatch(loginFormUpdate({ prop: "loginError", value: "" }));
        captchaForm.show();
      }

      return (
        <View>
          <Text style={styles.errorMessageStyle}>
            {AuthReducer?.loginError}
          </Text>
        </View>
      );
    }
  };

  const resetReducer = () => {
    dispatch(loginFormUpdate({ prop: "loginPassword", value: "" }));
    dispatch(loginFormUpdate({ prop: "loginEmail", value: "" }));
    dispatch(loginFormUpdate({ prop: "loginError", value: "" }));
    dispatch(loginFormUpdate({ prop: "gAuthEnable", value: false }));
    dispatch(loginFormUpdate({ prop: "gOtpCode", value: "" }));
    dispatch(loginFormUpdate({ prop: "recaptchaCheck", value: false }));
    dispatch(loginFormUpdate({ prop: "loginLoading", value: false }));
    dispatch(loginFormUpdate({ prop: "recaptchaData", value: "" }));
  };

  const checkSessionMaintaining = () => {
    setLoader(true);
    return new Promise((resolve, reject) => {
      CoinCultApi.get(END_POINT.MAINTENANCE_SCREEN_URL, null)
        .then((response) => {
          if (response.status === 200) {
            setLoader(false);
            status = response?.data === "false" ? false : true;
            // this.showMaintenanceAlert(status);
            Singleton.getInstance().showMaintenance = status;
            setShowMaintaining(status);
            resolve(status);
          }
        })
        .catch((error) => {
          reject(error);
          setLoader(false);
        });
    });
  };
  return (
    <>
      {showMaintaining ? (
        <MaintenanceScreen
          viewColor={{ backgroundColor: ThemeManager.colors.tabBackground }}
          maintainTextColor={{ color: ThemeManager.colors.textColor1 }}
          btnColor={{ color: ThemeManager.colors.selectedTextColor }}
          txtColor={{ color: ThemeManager.colors.textColor }}
          loaderState={loader}
          onPress={() => {
            checkSessionMaintaining();
          }}
        />
      ) : (
        <SafeAreaView
          style={{
            flex: 1,
            backgroundColor: ThemeManager.colors.DashboardBG,
          }}
        >
          {AuthReducer?.gAuthEnable ? (
            <KeyboardAwareScrollView
              bounces={false}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ flexGrow: 1 }}
            >
              <View style={{ flex: 1 }}>
                <View style={{ alignItems: "flex-end" }}>
                  <TouchableOpacity
                    style={{ marginRight: 15, marginTop: 15 }}
                    onPress={() => {
                      dispatch(resetGAuth());
                    }}
                  >
                    <Image
                      source={{ uri: ThemeManager.ImageIcons.icon_close_main }}
                      style={{ height: 25, width: 25, resizeMode: "contain" }}
                    />
                  </TouchableOpacity>
                </View>

                <View style={{ marginTop: 50, marginHorizontal: 15 }}>
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor,
                      fontFamily: Fonts.medium,
                      fontSize: 26,
                      marginBottom: 40,
                    }}
                  >
                    {strings.titleName.sign_in}
                  </Text>
                  <Text
                    style={{
                      marginTop: 50,
                      fontSize: 14,
                      fontFamily: Fonts.regular,
                      color: ThemeManager.colors.inactiveTextColor,
                      marginBottom: 5,
                    }}
                  >
                    {strings.titleName.enter_2fa}
                  </Text>
                </View>
                <InputField
                  editable={true}
                  title={"EG. 303455"}
                  value={AuthReducer?.gOtpCode}
                  onChangeText={(value) => {
                    if (constants.ACCOUNT_NUMBER_REGEX.test(value)) {
                      dispatch(loginFormUpdate({ prop: "gOtpCode", value }));
                    }
                  }}
                  maxlength={6}
                  keyboardType="numeric"
                  returnKeyType={"done"}
                  customContainerStyle={{
                    backgroundColor: ThemeManager.colors.SwapInput,
                  }}
                />
                <View style={{ marginTop: 40 }} />
                <View style={[styles.errorStyleView, { marginTop: 0 }]}>
                  {renderError()}
                </View>
                <ButtonPrimary
                  style={{ marginTop: 10 }}
                  title={strings.titleName.logIn}
                  onPress={() => {
                    onButtonPress();
                  }}
                />
                <TouchableOpacity
                  style={{ marginHorizontal: 15, marginTop: 20 }}
                  onPress={() => {
                    Actions.Location();
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: Fonts.regular,
                      color: ThemeManager.colors.inactiveTextColor,
                    }}
                  >
                    {strings.titleName.dont_have_account}{" "}
                    <Text
                      style={{
                        color: colors.btnTextColor,
                      }}
                    >
                      {strings.titleName.signup_here}
                    </Text>
                  </Text>
                </TouchableOpacity>
              </View>
              <ConfirmGoogleCaptcha
                siteKey={constants.RECAPTCHA_KEY}
                baseUrl={END_POINT.COMMON_URL}
                ref={(_ref) => (captchaForm = _ref)}
                languageCode="en"
                onMessage={(event) => {
                  onMessage(event);
                }}
              />
              <Loader isLoading={AuthReducer.loginLoading} />
            </KeyboardAwareScrollView>
          ) : (
            <SafeAreaView
              style={{
                flex: 1,
                backgroundColor: ThemeManager.colors.bgDarkwhite,
              }}
            >
              <KeyboardAwareScrollView
                bounces={false}
                keyboardShouldPersistTaps="handled"
                debounce={false}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ flexGrow: 1 }}
              >
                <View style={{ flex: 1 }}>
                  {/* Commented below code because user can not skip login */}
                  <TouchableOpacity
                    onPress={() => {
                      // Actions.currentScene != 'Main' && Actions.Main()
                      // Actions.currentScene != '_Home' && Actions.reset('Main');
                      let a = props.fromScreen;
                      console.log("login move=-=a", a);
                      if (props?.fromScreen === "Wallets") {
                        Actions.currentScene !== "_Home" &&
                          Actions.reset("Main");
                      } else {
                        if (a != null || a != undefined) {
                          if (a === "Home") {
                            Actions.currentScene !== "_Home" &&
                              Actions.reset("Main");
                          } else {
                            Actions.Main({ type: "reset" });
                            Actions[a]();
                          }
                        } else {
                          Actions.currentScene !== "_Home" &&
                            Actions.reset("Main");
                        }
                      }
                    }}
                    style={{
                      height: 45,
                      width: 45,
                      justifyContent: "flex-start",
                      alignSelf: "flex-end",
                      alignItems: "flex-end",
                      marginRight: 20,
                      marginTop: 20,
                      // backgroundColor: 'red',
                    }}
                  >
                    <Image
                      source={{ uri: ThemeManager.ImageIcons.icon_close_main }}
                      style={{
                        height: 25,
                        width: 25,
                        resizeMode: "contain",
                        // tintColor: ThemeManager.colors.headTxt,
                      }}
                    />
                  </TouchableOpacity>
                  {/* <Header
                    customCenterTitle={{}}
                    rightImage={{uri: Images.cross}}
                    btnTextRight=" "
                    customRightImage={{
                      width: 23,
                      height: 23,
                      right: 16,
                      tintColor: ThemeManager.colors.headTxt,
                      resizeMode: 'contain',
                    }}
                    rightButtonClicked={() => {
                      Actions.currentScene != 'Main' && Actions.Main();
                    }}
                  /> */}
                  <Text
                    onPress={() => {
                      let a = "2022-06-16 10:58:51 +0000";
                      let b = a.split(" ");
                      a = b[0] + "T" + b[1];
                      console.log("-----", a);
                      // let b = moment(a).format('MM/DD/YYYY h:mm:ss');
                      // console.log('-----', new Date(b).getTime());
                    }}
                    style={{
                      marginTop: 100,
                      marginHorizontal: 16,
                      color: ThemeManager.colors.headTxt,
                      fontFamily: fonts.medium,
                      fontSize: 22,
                    }}
                  >
                    {strings.login_page.account_login}
                  </Text>
                  {/* <SubHeaderLinks
            customNavigationLoginStyle={{marginTop: '10%'}}
            forEmail
            navItems={NAVDATA}
            selectedPage={selectedPage}
            onPress={({item, index}) => {     <SubHeaderLinks
            customNavigationLoginStyle={{marginTop: '10%'}}
            forEmail
            navItems={NAVDATA}
            selectedPage={selectedPage}
            onPress={({item, index}) => {
              setSelectedPage(index);
              pagera.setPage(index);
            }}
            GET_COIN_BALANCE_LIST
          />
              setSelectedPage(index);
              pagera.setPage(index);
            }}
            GET_COIN_BALANCE_LIST
          /> */}
                  {/* <PagerView
                ref={ref => (pagera = ref)}
                style={styles.pagerView}
                initialPage={0}
                scrollEnabled={false}
                onPageScroll={event => {
                  // EventRegister.emit('clearData', '');
                }}
                onPageSelected={event => {
                  setSelectedPage(event.nativeEvent.position);
                }}> */}
                  <View key="1">
                    <Text
                      style={[
                        styles.inputTitle,
                        { color: ThemeManager.colors.textBW },
                      ]}
                    >
                      {strings.login_page.email}
                    </Text>

                    <InputField
                      editable={true}
                      title={strings.login_page.email}
                      value={AuthReducer.loginEmail}
                      onChangeText={(value) => {
                        dispatch(
                          loginFormUpdate({ prop: "loginEmail", value })
                        );
                      }}
                      maxlength={100}
                      keyboardType="email-address"
                      customContainerStyle={{
                        backgroundColor: ThemeManager.colors.SwapInput,
                      }}
                    />
                    <Text
                      style={[
                        styles.inputTitle,
                        { color: ThemeManager.colors.textBW },
                      ]}
                    >
                      {strings.login_page.password}
                    </Text>
                    <InputField
                      editable={true}
                      title={strings.login_page.password}
                      value={AuthReducer.loginPassword}
                      onChangeText={(value) => {
                        dispatch(
                          loginFormUpdate({ prop: "loginPassword", value })
                        );
                      }}
                      maxlength={100}
                      keyboardType="default"
                      secureTextEntry={ViewPassword ? false : true}
                      image={
                        ViewPassword
                          ? { uri: ThemeManager.ImageIcons.icon_hide_eye }
                          : { uri: ThemeManager.ImageIcons.icon_open_eye }
                      }
                      rightImageStyle={{
                        tintColor: ThemeManager.colors.textColor1,
                      }}
                      onPress={() => {
                        setViewPassword(!ViewPassword);
                      }}
                      // {tintColor: ThemeManager.colors.textColor1},
                      customContainerStyle={{
                        backgroundColor: ThemeManager.colors.SwapInput,
                      }}
                    />
                    <View style={styles.errorStyleView}>{renderError()}</View>

                    <View style={{ marginTop: 25 }}>
                      <ButtonPrimary
                        title={strings.login_page.login}
                        onPress={() => {
                          onButtonPress();
                        }}
                      />
                    </View>

                    <TouchableOpacity
                      style={[styles.forgotPasswordView]}
                      onPress={() => {
                        resetReducer();
                        Actions.ResetPassword();
                      }}
                    >
                      <Text style={styles.text}>
                        {strings.login_page.forgot_password}
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.RegisterView}
                      onPress={() => {
                        resetReducer();
                        Actions.Location();
                      }}
                    >
                      <Text style={styles.text}>
                        {strings.login_page.register_now}
                      </Text>
                    </TouchableOpacity>
                  </View>
                  {/* <View key="2">
                  <Text
                    style={[
                      styles.inputTitle,
                      {color: ThemeManager.colors.textBW},
                    ]}>
                    Mobile
                  </Text>
                  <PhoneNumberInput
                    verifyLable={styles.notShow}
                    placeHolder="Mobile Number"
                    verifyInputStyle={styles.inputStyle}
                    countryCodeText={props.mobilePhoneCode}
                    placeHolderTextColor={ThemeManager.colors.inactiveTextColor}
                    maxLength={15}
                    countryCodeClicked={() => setModalCountryVisible(true)}
                    onChangeText={value => {
                      let extraSpaceRegex = /^\s*\s*$/;
                    }}
                  />
                  <Text
                    style={[
                      styles.inputTitle,
                      {color: ThemeManager.colors.textBW},
                    ]}>
                    {strings.login_page.password}
                  </Text>
                  <InputField
                    editable={true}
                    title={strings.login_page.password}
                    onChangeText={value => {}}
                    maxlength={100}
                    image={{uri: Images.viewPasswordPressed_icon}}
                    customContainerStyle={{
                      backgroundColor: ThemeManager.colors.SwapInput,
                    }}
                  />
                  <View style={{marginTop: 40}}>
                    <ButtonPrimary
                      title={strings.login_page.login}
                      onPress={() => {
                        Actions.EnterPhoneToVerify();
                      }}
                    />
                  </View>
                  <TouchableOpacity
                    style={[styles.forgotPasswordView]}
                    onPress={() => {
                      Actions.ResetPassword();
                    }}>
                    <Text style={styles.text}>
                      {strings.login_page.forgot_password}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.RegisterView}
                    onPress={() => {
                      Actions.Location();
                    }}>
                    <Text style={styles.text}>
                      {strings.login_page.register_now}
                    </Text>
                  </TouchableOpacity>
                </View>
              </PagerView> */}
                  <ConfirmGoogleCaptcha
                    siteKey={constants.RECAPTCHA_KEY}
                    baseUrl={END_POINT.COMMON_URL}
                    ref={(_ref) => (captchaForm = _ref)}
                    languageCode="en"
                    onMessage={(event) => {
                      onMessage(event);
                    }}
                  />
                  {AuthReducer.loginLoading && <Loader />}
                </View>
              </KeyboardAwareScrollView>
              <Modal
                animationType="slide"
                transparent={true}
                visible={modalCountryVisible}
                onRequestClose={() => setModalCountryVisible(false)}
              >
                <View style={styles.modelContainer}>
                  <TouchableOpacity
                    style={{ width: "100%", height: "100%" }}
                    onPress={() => setModalCountryVisible(false)}
                  />

                  <View style={styles.modelContainerChild}>
                    <HeaderCancel
                      headerBtnText={styles.btnBack}
                      titleText={strings.login_page.select_country}
                      onPressBtnBack={() => {
                        setModalCountryVisible(false);
                      }}
                    />
                    <CountryList
                      placeHolder={strings.login_page.search_country}
                      hideDialCode={false}
                      selectedListItem={(item) => {
                        setModalCountryVisible(false);
                        let value = item.dial_code;
                        alert(value);
                      }}
                    />
                  </View>
                </View>
              </Modal>
              <Loader isLoading={AuthReducer?.loginLoading} />
            </SafeAreaView>
          )}
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalCountryVisible}
            onRequestClose={() => setModalCountryVisible(false)}
          >
            <View style={styles.modelContainer}>
              <TouchableOpacity
                style={{ width: "100%", height: "100%" }}
                onPress={() => setModalCountryVisible(false)}
              />

              <View style={styles.modelContainerChild}>
                <HeaderCancel
                  headerBtnText={styles.btnBack}
                  titleText={strings.login_page.select_country}
                  onPressBtnBack={() => {
                    setModalCountryVisible(false);
                  }}
                />
                <CountryList
                  placeHolder={strings.login_page.search_country}
                  hideDialCode={false}
                  selectedListItem={(item) => {
                    setModalCountryVisible(false);
                    let value = item.dial_code;
                    alert(value);
                  }}
                />
              </View>
            </View>
          </Modal>
        </SafeAreaView>
      )}
    </>
  );
};

export default Login;
