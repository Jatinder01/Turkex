/* eslint-disable react-native/no-inline-styles */
import React, { useState, useEffect } from "react";
import {
  Text,
  SafeAreaView,
  TouchableOpacity,
  Image,
  TextInput,
} from "react-native";
import styles from "./LoginVerificationStyle";
import { View } from "native-base";
import { ThemeManager } from "../../../../ThemeManager";
import { Fonts, Images, colors } from "../../../theme";
import fonts from "../../../theme/fonts";
import * as constants from "../../../Constants";
import {
  InputField,
  ButtonPrimary,
  Header,
  Loader,
  InputFieldOtp,
} from "../../common";
import {
  registerFormUpdate,
  resendPhoneOtpVerify,
  resendEmailOtpVerify,
  registerEmailOtpUpdate,
  registerPhoneOtpUpdate,
  registerEmailPhoneVerify,
} from "../../../Redux/Actions";
import { useDispatch, useSelector } from "react-redux";

import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scrollview";
import { strings } from "../../../../Localization";
import { Actions } from "react-native-router-flux";

const LoginVerification = (props) => {
  let interval = React.useRef(null);
  let intervalEmail = React.useRef(null);
  let intervalPhone = React.useRef(null);

  const dispatch = useDispatch();

  const {
    registerEmailOtp,
    registerPhoneNumberOtp,
    registerError,
    regOtpLoading,
    regVerifyLoading,
    regLoading,
  } = useSelector((state) => state.RegisterReducer);
  const [emailAddress, setEmailAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [showConvertBtn, setShowConvertBtn] = useState(true);
  const { isThemeUpdate } = useSelector((state) => state.tradeReducer);
  const [countDown, setCountDown] = useState(60);
  const [countDownEmail, setCountDownEmail] = useState(60);
  const [countDownPhone, setCountDownPhone] = useState(60);
  const [showConvertBtnEmail, setShowConvertBtnEmail] = useState(false);
  const [showConvertBtnPhone, setShowConvertBtnPhone] = useState(false);

  useEffect(() => {
    return () => {
      // alert('vj');
      isThemeUpdate;
    };
  }, [isThemeUpdate]);
  useEffect(() => {
    getTimer();
    dispatch(
      registerFormUpdate({
        prop: "registerEmail",
        value: props.loginEmail,
      })
    );
    dispatch(
      registerFormUpdate({
        prop: "registerPhoneNumberWithCode",
        value: props.phoneNumber,
      })
    );
  }, []);
  const onButtonPress = () => {
    if (registerEmailOtp === "") {
      dispatch(
        registerFormUpdate({
          prop: "registerError",
          value: "Please enter email otp",
        })
      );
    } else if (registerPhoneNumberOtp === "") {
      dispatch(
        registerFormUpdate({
          prop: "registerError",
          value: "Please enter phone otp",
        })
      );
    } else if (registerEmailOtp.length != 5) {
      dispatch(
        registerFormUpdate({
          prop: "registerError",
          value: "Please enter valid email otp",
        })
      );
    } else if (registerPhoneNumberOtp.length != 5) {
      dispatch(
        registerFormUpdate({
          prop: "registerError",
          value: "Please enter valid phone otp",
        })
      );
    } else {
      dispatch(
        registerFormUpdate({
          prop: "registerError",
          value: "",
        })
      );
      dispatch(
        registerFormUpdate({
          prop: "registerOtpError",
          value: "",
        })
      );
      dispatch(
        registerEmailPhoneVerify({
          registerEmail: props.loginEmail,
          registerPhoneNumber: props.phoneNumber,
          registerEmailOtp: registerEmailOtp,
          registerPhoneNumberOtp: registerPhoneNumberOtp,
        })
      )
        .then((res) => {
          dispatch(
            registerFormUpdate({ prop: "registerPhoneNumber", value: "" })
          );
          dispatch(registerFormUpdate({ prop: "registerEmail", value: "" }));
          dispatch(
            registerFormUpdate({ prop: "registerPhoneNumberOtp", value: "" })
          );
          dispatch(registerFormUpdate({ prop: "registerEmailOtp", value: "" }));
        })
        .catch((err) => {});
    }
  };
  useEffect(() => {
    dispatch(registerFormUpdate({ prop: "registerPhoneNumberOtp", value: "" }));
    dispatch(registerFormUpdate({ prop: "registerEmailOtp", value: "" }));

    return () => {
      dispatch(registerFormUpdate({ prop: "registerPhoneNumber", value: "" }));
      dispatch(registerFormUpdate({ prop: "registerEmail", value: "" }));
      dispatch(
        registerFormUpdate({ prop: "registerPhoneNumberOtp", value: "" })
      );
      dispatch(registerFormUpdate({ prop: "registerEmailOtp", value: "" }));
    };
  }, []);

  const renderError = () => {
    if (registerError) {
      return (
        <View style={{ marginHorizontal: 16, marginBottom: 10 }}>
          <Text style={styles.errorMessageStyle}>{registerError}</Text>
        </View>
      );
    }
    // }
  };
  const getTimer = () => {
    let count = 60;
    if (interval) {
      setCountDown("");
      clearInterval(interval.current);
    }

    interval.current = setInterval(() => {
      count = count - 1;

      setCountDown(count + "");
      if (count == 1) {
        count = 0;
        setCountDown("");
        setShowConvertBtn(false);
        interval && clearInterval(interval.current);
      }
    }, 1000);
  };
  const getTimerEmail = () => {
    let countEmail = 60;
    if (intervalEmail) {
      setCountDownEmail("");
      clearInterval(intervalEmail.current);
    }

    intervalEmail.current = setInterval(() => {
      countEmail = countEmail - 1;

      setCountDown(countEmail + "");
      if (countEmail == 1) {
        countEmail = 0;
        setCountDownEmail("");
        setShowConvertBtnEmail(false);
        intervalEmail && clearInterval(intervalEmail.current);
      }
    }, 1000);
  };
  const getTimerPhone = () => {
    let countPhone = 60;
    if (intervalPhone) {
      setCountDownPhone("");
      clearInterval(intervalPhone.current);
    }

    intervalPhone.current = setInterval(() => {
      countPhone = countPhone - 1;

      setCountDown(countPhone + "");
      if (countPhone == 1) {
        countPhone = 0;
        setCountDownPhone("");
        setShowConvertBtnPhone(false);
        intervalPhone && clearInterval(intervalPhone.current);
      }
    }, 1000);
  };
  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: ThemeManager.colors.DashboardBG,
      }}
    >
      {/* <Header
        customCenterTitle={{}}
        rightImage={{ uri: Images.icon_close }}
        btnTextRight=" "
        customRightImage={{
          width: 23,
          height: 23,
          right: 16,
          tintColor: ThemeManager.colors.headTxt,
          resizeMode: "contain",
        }}
        rightButtonClicked={() => {
          Actions.pop();
        }}
      /> */}
      <View style={{ alignItems: "flex-end" }}>
        <TouchableOpacity
          style={{ marginRight: 15, marginTop: 15 }}
          onPress={() => {
            Actions.pop();
          }}
        >
          <Image
            source={{ uri: ThemeManager.ImageIcons.icon_close_main }}
            style={{ height: 25, width: 25, resizeMode: "contain" }}
          />
        </TouchableOpacity>
      </View>
      <Loader isLoading={regOtpLoading} />
      <Loader isLoading={regVerifyLoading} />

      <View style={{ flex: 1 }}>
        <KeyboardAwareScrollView
          bounces={false}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ flexGrow: 1 }}
        >
          <Text
            style={{
              marginTop: 20,
              marginHorizontal: 16,
              color: ThemeManager.colors.headTxt,
              fontFamily: fonts.medium,
              fontSize: 22,
            }}
          >
            {strings.enterAccountDetails?.verifyAccount}
          </Text>
          <View>
            <View style={styles.inputTitle} />

            <View
              style={{
                justifyContent: "space-between",
                flexDirection: "row",
                alignItems: "center",
                height: 50,
                backgroundColor: ThemeManager.colors.SwapInput,
                marginHorizontal: 15,
                paddingHorizontal: 10,
                borderRadius: 6,
              }}
            >
              <TextInput
                value={registerEmailOtp}
                placeholder={strings.enterAccountDetails?.emailOtp}
                onChangeText={(value) => {
                  if (constants.ACCOUNT_NUMBER_REGEX.test(value)) {
                    dispatch(
                      registerEmailOtpUpdate({
                        prop: "registerEmailOtp",
                        value: value,
                      })
                    );
                  }
                }}
                style={[
                  {
                    fontFamily: fonts.regular,
                    color: ThemeManager.colors.textColor1,

                    fontSize: 14,
                    // lineHeight: 20,
                    // paddingLeft: 15,
                    height: 50,
                    backgroundColor: colors.transparent,
                    width: "60%",
                  },
                ]}
                maxLength={5}
                keyboardType="numeric"
                returnKeyType={"done"}
                placeholderTextColor={ThemeManager.colors.anouncementtextColour}
              />
              <View
                style={{
                  // justifyContent: "center",
                  // alignItems: "flex-end",
                  // marginRight: 16,
                  // marginTop: 5,
                  width: "35%",
                }}
              >
                {!showConvertBtn && !showConvertBtnEmail && (
                  <View
                    style={{
                      height: 40,
                      justifyContent: "center",
                      alignItems: "flex-end",
                    }}
                  >
                    <Text
                      style={{
                        color: ThemeManager.colors.selectedTextColor,
                        // textDecorationLine: "underline",
                        fontFamily: fonts.medium,
                        fontSize: 14,
                      }}
                    >
                      {strings.enterAccountDetails?.resendOtp}
                    </Text>
                  </View>
                )}
                {showConvertBtn && !showConvertBtnEmail && (
                  <View
                    style={{
                      height: 40,
                      justifyContent: "center",
                      alignItems: "flex-end",
                    }}
                  >
                    <Text
                      style={{
                        color: ThemeManager.colors.selectedTextColor,
                        // textDecorationLine: "underline",
                        fontFamily: fonts.medium,
                        fontSize: 14,
                      }}
                    >
                      {countDown} s
                    </Text>
                  </View>
                )}
                {!showConvertBtn && showConvertBtnEmail && (
                  <TouchableOpacity
                    style={{
                      height: 40,
                      justifyContent: "center",
                      alignItems: "flex-end",
                    }}
                    onPress={() => {
                      dispatch(resendEmailOtpVerify(props.loginEmail));
                    }}
                  >
                    <Text
                      style={{
                        color: ThemeManager.colors.selectedTextColor,
                        // textDecorationLine: "underline",
                        fontFamily: fonts.medium,
                        fontSize: 14,
                      }}
                    >
                      {countDownEmail}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
            {/* <InputFieldOtp
              editable={true}
              title={strings.enterAccountDetails?.emailOtp}
              value={registerEmailOtp}
              onChangeText={(value) => {
                if (constants.ACCOUNT_NUMBER_REGEX.test(value)) {
                  dispatch(
                    registerEmailOtpUpdate({
                      prop: "registerEmailOtp",
                      value: value,
                    })
                  );
                }
              }}
              maxlength={5}
              keyboardType="numeric"
              returnKeyType={"done"}
              customContainerStyle={{
                backgroundColor: ThemeManager.colors.SwapInput,
              }}
              // rightText={}
            /> */}
            {/* <View
              style={{
                justifyContent: "center",
                alignItems: "flex-end",
                marginRight: 16,
                marginTop: 5,
              }}
            >
              {!showConvertBtn && !showConvertBtnEmail && (
                <View
                  style={{
                    height: 40,
                    justifyContent: "center",
                    alignItems: "flex-end",
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor1,
                      textDecorationLine: "underline",
                    }}
                  >
                    {strings.enterAccountDetails?.resendOtp}
                  </Text>
                </View>
              )}
              {showConvertBtn && !showConvertBtnEmail && (
                <View
                  style={{
                    height: 40,
                    justifyContent: "center",
                    alignItems: "flex-end",
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor1,
                      textDecorationLine: "underline",
                    }}
                  >
                    {countDown}
                  </Text>
                </View>
              )}
              {!showConvertBtn && showConvertBtnEmail && (
                <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: "center",
                    alignItems: "flex-end",
                  }}
                  onPress={() => {
                    dispatch(resendEmailOtpVerify(props.loginEmail));
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor1,
                      textDecorationLine: "underline",
                    }}
                  >
                    {countDownEmail}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
             */}
            <View style={styles.inputTitle} />
            <View
              style={{
                justifyContent: "space-between",
                flexDirection: "row",
                alignItems: "center",
                height: 50,
                backgroundColor: ThemeManager.colors.SwapInput,
                marginHorizontal: 15,
                paddingHorizontal: 10,
                borderRadius: 6,
              }}
            >
              <TextInput
                value={registerPhoneNumberOtp}
                placeholder={strings.enterAccountDetails?.phoneOtp}
                onChangeText={(value) => {
                  if (constants.ACCOUNT_NUMBER_REGEX.test(value)) {
                    dispatch(
                      registerPhoneOtpUpdate({
                        prop: "registerPhoneNumberOtp",
                        value: value,
                      })
                    );
                  }
                }}
                style={[
                  {
                    fontFamily: fonts.regular,
                    color: ThemeManager.colors.textColor1,

                    fontSize: 14,
                    // lineHeight: 20,
                    // paddingLeft: 15,
                    height: 50,
                    backgroundColor: colors.transparent,
                    width: "60%",
                  },
                ]}
                maxLength={5}
                keyboardType="numeric"
                returnKeyType={"done"}
                placeholderTextColor={ThemeManager.colors.anouncementtextColour}
              />
              <View
                style={{
                  // justifyContent: "center",
                  // alignItems: "flex-end",
                  // marginRight: 16,
                  // marginTop: 5,
                  width: "35%",
                }}
              >
                {!showConvertBtn && !showConvertBtnPhone && (
                  <TouchableOpacity
                    style={{
                      height: 40,
                      justifyContent: "center",
                      alignItems: "flex-end",
                    }}
                    onPress={() => {
                      dispatch(
                        resendPhoneOtpVerify(
                          props.phoneNumber,
                          props.loginEmail
                        )
                      );
                    }}
                  >
                    <Text
                      style={{
                        color: ThemeManager.colors.selectedTextColor,
                        // textDecorationLine: "underline",
                        fontFamily: fonts.medium,
                        fontSize: 14,
                      }}
                    >
                      {strings.enterAccountDetails?.resendOtp}
                    </Text>
                  </TouchableOpacity>
                )}
                {showConvertBtn && !showConvertBtnPhone && (
                  <View
                    style={{
                      height: 40,
                      justifyContent: "center",
                      alignItems: "flex-end",
                    }}
                  >
                    <Text
                      style={{
                        color: ThemeManager.colors.selectedTextColor,
                        // textDecorationLine: "underline",
                        fontFamily: fonts.medium,
                        fontSize: 14,
                      }}
                    >
                      {countDown}
                    </Text>
                  </View>
                )}
                {!showConvertBtn && showConvertBtnPhone && (
                  <TouchableOpacity
                    style={{
                      height: 40,
                      justifyContent: "center",
                      alignItems: "flex-end",
                    }}
                    onPress={() => {
                      dispatch(resendEmailOtpVerify(props.loginEmail));
                    }}
                  >
                    <Text
                      style={{
                        color: ThemeManager.colors.selectedTextColor,
                        // textDecorationLine: "underline",
                        fontFamily: fonts.medium,
                        fontSize: 14,
                      }}
                    >
                      {countDownPhone}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {/* <InputFieldOtp
              editable={true}
              title={strings.enterAccountDetails?.phoneOtp}
              value={registerPhoneNumberOtp}
              onChangeText={(value) => {
                if (constants.ACCOUNT_NUMBER_REGEX.test(value)) {
                  dispatch(
                    registerPhoneOtpUpdate({
                      prop: "registerPhoneNumberOtp",
                      value: value,
                    })
                  );
                }
              }}
              maxlength={5}
              keyboardType="numeric"
              returnKeyType={"done"}
              customContainerStyle={{
                backgroundColor: ThemeManager.colors.SwapInput,
              }}
            />
            <View
              style={{
                justifyContent: "center",
                alignItems: "flex-end",
                marginRight: 16,
                marginTop: 5,
              }}
            >
              {!showConvertBtn && !showConvertBtnPhone && (
                <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: "center",
                    alignItems: "flex-end",
                  }}
                  onPress={() => {
                    dispatch(
                      resendPhoneOtpVerify(props.phoneNumber, props.loginEmail)
                    );
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor1,
                      textDecorationLine: "underline",
                    }}
                  >
                    {strings.enterAccountDetails?.resendOtp}
                  </Text>
                </TouchableOpacity>
              )}
              {showConvertBtn && !showConvertBtnPhone && (
                <View
                  style={{
                    height: 40,
                    justifyContent: "center",
                    alignItems: "flex-end",
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor1,
                      textDecorationLine: "underline",
                    }}
                  >
                    {countDown}
                  </Text>
                </View>
              )}
              {!showConvertBtn && showConvertBtnPhone && (
                <TouchableOpacity
                  style={{
                    height: 40,
                    justifyContent: "center",
                    alignItems: "flex-end",
                  }}
                  onPress={() => {
                    dispatch(resendEmailOtpVerify(props.loginEmail));
                  }}
                >
                  <Text
                    style={{
                      color: ThemeManager.colors.textColor1,
                      textDecorationLine: "underline",
                    }}
                  >
                    {countDownPhone}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
             */}
            {/* <Text style={styles.inputTitle}>Password</Text> */}
            <View style={styles.inputTitle} />

            <View style={styles.btnStyleView}>{renderError()}</View>
            {regLoading && <Loader />}
            <ButtonPrimary
              style={{ marginTop: 8 }}
              title={strings.enterAccountDetails?.confirm}
              onPress={() => {
                onButtonPress();
                //  Actions.currentScene != "Home" && Actions.Home()
              }}
            />
          </View>
          {regLoading && <Loader />}
        </KeyboardAwareScrollView>
      </View>
    </SafeAreaView>
  );
};

export default LoginVerification;
