/* eslint-disable react-native/no-inline-styles */
import React, { useEffect, useState } from "react";
import {
  Text,
  TouchableOpacity,
  View,
  Image,
  ScrollView,
  TextInput,
  Alert,
  AppState,
  FlatList,
  RefreshControl,
  StyleSheet,
  Modal,
  Dimensions,
  ImageBackground,
} from "react-native";

import { Wrap } from "../../common/Wrap";
import { ThemeManager } from "../../../../ThemeManager";
import TradeHeader from "../../common/TradeHeader";
import { strings } from "../../../../Localization";
import { colors, Fonts, Images } from "../../../theme";
import BorderLine from "../../common/BorderLine";
import { Actions } from "react-native-router-flux";
import Singleton from "../../../Singleton";
import { ButtonPrimary, TabIcon, Loader } from "../../common";
import { useDispatch, useSelector } from "react-redux";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scrollview";
import {
  getCardTopUpTrxList,
  getCardList,
  cardTransaction,
} from "../../../Redux/Actions";
import * as constants from "../../../Constants";
import { EventRegister } from "react-native-event-listeners";
import LinearGradient from "react-native-linear-gradient";
import LottieView from "lottie-react-native";
import SimpleHeader from "../../common/SimpleHeader";
import SelectDropdown from "react-native-select-dropdown";
import DatePicker from "react-native-date-picker";
import Moment from "moment";
const { height, width } = Dimensions.get("window");
let maxDateTime;
let paramTrx;
const TransactionStatement = (props) => {
  const dispatch = useDispatch();
  const styles = useStyles(ThemeManager);
  const [cardInfos, setCardInfos] = useState([]);
  const [selectedCard, setSelectedCard] = useState("");
  const [selectedCardIndex, setSelectedCardIndex] = useState(0);
  const [fromDate, setfromDate] = useState("YYYY-MM-DD");
  const [toDate, setToDate] = useState("YYYY-MM-DD");
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [fromDateSelected, setfromDateSelected] = useState(null);
  const [minimumToDate, setMinimumToDate] = useState(new Date());
  const [maxToDate, setMaxToDate] = useState(null);
  const [trxList, setTrxList] = useState([]);
  const [pageLimit, setPageLImit] = useState(2);
  const [pageNumberTrx, setPageNumberTrx] = useState(1);
  const [cardNumber, setCardNumber] = useState("");
  const {
    cardTopUpTrxListInfo,
    cardTopUpTrxListError,
    isCardTopUpTrxListLoading,
    totalRecords,
  } = useSelector((state) => state.cardTopUpTrxListReducer);
  const {
    cardTransactionHolder,
    isCardTransactionLoading,
    cardTransactionError,
  } = useSelector((state) => state.cardTransactionReducer);
  console.log("cardTransactionHolder=-->>>", cardTransactionHolder);

  useEffect(() => {
    dispatch(getCardList())
      .then((res) => {
        // console.log("getCardList=-====2==-->>>", res);
        // console.log("getCardList=-====2length-->>>", res.length);
        // console.log("getCardList=-====2length-->>>", res.length > 0);
        // console.log("getCardList=-====2length-->>>", res.length < 0);
        var date1 = new Date();
        let maxDate23 = Moment(date1).subtract(30, "days");
        console.log("value=-maxDate23=www", maxDate23);

        let maxDate24 = Moment(date1).subtract(30, "days").format("YYYY-MM-DD");
        console.log("value=-maxDate24=www", maxDate24);
        setMaxToDate(maxDate23);
        // maxDateTime = maxDate23;
        if (res.length > 0) {
          // console.log("getCardLis=-=-+++trx details=-=-=-=-=-=");
          setCardInfos(res);
          setSelectedCard(res[0]);
          setCardNumber(res[0].card_number);
          getTransactionList(res[0].card_number, pageNumberTrx, pageLimit);
        }
      })
      .catch((err) => {
        console.log("getCardList ++trx details err=++-=->>", err);
      });
    return () => {};
  }, []);
  const getTransactionList = (card_number, pageNumberTrx, pageLimit) => {
    dispatch(cardTransaction(card_number, pageNumberTrx, pageLimit))
      .then((res) => {
        console.log("getCardTopUpTrxList=-=res=-", res);
        let resp = JSON.parse(res.bodyString);
        setTrxList(resp);
      })
      .catch((err) => {
        console.log("getCardTopUpTrxList=-=-err=-", err);
      });
  };
  // const isCloseToBottomTrx = () => {
  //   let page = pageNumberTrx + 1;
  //   console.log(
  //     "cardTopUpTrxListInfo.length=-=-err=-",
  //     cardTopUpTrxListInfo.length
  //   );
  //   console.log("totalRecords.length=-=-err=-", totalRecords);

  //   if (cardTopUpTrxListInfo.length != totalRecords) {
  //     paramTrx = {
  //       page: `${page}`,
  //       limit: pageLimit,
  //     };
  //     setPageNumberTrx(page);
  //     dispatch(cardTransaction(cardNumber, paramTrx.page, paramTrx.limit));
  //   }
  // };
  const onButtonPress = () => {};
  const renderDatePicker = () => {
    var date1 = new Date();
    console.log("value=-date1=www", date1);
    let frmDat = Moment(date1).subtract(7, "days");
    return (
      <>
        {fromDateSelected ? (
          <DatePicker
            modal
            fadeToColor="white"
            open={showDatePicker}
            mode="date"
            date={date1}
            maximumDate={date1}
            theme={ThemeManager.colors.themeColor === "dark" ? "dark" : "light"}
            textColor={ThemeManager.colors.textColor1}
            onConfirm={(date) => {
              date1 = date;
              let value = Moment(date).format("YYYY-MM-DD");
              console.log("value=-=", value);
              // let newMaxDate = new Date(
              //   Date.parse(
              //     Moment().add(30, "days").format("ddd MMM DD YYYY HH:mm:ss ZZ")
              //   )
              // );
              let maxDate = Moment(date).add(30, "days");
              let maxDate1 = Moment(date).add(30, "days").format("YYYY-MM-DD");
              console.log("value=-maxDate=www", maxDate1);
              console.log("value=-minimumDate=date", date);
              console.log("value=-maxDate=", maxDate);

              setfromDate(value);
              setMinimumToDate(date);
              setMaxToDate(maxDate);
              // maxDateTime = maxDate;
              setShowDatePicker(false);
            }}
            onCancel={() => {
              setShowDatePicker(false);
            }}
          />
        ) : (
          <DatePicker
            modal
            fadeToColor="white"
            open={showDatePicker}
            mode="date"
            date={minimumToDate}
            maximumDate={maxToDate}
            minimumDate={minimumToDate}
            theme={ThemeManager.colors.themeColor === "dark" ? "dark" : "light"}
            textColor={ThemeManager.colors.textColor1}
            onConfirm={(date) => {
              console.log("fromDtae=-=-=-", fromDate);
              let value = Moment(date).format("YYYY-MM-DD");
              setToDate(value);
              console.log("value=-wwww=", value);
              setShowDatePicker(false);
            }}
            onCancel={() => {
              setShowDatePicker(false);
            }}
          />
        )}
      </>
    );
  };
  return (
    <Wrap
      style={{ backgroundColor: ThemeManager.colors.DashboardBG }}
      screenStyle={[
        styles.screenStyle,
        { backgroundColor: ThemeManager.colors.DashboardBG },
      ]}
      darkMode={ThemeManager.colors.themeColor === "light" ? false : true}
      bottomStyle={{ backgroundColor: ThemeManager.colors.DashboardBG }}
    >
      <View
        style={{ marginHorizontal: 16, marginBottom: 15, marginVertical: 10 }}
      >
        <SimpleHeader
          backImageColor={{ tintColor: ThemeManager.colors.headTxt }}
          onBackPress={() => {
            Actions.pop();
          }}
        />
      </View>
      <Loader isLoading={isCardTopUpTrxListLoading} />
      {/* <KeyboardAwareScrollView
        bounces={false}
        keyboardShouldPersistTaps="handled"
        nestedScrollEnabled={true}
        contentContainerStyle={{ flex: 1 }}
      > */}
      <ScrollView bounces={false}>
        <View style={{ marginHorizontal: 10, marginVertical: 15 }}>
          <Text
            style={{
              fontSize: 22,
              fontFamily: Fonts.medium,
              color: ThemeManager.colors.textColor,
            }}
          >
            {strings.cardScreen.transaction_statement}
          </Text>
          <View
            style={{
              justifyContent: "center",
              // marginHorizontal: 15,
            }}
          >
            <Text
              style={{
                color: ThemeManager.colors.textColor,
                fontSize: 13,
                fontFamily: Fonts.regular,
                marginTop: 10,
              }}
            >
              {strings.cardScreen.select_card}
            </Text>
            <View>
              <SelectDropdown
                key={"first"}
                data={cardInfos}
                defaultValueByIndex={selectedCardIndex}
                onSelect={(selectedItem, index) => {
                  console.log("selectedItem=-=www-=", selectedItem);
                  console.log("selectedItem=-=indexwwww-=", index);
                  setSelectedCard(selectedItem);
                  setSelectedCardIndex(index);
                  // onSelect(selectedItem, index);
                }}
                // selectedIndex={genderIndex}
                // buttonStyle={styles.dropdown3BtnStyle}
                buttonStyle={{
                  // width: "100%",
                  width: "100%",
                  borderRadius: 6,
                  height: 49,
                  marginBottom: 10,
                  backgroundColor: ThemeManager.colors.tabBackground,
                }}
                renderCustomizedButtonChild={(selectedItem, index) => {
                  console.log("selectedItem=-=www+++-=-", selectedItem);
                  console.log("selectedItem=-++www+-index", index);
                  console.log("selectedItem=-=-++=-111", selectedCard);

                  return (
                    <View style={[styles.dropdown3BtnChildStyle]}>
                      <Text
                        style={[
                          styles.dropdown3BtnTxt,
                          {
                            color: ThemeManager.colors.textColor1,
                            textTransform: "capitalize",
                            fontFamily: Fonts.regular,
                            marginLeft: 5,
                          },
                        ]}
                      >
                        {selectedItem
                          ? selectedItem.card_number
                          : selectedCard.card_number}
                      </Text>

                      <Image
                        source={{ uri: Images.icon_dropDown }}
                        style={{
                          height: 15,
                          width: 15,
                          resizeMode: "contain",
                          tintColor: ThemeManager.colors.textColor1,
                          marginRight: 8,
                        }}
                      />
                    </View>
                  );
                }}
                dropdownStyle={[
                  {
                    backgroundColor: ThemeManager.colors.tabBackground,
                  },
                ]}
                rowStyle={[
                  {
                    backgroundColor: ThemeManager.colors.tabBackground,
                  },
                ]}
                renderCustomizedRowChild={(item, index) => {
                  console.log(
                    "print item -0-0-0>>",
                    item,
                    "=-=index=-=",
                    index
                  );
                  return (
                    <>
                      <View
                        style={{
                          flex: 1,

                          flexDirection: "row",
                          justifyContent: "flex-start",
                          alignItems: "center",

                          paddingHorizontal: 15,
                          paddingVertical: 10,
                        }}
                      >
                        <Text
                          style={[
                            styles.dropdown3RowTxt,
                            {
                              color:
                                selectedCardIndex === index
                                  ? ThemeManager.colors.selectedTextColor
                                  : ThemeManager.colors.textColor1,
                              fontFamily: Fonts.regular,
                              textTransform: "capitalize",
                            },
                          ]}
                        >
                          {item?.card_number}
                        </Text>
                      </View>
                    </>
                  );
                }}
              />
            </View>
            <View
              style={{
                justifyContent: "space-between",
                alignItems: "center",
                flexDirection: "row",
                marginTop: 10,
              }}
            >
              <View style={{ width: "48%" }}>
                <Text
                  style={{
                    color: ThemeManager.colors.textColor,
                    fontSize: 13,
                    fontFamily: Fonts.regular,
                  }}
                >
                  {strings.cardScreen.transaction_from_date}
                </Text>
                <TouchableOpacity
                  onPress={() => {
                    setfromDateSelected(true);
                    setShowDatePicker(true);
                  }}
                  style={{
                    marginTop: 5,
                    height: 50,
                    backgroundColor: ThemeManager.colors.SwapInput,
                    justifyContent: "space-between",
                    flexDirection: "row",
                    borderRadius: 6,
                  }}
                >
                  <View style={{ justifyContent: "center" }}>
                    <Text
                      style={{
                        fontFamily: Fonts.medium,
                        fontSize: 14,
                        color: ThemeManager.colors.textColor1,
                        marginLeft: 15,
                      }}
                    >
                      {fromDate}
                    </Text>
                  </View>
                  <View style={{ justifyContent: "center" }}>
                    <Image
                      source={{
                        uri: Images.icon_calender,
                      }}
                      style={{
                        width: 20,
                        height: 20,
                        resizeMode: "contain",
                        marginRight: 8,
                      }}
                    />
                  </View>
                </TouchableOpacity>
              </View>
              <View style={{ width: "48%" }}>
                <Text
                  style={{
                    color: ThemeManager.colors.textColor,
                    fontSize: 13,
                    fontFamily: Fonts.regular,
                  }}
                >
                  {strings.cardScreen.to_date}
                </Text>
                <TouchableOpacity
                  onPress={() => {
                    setfromDateSelected(false);
                    setShowDatePicker(true);
                  }}
                  style={{
                    marginTop: 5,
                    height: 50,
                    backgroundColor: ThemeManager.colors.SwapInput,
                    justifyContent: "space-between",
                    flexDirection: "row",
                    borderRadius: 6,
                  }}
                >
                  <View style={{ justifyContent: "center" }}>
                    <Text
                      style={{
                        fontFamily: Fonts.medium,
                        fontSize: 14,
                        color: ThemeManager.colors.textColor1,
                        marginLeft: 15,
                      }}
                    >
                      {toDate}
                    </Text>
                  </View>
                  <View style={{ justifyContent: "center" }}>
                    <Image
                      source={{
                        uri: Images.icon_calender,
                      }}
                      style={{
                        width: 20,
                        height: 20,
                        resizeMode: "contain",
                        marginRight: 8,
                      }}
                    />
                  </View>
                </TouchableOpacity>
              </View>
            </View>
            <ButtonPrimary
              style={{ marginVertical: 15, width: "100%", marginLeft: 0 }}
              title={strings.cardScreen.view_detailed_statement}
              onPress={() => {
                onButtonPress();
              }}
            />
            <FlatList
              nestedScrollEnabled
              keyboardShouldPersistTaps={"handled"}
              data={cardTopUpTrxListInfo}
              showsVerticalScrollIndicator={false}
              style={{ marginTop: 5, height: height }}
              bounces={false}
              // contentContainerStyle={{height: height - 80}}
              contentContainerStyle={{ flexGrow: 1 }}
              onEndReachedThreshold={0.3}
              extraData={cardTopUpTrxListInfo}
              onEndReached={() => {
                // isCloseToBottomTrx();
              }}
              // onEndReached={isCloseToBottomTrade}
              scrollEnabled={true}
              renderItem={({ item, index }) => {
                return (
                  <View
                    style={{
                      backgroundColor: ThemeManager.colors.SwapInput,
                      padding: 15,
                      marginBottom: 8,
                      borderRadius: 8,
                    }}
                  >
                    <View
                      style={[styles.rowStyle, { alignItems: "flex-start" }]}
                    >
                      <View
                        style={{
                          flexDirection: "row",
                          alignItems: "center",
                          marginBottom: 5,
                        }}
                      >
                        <Image
                          style={{
                            height: 18,
                            width: 18,
                            resizeMode: "contain",
                            tintColor: ThemeManager.colors.headerText,
                          }}
                          source={{ uri: Images.topUpIcon }}
                        />
                        <Text
                          style={[
                            styles.recentText,
                            {
                              color: ThemeManager.colors.headerText,
                              textAlign: "right",
                              marginLeft: 10,
                            },
                          ]}
                        >
                          {Moment(item.created_at).format("DD-MM-YY hh:mm:ss")}
                        </Text>
                      </View>
                    </View>
                    <View
                      style={[styles.rowStyle, { alignItems: "flex-start" }]}
                    >
                      <Text
                        style={[
                          styles.recentText,
                          {
                            fontSize: 17,
                            fontFamily: Fonts.bold,
                            lineHeight: 20,
                          },
                        ]}
                      >
                        {item.amount} {item.currency}
                      </Text>
                    </View>
                    <View
                      style={[styles.rowStyle, { alignItems: "flex-start" }]}
                    >
                      <Text
                        style={[
                          styles.recentText,
                          {
                            color: ThemeManager.colors.headerText,
                            textAlign: "right",
                            marginBottom: 3,
                          },
                        ]}
                      >
                        {item.order_no}
                      </Text>
                    </View>

                    <View
                      style={[styles.rowStyle, { alignItems: "flex-start" }]}
                    >
                      <Text
                        style={[
                          styles.recentText,
                          {
                            color:
                              item.topup_status == "success"
                                ? ThemeManager.colors.btnGreenColor
                                : ThemeManager.colors.headerText,
                            textAlign: "right",
                            textTransform: "capitalize",
                          },
                        ]}
                      >
                        {item.topup_status}
                      </Text>
                    </View>
                  </View>
                );
              }}
              ListFooterComponent={() => {
                return <View style={{ height: 15 }}></View>;
              }}
              keyExtractor={(item, index) => index.toString()}
            />
          </View>
        </View>
      </ScrollView>
      {/* </KeyboardAwareScrollView> */}
      {renderDatePicker()}
    </Wrap>
  );
};

export default TransactionStatement;

const useStyles = (theme) =>
  StyleSheet.create({
    mainContainer: { flex: 1, marginTop: 20, marginHorizontal: 15 },
    dropdown3BtnChildStyle: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
    },

    dropdown3BtnTxt: {
      textAlign: "center",
      fontSize: 14,
      marginHorizontal: 2,
    },

    dropdown3RowChildStyle: {
      flex: 1,

      justifyContent: "center",
      alignItems: "flex-start",

      paddingHorizontal: 15,
    },

    dropdown3RowTxt: {
      textAlign: "center",
      fontSize: 14,
      marginHorizontal: 12,
    },
    recentView: {
      backgroundColor: theme.colors.tabBackground,
      padding: 15,
      marginTop: 10,
      // borderRadius: 6,
    },
    rowStyle: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
    },
    recentText: {
      color: theme.colors.textColor,
      fontSize: 14,
      fontFamily: Fonts.regular,
    },
  });
