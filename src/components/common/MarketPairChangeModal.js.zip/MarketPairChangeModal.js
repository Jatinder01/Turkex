/* eslint-disable react-native/no-inline-styles */
import React, { useState, useRef, useEffect } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  Modal,
} from "react-native";
import { useSelector } from "react-redux";
import { ThemeManager } from "../../../ThemeManager";
import { colors, Fonts, Images } from "../../theme";
import ActionSheet from "react-native-actionsheet";
import { strings } from "../../../Localization";
import { Wrap } from "./Wrap";
import { useDispatch } from "react-redux";
import {
  buySellSocket,
  tradeValuesUpdate,
  getBalanceDetails,
  callTradeSocket,
  getUserAllBalance,
  getPublicTrade,
  placeTradeOrder,
  stopPreviousConnection,
  getTreadingRules,
  getTreadingFeee,
  tradeSocketClose,
  updateMarketPair,
} from "../../Redux/Actions";

const MarketPairChangeModalMemo = (props) => {
  const dispatch = useDispatch();
  const ActionSheetAsk = useRef(null);
  const [precision, setPrecision] = useState(4);
  const [dropdownSelectedValue, setDropdownSelectedValue] = useState("0.0001");
  const marketSocketReducer = useSelector((state) => state.marketSocketReducer);
  const tradeReducer = useSelector((state) => state.tradeReducer);
  const FundsReducer = useSelector((state) => state.FundsReducer);
  const [modalVisible, setModalVisible] = useState(props.visible);

  useEffect(() => {
    setModalVisible(props.visible);
  }, [props.visible]);

  const updateSocket = async (pair) => {
    dispatch(updateMarketPair(pair));
    dispatch(buySellSocket({ pair: pair }));
    dispatch(
      callTradeSocket({
        pair: pair,
      })
    );
  };
  const getUserBalance = (coinName) => {
    // alert(coinName);
    // dispatch(getBalanceDetails({ coinName }));
  };
  useEffect(() => {
    dispatch(
      getPublicTrade(
        tradeReducer.selectedCoinPair.base_unit +
          tradeReducer.selectedCoinPair.quote_unit
      )
    );
    return () => {};
  }, []);
  const tradeFeesFun = async (pair) => {
    let data = tradeReducer.tradeFeeData;
    let pairData = data.find((item) => item.id == pair);
    dispatch(
      tradeValuesUpdate({
        prop: "tradeFees",
        value: pairData,
      })
    );
    dispatch(
      tradeValuesUpdate({
        prop: "amountDecimalValue",
        value: pairData?.amount_precision,
      })
    );
    dispatch(
      tradeValuesUpdate({
        prop: "priceDecimalValue",
        value: pairData?.price_precision,
      })
    );
  };
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => props.closeModal()}
    >
      <Wrap
        darkMode={ThemeManager.colors.themeColor === "light" ? false : true}
        style={{ backgroundColor: ThemeManager.colors.DashboardBG }}
        screenStyle={[styles.screenStyle, { backgroundColor: "transparent" }]}
        bottomStyle={{ backgroundColor: ThemeManager.colors.DashboardBG }}
      >
        <View
          style={{
            backgroundColor: "rgba(255,255,255,0.1)",
            flex: 1,
          }}
        >
          <Text
            style={{
              color: ThemeManager.colors.textColor1,
              fontSize: 20,
              fontFamily: Fonts.medium,
              marginTop: 20,
              alignSelf: "center",
              textAlign: "center",
            }}
          >
            Coin Pair Change
          </Text>
          <TouchableOpacity
            onPress={props.closeModal}
            style={{
              position: "absolute",
              top: 20,
              right: 20,
              height: 40,
              width: 40,
              alignItems: "flex-end",
              justifyContent: "flex-start",
            }}
          >
            <Image
              source={{ uri: ThemeManager.ImageIcons.icon_close_main }}
              style={{
                height: 20,
                width: 20,
                resizeMode: "contain",
              }}
            />
          </TouchableOpacity>
          <FlatList
            keyboardShouldPersistTaps={"handled"}
            data={marketSocketReducer?.marketData}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => {
              return (
                <TouchableOpacity
                  onPress={() => {
                    let arr = [];
                    let pairValue = item.base_unit + item.quote_unit;
                    dispatch(updateMarketPair(pairValue));
                    dispatch(stopPreviousConnection()).then((res) => {
                      dispatch(tradeSocketClose()).then((res) => {
                        setTimeout(function () {
                          updateSocket(pairValue);
                        }, 1500);
                      });
                    });

                    getUserBalance(item?.quote_unit);
                    dispatch(
                      tradeValuesUpdate({
                        prop: "selectedCoinPair",
                        value: item,
                      })
                    );

                    props.closeModal();
                  }}
                  style={{
                    height: 50,
                    marginTop: 5,
                    backgroundColor: ThemeManager.colors.tabBackground,
                    justifyContent: "center",
                    marginHorizontal: 20,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      fontFamily: Fonts.regular,
                      color: ThemeManager.colors.textColor1,
                      marginLeft: 10,
                    }}
                  >
                    {item.name}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
      </Wrap>
    </Modal>
  );
};

const styles = StyleSheet.create({
  buySellTabBlock: {
    flexDirection: "row",
    borderWidth: 1,
    borderRadius: 100,
    marginTop: 10,
    marginBottom: 10,
    overflow: "hidden",
  },
  btnBlock: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    height: 35,
    borderBottomWidth: 0,
  },
  btnText: {
    fontSize: 13,
    lineHeight: 44,
    color: "#333",
  },
  textUppercase: {
    textTransform: "uppercase",
  },
  btnActive: {
    backgroundColor: "#900",
  },
});

export const MarketPairChangeModal = React.memo(MarketPairChangeModalMemo);
