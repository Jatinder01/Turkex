## 0.7.0

* ```ViewPager``` was replaced by ```ScrollView``` for android.
