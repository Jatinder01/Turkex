import {
  FAIL_OPEN_ORDER_SUCCESS,
  GET_OPEN_ORDER_SUBMIT,
  RESET_OPEN_ORDER_SUCCESS,
  UPDATE_OPEN_ORDER_SUCCESS,
  GET_OPEN_ORDER_SUCCESS,
} from '../Actions/types';

const INITIAL_STATE = {
  openOrders: [],

  openHistoryError: '',

  totalRecordsOpenHistory: 0,
  openHistoryLoading: false,
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case UPDATE_OPEN_ORDER_SUCCESS:
      return {...state, [action.payload.prop]: action.payload.value};

    case GET_OPEN_ORDER_SUBMIT:
      return {...state, openHistoryLoading: true, orderHistoryError: ''};
    case GET_OPEN_ORDER_SUCCESS:
      console.log('OPEN_ORDER_SUCCESS=-=-action=-=>>>', action);
      console.log('OPEN_ORDER_SUCCESS=-=state-=-=>>>', state);

      return {
        ...state,
        openOrders: state.openOrders.concat(action.payload.data),
        totalRecordsOpenHistory: action.payload.headers.total,
        openHistoryError: '',
        openHistoryLoading: false,
      };

    case FAIL_OPEN_ORDER_SUCCESS:
      //console.log(state, action);
      return {
        ...state,
        openHistoryError: action.payload,
        openHistoryLoading: false,
      };

    case RESET_OPEN_ORDER_SUCCESS:
      return {...state, ...INITIAL_STATE};
    default:
      return state;
  }
};
