import {Actions} from 'react-native-router-flux';
import {CoinCultApi} from '../../api';
import {APIClient} from '../../api/APIClient';
import END_POINT from '../../EndPoints';
import {
  LOGIN_USER_SUCCESS,
  LOGIN_USER_FAIL,
  LOGIN_USER,
  LOGIN_FORM_UPDATE,
  LOGIN_USER_ENABLE_AUTH,
  LOGOUT_USER_SUCCESS,
  EMPTY_CAPTCHA,
  UPDATE_USER_DATA,
  GET_PROFILE_1,
  AUTH_FIELD_VALIDATE,
  GAUTH_RESET,

  //email
  LOGIN_EMAIL_OTP_SUCCESS,
  LOGIN_EMAIL_OTP_FAIL,
  LOGIN_EMAIL_OTP_SUBMIT,
  LOGIN_EMAIL_OTP_RESET,
  //phone
  LOGIN_PHONE_OTP_SUCCESS,
  LOGIN_PHONE_OTP_FAIL,
  LOGIN_PHONE_OTP_SUBMIT,
  LOGIN_PHONE_OTP_RESET,
} from './types';

import {Platform, Alert} from 'react-native';
import * as constants from '../../Constants';
import Singleton from '../../Singleton';
import {getMultiLingualData} from '../../../Utils';
import {showMessage, hideMessage} from 'react-native-flash-message';
import {ThemeManager} from '../../../ThemeManager';

export const loginFormUpdate = ({prop, value}) => {
  return {
    type: LOGIN_FORM_UPDATE,
    payload: {prop, value},
  };
};

export const logoutAndReset = () => {
  return {
    type: 'LOGOUT',
  };
};
export const resetGAuth = () => {
  return {
    type: GAUTH_RESET,
  };
};
export const resetResendEmailotp = () => {
  return {
    type: LOGIN_EMAIL_OTP_RESET,
  };
};
export const logoutUser = () => dispatch => {
  return new Promise((resolve, reject) => {
    Singleton.getInstance()
      .getData(constants.ACCESS_TOKEN)
      .then(res => {
        CoinCultApi.delete(
          END_POINT.LOGIN_USER_API_POST +
            '?device_id=' +
            Singleton.getInstance().deviceToken,
          {
            headers: {
              // 'X-CSRF-Token': res,
              Authorization: res,
              'Content-Type': 'application/json',
            },
          },
        )
          .then(response => {
            console.log('logout success=-=-=-=-=-=>>>', response.data);
            logoutUserSuccess(dispatch, response.data);
            resolve(response.data);
          })
          .catch(error => {
            console.log(
              'Error12121212---logout=-=-=->>>',
              JSON.stringify(error),
            );
            loginUserFail(
              dispatch,
              getMultiLingualData(error.response.data.errors[0]),
            );
            reject(getMultiLingualData(error.response.data.errors[0]));
          });
      });
  });
};

export const getProfile1 = () => {
  return dispatch => {
    dispatch({type: GET_PROFILE_1});
    Singleton.getInstance()
      .getData(constants.IS_LOGIN)
      .then(isLogin => {
        if (isLogin == 'true') {
          Singleton.getInstance()
            .getData(constants.ACCESS_TOKEN)
            .then(res => {
              // alert(res);
            });
        }
      });
  };
};

export const getProfile = dispatch => {
  Singleton.getInstance()
    .getData(constants.IS_LOGIN)
    .then(isLogin => {
      if (isLogin == 'true') {
        Singleton.getInstance()
          .getData(constants.ACCESS_TOKEN)
          .then(res => {
            CoinCultApi.get(
              END_POINT.GET_USER_ME,
              // {withCredentials: true},

              {
                headers: {
                  contentType: 'application/json',
                  // 'X-CSRF-Token': res,
                  Authorization: res,
                },
              },
            )
              .then(userData => {
                geProfileSuccess(dispatch, userData.data);
                Singleton.getInstance().saveData(
                  constants.USER_DATA,
                  JSON.stringify(userData.data),
                );
              })
              .catch(error => {
                console.log('Err:geProfileSuccess=-=-= ' + error);
                if (error.response.status == '401') {
                  Actions.currentScene != 'Login' && Actions.replace('Login');
                  // Alert.alert(constants.APP_NAME, 'Session expired');
                  Singleton.getInstance().saveEmptyDefault();
                }
              });
          });
      }
    });
};
const resendEmailPHoneOtp = (dispatch, loginEmail, phoneNumber) => {
  console.log('loginEmail resendEmailPHoneOtp user=-=-=-=>>>> ', loginEmail);
  console.log('phoneNumber resendEmailPHoneOtp user=-=-=-=>>>> ', phoneNumber);

  dispatch({type: LOGIN_EMAIL_OTP_SUBMIT});
  CoinCultApi.post(END_POINT.RESEND_REGISTER_EMAIL_OTP, {
    email: loginEmail,
  })
    .then(response => {
      otpSentFail(dispatch, '');
      loginUserFail(dispatch, '');
      console.log(' resendEmailPHoneOtp user=-=-=-=>>>> ', response);
      if (response.status == 201) {
        otpSentSuccess(dispatch, response);
        showMessage({
          message: 'OTP sent on email successfully.',
          backgroundColor: ThemeManager.colors.tabBottomBorder,
          autoHide: true,
          duration: 1000,
          type: 'success',
        });
        Actions.currentScene != 'LoginVerification' &&
          Actions.push('LoginVerification', {
            loginEmail: loginEmail,
            phoneNumber: phoneNumber,
          });
      }
    })
    .catch(error => {
      console.log(
        'Error resendEmailPHoneOtp=-=-+++=-=>> ',
        JSON.stringify(error),
      );

      console.log('Error resendEmailPHoneOtp=-=-=-=>> ', error.errors[0]);
      otpSentFail(dispatch, getMultiLingualData(error.errors[0]));
      loginUserFail(dispatch, getMultiLingualData(error.errors[0]));
    });
  CoinCultApi.post(END_POINT.RESEND_REGISTER_PHONE_OTP, {
    phone_number: phoneNumber,
  })
    .then(response => {
      otpSentPhoneFail(dispatch, '');
      loginUserFail(dispatch, '');
      console.log(' RESEND_REGISTER_PHONE_OTP user=-=-=-=>>>> ', response);
      if (response.status == 201) {
        otpSentPhoneSuccess(dispatch, response);
        showMessage({
          message: 'OTP sent on phone successfully.',
          backgroundColor: ThemeManager.colors.tabBottomBorder,
          autoHide: true,
          duration: 3000,
          type: 'success',
        });
      }
    })
    .catch(error => {
      console.log(
        'Error RESEND_REGISTER_PHONE_OTP=-=-+++=-=>> ',
        JSON.stringify(error),
      );

      console.log('Error RESEND_REGISTER_PHONE_OTP=-=-=-=>> ', error.errors[0]);
      otpSentPhoneFail(dispatch, getMultiLingualData(error.errors[0]));
      loginUserFail(dispatch, getMultiLingualData(error.errors[0]));
    });
  // CoinCultApi.post(END_POINT.GENERATE_CODE_API_POST, {
  //   email: loginEmail,
  // })
  //   .then(response => {
  //     loginUserFail(dispatch, '');
  //     console.log(' forgotpass user=-=-=-=>>>> ', response);
  //     if (response.status == 201) {
  //       showMessage({
  //         message: 'Email sent successfully.',
  //         backgroundColor: ThemeManager.colors.tabBottomBorder,
  //         autoHide: true,
  //         duration: 4000,
  //         type: 'success',
  //       });
  //     }
  //   })
  //   .catch(error => {
  //     console.log('Error forgotpass=-=-+++=-=>> ', JSON.stringify(error));

  //     console.log('Error forgotpass=-=-=-=>> ', error.errors[0]);
  //     loginUserFail(dispatch, getMultiLingualData(error.errors[0]));
  //   });
};
export const loginUser = ({
  loginEmail,
  loginPassword,
  gOtpCode,
  gAuthEnable,
  recaptchaCheck,
  recaptchaData,
}) => {
  return dispatch => {
    dispatch({type: LOGIN_USER});

    var params = {};
    if (recaptchaCheck) {
      if (gAuthEnable) {
        params = {
          email: loginEmail,
          password: loginPassword,
          otp_code: gOtpCode,
          authentication_state: 'jwt',
          captcha_response: recaptchaData,
          login_device: {
            device_id:
              Singleton.getInstance().deviceToken === ''
                ? 'abc'
                : Singleton.getInstance().deviceToken,
            device_type: Platform.OS,
          },
        };
        console.log('print login pararms=-=-=>>>>', params);
      } else {
        params = {
          email: loginEmail,
          password: loginPassword,
          captcha_response: recaptchaData,
          authentication_state: 'jwt',

          login_device: {
            device_id:
              Singleton.getInstance().deviceToken === ''
                ? 'abc'
                : Singleton.getInstance().deviceToken,
            device_type: Platform.OS,
          },
        };
      }
      APIClient.getInstance()
        // .postNoHeader(END_POINT.LOGIN_USER_API_POST, params)
        .postNoHeader(END_POINT.LOGIN_USER_API_POST, params)

        .then(response => {
          console.log('response1 login-=-=-=-=-=+++>', response);
          // console.log(
          //   'response1 login response.phones.number=-=+++>',
          //   response.phones[0].number,
          // );

          // Singleton.getInstance().saveToken(response.csrf_token);
          Singleton.getInstance().saveToken('Bearer ' + response.access_token);

          // csrf_token
          if (response.state == 'active') {
            // alert('heloo');
            loginUserSuccess(dispatch, response);
            Singleton.getInstance()
              .deleteOfflineStepsData()
              .then(re => {
                Singleton.getInstance()
                  .saveData(constants.USER_DATA, JSON.stringify(response))
                  .then(res => {
                    Singleton.getInstance()
                      .saveData(constants.IS_LOGIN, 'true')
                      .then(res => {
                        // Actions.Home();
                        Actions.reset('Main');
                      });
                  });
              });
          } else {
            if (response.state == 'pending') {
              emptyCaptcha(dispatch);
              Alert.alert(
                constants.APP_NAME,
                'Your email address and phone number is not verified.Please verify your phone number and email address and then try to login again.',
                [
                  {
                    text: 'RESEND',
                    onPress: () => {
                      resendEmailPHoneOtp(
                        dispatch,
                        response.email,
                        response?.phones[0].number,
                      );
                    },
                  },
                  {
                    text: 'CANCEL',
                    onPress: () => loginUserFail(dispatch, ''),
                    style: 'cancel',
                  },
                ],
                {cancelable: false},
              );
            } else if (response.state == 'banned') {
              emptyCaptcha(dispatch);
              loginUserFail(dispatch, 'Your account is banned by admin');
            }
          }
        })
        .catch(error => {
          console.log(
            'Error login============login===========--',
            JSON.stringify(error),
          );

          if (error.errors[0] == 'identity.session.missing_otp') {
            loginUserEnterAuth(dispatch, true);
          }
          // else if (
          //   error.errors[0] == 'identity.captcha.verification_failed'
          // ) {
          //   loginUserFail(
          //     dispatch,
          //     'Captcha session expired, please verify captcha again',
          //   );
          // }
          else {
            if (error.errors[0] == 'identity.captcha.verification_failed') {
              // loginUserFail(dispatch, 'Captcha_Session_failed');
              loginUserFail(dispatch, getMultiLingualData(error.errors[0]));
            }
            loginUserFail(dispatch, getMultiLingualData(error.errors[0]));
          }
        }); //Call API
    }
  };
};

const authUserValidationFailed = (disptach, prop, value) => {
  disptach({
    type: AUTH_FIELD_VALIDATE,
    payload: {prop, value},
  });
};

const geProfileSuccess = (dispatch, user) => {
  dispatch({
    type: UPDATE_USER_DATA,
    payload: user,
  });
};

const loginUserFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGIN_USER_FAIL,
    payload: errorMessage,
  });
};
const otpSentFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGIN_EMAIL_OTP_FAIL,
    payload: errorMessage,
  });
};
const otpSentPhoneFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGIN_PHONE_OTP_FAIL,
    payload: errorMessage,
  });
};
const loginUserSuccess = (dispatch, user) => {
  dispatch({
    type: LOGIN_USER_SUCCESS,
    payload: user,
  });
};
const emptyCaptcha = dispatch => {
  dispatch({
    type: EMPTY_CAPTCHA,
  });
};
const logoutUserSuccess = (dispatch, user) => {
  dispatch({
    type: LOGOUT_USER_SUCCESS,
    payload: user,
  });
};
const otpSentSuccess = (dispatch, user) => {
  dispatch({
    type: LOGIN_EMAIL_OTP_SUCCESS,
    payload: user,
  });
};
const otpSentPhoneSuccess = (dispatch, user) => {
  dispatch({
    type: LOGIN_PHONE_OTP_SUCCESS,
    payload: user,
  });
};
const loginUserEnterAuth = (dispatch, user) => {
  dispatch({
    type: LOGIN_USER_ENABLE_AUTH,
    payload: user,
  });
};
