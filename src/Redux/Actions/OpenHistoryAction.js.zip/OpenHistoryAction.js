import {Actions} from 'react-native-router-flux';

import {CoinCultApi} from '../../api/CoinCultApi';
import {
  FAIL_OPEN_ORDER_SUCCESS,
  GET_OPEN_ORDER_SUBMIT,
  RESET_OPEN_ORDER_SUCCESS,
  UPDATE_OPEN_ORDER_SUCCESS,
  GET_OPEN_ORDER_SUCCESS,
} from './types';
import * as constants from '../../Constants';

import {getMultiLingualData} from '../../../Utils';
import {Alert} from 'react-native';
// import END_POINT from '../../EndPoints';
import Singleton from '../../Singleton';
import END_POINT from '../../EndPoints';

export const openOrderHistoryUpdate = ({prop, value}) => {
  console.log('======orderHistoryUpdate=====>' + prop, value);
  return {
    type: UPDATE_OPEN_ORDER_SUCCESS,
    payload: {prop, value},
  };
};

export const resetOpenOrderHistory = () => {
  return {
    type: RESET_OPEN_ORDER_SUCCESS,
  };
};

export const getOpenOrders = (param, concatLink, loader) => dispatch => {
  return new Promise((resolve, reject) => {
    loader && dispatch({type: GET_OPEN_ORDER_SUBMIT});
    //Call API
    // console.log(param);
    Singleton.getInstance()
      .getData(constants.ACCESS_TOKEN)
      .then(res => {
        //?limit=50&page=1
        console.log(
          'order history=--=-=-=--',
          END_POINT.GET_TRADE_ORDER_API +
            `?page=${param.page}&limit=${param.limit}${concatLink}`,
        );

        CoinCultApi.get(
          END_POINT.GET_TRADE_ORDER_API +
            `?page=${param.page}&limit=${param.limit}${concatLink}`,
          {
            headers: {
              'X-CSRF-Token': res,
              'Content-Type': 'application/json',
            },
          },
        )
          .then(response => {
            console.log('getOpenOrders=-=-=-=->>>>', JSON.stringify(response));
            getOpenOrderSuccess(dispatch, response);
            resolve(response.data);
          })
          .catch(error => {
            console.log(
              'Error get getOpenOrders=-=-=-=>>>',
              JSON.stringify(error),
            );
            if (error.response.status == '401') {
              Actions.currentScene != 'Login' && Actions.replace('Login');
              Alert.alert(constants.APP_NAME, 'Session expired');
              Singleton.getInstance().saveEmptyDefault();
            }
            getOpenOrdersFail(
              dispatch,
              getMultiLingualData(error.response.data.errors[0]),
            );
            reject(getMultiLingualData(error.response.data.errors[0]));
          });
      });
  });
};

const getOpenOrdersFail = (dispatch, errorMessage) => {
  dispatch({
    type: FAIL_OPEN_ORDER_SUCCESS,
    payload: errorMessage,
  });
};

const getOpenOrderSuccess = (dispatch, details) => {
  dispatch({
    type: GET_OPEN_ORDER_SUCCESS,
    payload: details,
  });
};
