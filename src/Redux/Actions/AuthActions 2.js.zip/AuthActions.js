import {Actions} from 'react-native-router-flux';
import {CoinCultApi} from '../../api';
import {APIClient} from '../../api/APIClient';
import END_POINT from '../../EndPoints';
import {
  LOGIN_USER_SUCCESS,
  LOGIN_USER_FAIL,
  LOGIN_USER,
  LOGIN_FORM_UPDATE,
  LOGIN_USER_ENABLE_AUTH,
  LOGOUT_USER_SUCCESS,
  EMPTY_CAPTCHA,
  UPDATE_USER_DATA,
  GET_PROFILE_1,
  AUTH_FIELD_VALIDATE,
  GAUTH_RESET,
  LOGOUT_USER_FAIL,
  //email
  LOGIN_EMAIL_OTP_SUCCESS,
  LOGIN_EMAIL_OTP_FAIL,
  LOGIN_EMAIL_OTP_SUBMIT,
  LOGIN_EMAIL_OTP_RESET,
  //phone
  LOGIN_PHONE_OTP_SUCCESS,
  LOGIN_PHONE_OTP_FAIL,
  LOGIN_PHONE_OTP_SUBMIT,
  LOGIN_PHONE_OTP_RESET,
} from './types';
import AsyncStorage from '@react-native-community/async-storage';
import {Platform, Alert} from 'react-native';
import * as constants from '../../Constants';
import Singleton from '../../Singleton';
import {getMultiLingualData} from '../../../Utils';
import {showMessage, hideMessage} from 'react-native-flash-message';
import {ThemeManager} from '../../../ThemeManager';
import {reject} from 'lodash';

export const loginFormUpdate = ({prop, value}) => {
  return {
    type: LOGIN_FORM_UPDATE,
    payload: {prop, value},
  };
};
/**************************************Update changeThemeAction ****************************************************/
export const changeThemeAction = value => {
  return {
    type: 'CHANGE_THEME',
    payload: value,
  };
};
/**************************************Update changeLanguageAction ****************************************************/
export const changeLanguageAction = value => {
  return {
    type: 'CHANGE_LANGUAGE',
    payload: value,
  };
};
/**************************************Logout and reset ****************************************************/
export const logoutAndReset = () => {
  return {
    type: 'LOGOUT',
  };
};
/**************************************Reset GAuth****************************************************/
export const resetGAuth = () => {
  return {
    type: GAUTH_RESET,
  };
};
export const resetResendEmailotp = () => {
  return {
    type: LOGIN_EMAIL_OTP_RESET,
  };
};
const clearAsyncStorage = async () => {
  AsyncStorage.clear();
};
export const logoutUser = () => dispatch => {
  return new Promise((resolve, reject) => {
    Singleton.getInstance()
      .getData(constants.REFRESH_TOKEN)
      .then(res => {
        CoinCultApi.delete(END_POINT.REFRESH_SESSION, {
          headers: {
            contentType: 'application/json',
            // 'X-CSRF-Token': res,
            'refresh-token': res,
          },
        })
          .then(response => {
            Singleton.getInstance().saveEmptyDefault();
            Singleton.getInstance()
              .deleteOfflineStepsData()
              .then(res => {
                dispatch(logoutAndReset());
              });
            Singleton.getInstance().clearStorage();
            Actions.currentScene != 'Login' && Actions.reset('Login');
            logoutUserSuccess(dispatch, response?.data);
            resolve(response?.data);
          })
          .catch(error => {
            Singleton.getInstance().saveEmptyDefault();
            Singleton.getInstance()
              .deleteOfflineStepsData()
              .then(res => {
                dispatch(logoutAndReset());
              });

            Singleton.getInstance().clearStorage();
            Actions.currentScene != 'Login' && Actions.reset('Login');
            logoutUserFail(
              dispatch,
              getMultiLingualData(error?.response?.data?.errors[0]),
            );
            reject(getMultiLingualData(error?.response?.data?.errors[0]));
          });
      });
  });
};

export const getProfile1 = () => {
  return dispatch => {
    return new Promise(async (resolve, reject) => {
      dispatch({type: GET_PROFILE_1});

      Singleton.getInstance()
        .getData(constants.IS_LOGIN)
        .then(isLogin => {
          if (isLogin == 'true') {
            // alert(res);
            CoinCultApi.get(END_POINT.GET_USER_ME, {
              headers: {
                contentType: 'application/json',
                Authorization: Singleton.getInstance().accessToken,
              },
            })
              .then(userData => {
                // console.log('getProfile1=-=-=->>>>>', userData);
                geProfileSuccess(dispatch, userData.data);
                Singleton.getInstance().saveData(
                  constants.USER_DATA,
                  JSON.stringify(userData.data),
                );
                resolve(userData.data);
              })
              .catch(error => {
                // console.log(
                //   'getProfile1=-=-=->>>>>error',
                //   JSON.stringify(error),
                // );

                if (error?.response?.status == '401') {
                  Singleton.getInstance().isLoginSuccess = true;
                  Singleton.getInstance().refreshToken(1);
                }
                reject(error?.response);
              });
          }
        });
    });
  };
};

export const getProfile = dispatch => {
  Singleton.getInstance()
    .getData(constants.IS_LOGIN)
    .then(isLogin => {
      if (isLogin == 'true') {
        CoinCultApi.get(
          END_POINT.GET_USER_ME,

          {
            headers: {
              contentType: 'application/json',
              Authorization: Singleton.getInstance().accessToken,
            },
          },
        )
          .then(userData => {
            geProfileSuccess(dispatch, userData.data);
            Singleton.getInstance().saveData(
              constants.USER_DATA,
              JSON.stringify(userData.data),
            );
          })
          .catch(error => {
            if (error?.response?.status == '401') {
              Singleton.getInstance().isLoginSuccess = true;
              Singleton.getInstance().refreshToken(1);
            }
          });
        // });
      }
    });
};
export const refreshTestSession = () => {
  return new Promise((resolve, reject) =>
    Singleton.getInstance()
      .getData(constants.IS_LOGIN)
      .then(isLogin => {
        if (isLogin == 'true') {
          CoinCultApi.get(END_POINT.GET_USER_ME, {
            headers: {
              contentType: 'application/json',
              Authorization: Singleton.getInstance().accessToken,
            },
          })
            .then(userData => {
              resolve(userData);
            })
            .catch(error => {
              if (error?.response?.status == '401') {
                Singleton.getInstance()
                  .refreshToken(0)
                  .then(res => {
                    resolve(res);
                  })
                  .catch(err => {
                    reject('failed to create session' + err);
                  });
              }
            });
        } else {
          reject('Not Login');
        }
      }),
  );
};

export const testSession = () => {
  return dispatch =>
    new Promise((resolve, reject) =>
      Singleton.getInstance()
        .getData(constants.IS_LOGIN)
        .then(isLogin => {
          if (isLogin == 'true') {
            CoinCultApi.get(END_POINT.GET_USER_ME, {
              headers: {
                contentType: 'application/json',
                Authorization: Singleton.getInstance().accessToken,
              },
            })
              .then(userData => {
                Singleton.getInstance().saveData(
                  constants.USER_DATA,
                  JSON.stringify(userData.data),
                );
                resolve(userData);
              })
              .catch(error => {
                if (error?.response?.status == '401') {
                  Singleton.getInstance()
                    .refreshToken(0)
                    .then(res => {
                      resolve(res);
                    })
                    .catch(err => {
                      reject('failed to create session' + err);
                    });
                }
              });
          } else {
            reject('Not Login');
          }
        }),
    );
};
const resendEmailPHoneOtp = (dispatch, loginEmail, phoneNumber) => {
  dispatch({type: LOGIN_EMAIL_OTP_SUBMIT});
  CoinCultApi.post(END_POINT.RESEND_REGISTER_EMAIL_OTP, {
    email: loginEmail,
  })
    .then(response => {
      otpSentFail(dispatch, '');
      loginUserFail(dispatch, '');
      if (response.status == 201) {
        otpSentSuccess(dispatch, response);
        showMessage({
          message: 'OTP sent on email successfully.',
          backgroundColor: ThemeManager.colors.tabBottomBorder,
          autoHide: true,
          duration: 1000,
          type: 'success',
        });
        Actions.currentScene != 'LoginVerification' &&
          Actions.push('LoginVerification', {
            loginEmail: loginEmail,
            phoneNumber: phoneNumber,
          });
      }
    })
    .catch(error => {
      otpSentFail(dispatch, getMultiLingualData(error?.errors[0]));
      loginUserFail(dispatch, getMultiLingualData(error?.errors[0]));
    });
  CoinCultApi.post(END_POINT.RESEND_REGISTER_PHONE_OTP, {
    phone_number: phoneNumber,
  })
    .then(response => {
      otpSentPhoneFail(dispatch, '');
      loginUserFail(dispatch, '');
      if (response.status == 201) {
        otpSentPhoneSuccess(dispatch, response);
        showMessage({
          message: 'OTP sent on phone successfully.',
          backgroundColor: ThemeManager.colors.tabBottomBorder,
          autoHide: true,
          duration: 3000,
          type: 'success',
        });
      }
    })
    .catch(error => {
      otpSentPhoneFail(dispatch, getMultiLingualData(error?.errors[0]));
      loginUserFail(dispatch, getMultiLingualData(error?.errors[0]));
    });
  // CoinCultApi.post(END_POINT.GENERATE_CODE_API_POST, {
  //   email: loginEmail,
  // })
  //   .then(response => {
  //     loginUserFail(dispatch, '');
  //     console.log(' forgotpass user=-=-=-=>>>> ', response);
  //     if (response.status == 201) {
  //       showMessage({
  //         message: 'Email sent successfully.',
  //         backgroundColor: ThemeManager.colors.tabBottomBorder,
  //         autoHide: true,
  //         duration: 4000,
  //         type: 'success',
  //       });
  //     }
  //   })
  //   .catch(error => {
  //     console.log('Error forgotpass=-=-+++=-=>> ', JSON.stringify(error));

  //     console.log('Error forgotpass=-=-=-=>> ', error.errors[0]);
  //     loginUserFail(dispatch, getMultiLingualData(error.errors[0]));
  //   });
};
export const loginUser = ({
  loginEmail,
  loginPassword,
  gOtpCode,
  gAuthEnable,
  recaptchaCheck,
  recaptchaData,
}) => {
  return dispatch => {
    dispatch({type: LOGIN_USER});

    var params = {};
    if (recaptchaCheck) {
      if (gAuthEnable) {
        params = {
          email: loginEmail,
          password: loginPassword,
          otp_code: gOtpCode,
          authentication_state: 'jwt',
          captcha_response: recaptchaData,
          login_device: {
            device_id:
              Singleton.getInstance().deviceToken === ''
                ? 'abc'
                : Singleton.getInstance().deviceToken,
            device_type: Platform.OS,
          },
        };
        console.log('print login pararms=-=-=>>>>', params);
      } else {
        params = {
          email: loginEmail,
          password: loginPassword,
          captcha_response: recaptchaData,
          authentication_state: 'jwt',

          login_device: {
            device_id:
              Singleton.getInstance().deviceToken === ''
                ? 'abc'
                : Singleton.getInstance().deviceToken,
            device_type: Platform.OS,
          },
        };
      }

      APIClient.getInstance()
        .postNoHeader(END_POINT.LOGIN_USER_API_POST, params)

        .then(response => {
          Singleton.getInstance().saveToken('Bearer ' + response.access_token);
          Singleton.getInstance().accessToken =
            'Bearer ' + response.access_token;
          // csrf_token
          if (response.state == 'active') {
            // alert('heloo');

            Singleton.getInstance()
              .deleteOfflineStepsData()
              .then(re => {
                Singleton.getInstance()
                  .saveData(constants.USER_DATA, JSON.stringify(response))
                  .then(res => {
                    Singleton.getInstance()
                      .saveData(constants.IS_LOGIN, 'true')
                      .then(res => {
                        // Actions.Home();
                        Actions.reset('Main');
                        loginUserSuccess(dispatch, response);
                      });
                  });
              });
          } else {
            if (response?.state == 'pending') {
              emptyCaptcha(dispatch);
              Alert.alert(
                constants.APP_NAME,
                'Your email address and phone number is not verified.Please verify your phone number and email address and then try to login again.',
                [
                  {
                    text: 'RESEND',
                    onPress: () => {
                      resendEmailPHoneOtp(
                        dispatch,
                        response?.email,
                        response?.phones[0]?.number,
                      );
                    },
                  },
                  {
                    text: 'CANCEL',
                    onPress: () => loginUserFail(dispatch, ''),
                    style: 'cancel',
                  },
                ],
                {cancelable: false},
              );
            } else if (response?.state == 'banned') {
              emptyCaptcha(dispatch);
              loginUserFail(dispatch, 'Your account is banned by admin');
            }
          }
        })
        .catch(error => {
          if (error?.errors[0] == 'identity.session.missing_otp') {
            loginUserEnterAuth(dispatch, true);
          }
          // else if (
          //   error.errors[0] == 'identity.captcha.verification_failed'
          // ) {
          //   loginUserFail(
          //     dispatch,
          //     'Captcha session expired, please verify captcha again',
          //   );
          // }
          else {
            if (error?.errors[0] == 'identity.captcha.verification_failed') {
              // loginUserFail(dispatch, 'Captcha_Session_failed');
              loginUserFail(dispatch, getMultiLingualData(error?.errors[0]));
            }
            loginUserFail(dispatch, getMultiLingualData(error?.errors[0]));
          }
        }); //Call API
    }
  };
};

const authUserValidationFailed = (disptach, prop, value) => {
  disptach({
    type: AUTH_FIELD_VALIDATE,
    payload: {prop, value},
  });
};

const geProfileSuccess = (dispatch, user) => {
  dispatch({
    type: UPDATE_USER_DATA,
    payload: user,
  });
};

const loginUserFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGIN_USER_FAIL,
    payload: errorMessage,
  });
};
const otpSentFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGIN_EMAIL_OTP_FAIL,
    payload: errorMessage,
  });
};
const otpSentPhoneFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGIN_PHONE_OTP_FAIL,
    payload: errorMessage,
  });
};
const loginUserSuccess = (dispatch, user) => {
  dispatch({
    type: LOGIN_USER_SUCCESS,
    payload: user,
  });
};
const emptyCaptcha = dispatch => {
  dispatch({
    type: EMPTY_CAPTCHA,
  });
};
const logoutUserSuccess = (dispatch, user) => {
  dispatch({
    type: LOGOUT_USER_SUCCESS,
    payload: user,
  });
};
const logoutUserFail = (dispatch, errorMessage) => {
  dispatch({
    type: LOGOUT_USER_FAIL,
    payload: errorMessage,
  });
};
const otpSentSuccess = (dispatch, user) => {
  dispatch({
    type: LOGIN_EMAIL_OTP_SUCCESS,
    payload: user,
  });
};
const otpSentPhoneSuccess = (dispatch, user) => {
  dispatch({
    type: LOGIN_PHONE_OTP_SUCCESS,
    payload: user,
  });
};
const loginUserEnterAuth = (dispatch, user) => {
  dispatch({
    type: LOGIN_USER_ENABLE_AUTH,
    payload: user,
  });
};
