import Singleton from "../Singleton";
import * as Constant from "../Constants";
import { Platform, NetInfo } from "react-native";
import RNFetchBlob from "rn-fetch-blob";
import END_POINT from "../EndPoints";
import moment from "moment";
const APIClient = class APIClient {
  static myInstance = null;

  static getInstance() {
    if (APIClient.myInstance == null) {
      APIClient.myInstance = new APIClient();
    }
    return this.myInstance;
  }
  getWithoutAuth(endpoint) {
    return new Promise((resolve, reject) => {
      console.log("url", `${END_POINT.BASE_URL}${endpoint}`);
      fetch(`${END_POINT.BASE_URL}${endpoint}`, {
        method: "GET",
      })
        .then(async (res) => {
          console.log("res", res);
          let response = await res?.json();
          if (!res?.ok) {
            return reject(response);
          }
          return resolve(response);
        })
        .catch(reject);
    });
  }
  get(endpoint, UserToken) {
    return new Promise((resolve, reject) => {
      console.log("UserToken", UserToken);
      console.log("url", `${END_POINT.BASE_URL}${endpoint}`);
      fetch(`${END_POINT.BASE_URL}${endpoint}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "api-access-token": UserToken,
        },
      })
        .then(async (res) => {
          console.log("res", res);
          let response = await res?.json();
          if (!res?.ok) {
            return reject(response);
          }
          return resolve(response);
        })
        .catch(reject);
    });
  }

  post(endpoint, data, UserToken) {
    return new Promise((resolve, reject) => {
      console.log("endpoint", endpoint);
      console.log("UserToken", UserToken);
      console.log("url", `${END_POINT.BASE_URL}${endpoint}`);
      console.log("data", JSON.stringify(data));
      fetch(`${END_POINT.BASE_URL}${endpoint}`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "api-access-token": UserToken,
        },
        body: JSON.stringify(data),
      })
        .then(async (res) => {
          console.log("res=-=-=-=-=>>>>", res);
          let response = await res?.json();
          console.log("response++++>>>>>>>>", response);
          if (!res?.ok) {
            return reject(response);
          }
          return resolve(response);
        })
        .catch(reject);
    });
  }
  convertUTCDateToLocalDate = function (date) {
    return new Date(
      Date.UTC(
        date.getFullYear(),
        date.getMonth(),
        date.getDate(),
        date.getHours(),
        date.getMinutes(),
        date.getSeconds()
      )
    );
  };
  postNoHeaderFirst(endpoint, data) {
    return new Promise((resolve, reject) => {
      console.log("url", `${END_POINT.BASE_URL}${endpoint}`);
      console.log("data", JSON.stringify(data));
      fetch(`${END_POINT.BASE_URL}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        // body: data,
        body: JSON.stringify(data),
      })
        .then(async (res) => {
          console.log("response postNoHeader res=-=-=-=->>", res);

          let response = await res?.json();
          console.log("postNoHeader res----check-", response);
          console.log("response postNoHeader", response);
          if (!res?.ok) {
            console.log("response postNoHeader--ok---", response);
            return reject(response);
          } else {
            return resolve(response);
          }
        })
        .catch(reject);
    });
  }
  postNoHeader(endpoint, data) {
    return new Promise((resolve, reject) => {
      console.log("url", `${END_POINT.BASE_URL}${endpoint}`);
      console.log("data", JSON.stringify(data));
      fetch(`${END_POINT.BASE_URL}${endpoint}`, {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        // body: data,
        body: JSON.stringify(data),
      })
        .then(async (res) => {
          console.log("response postNoHeader res=-=-=-=->>", res);

          let response = await res?.json();
          console.log("postNoHeader res----check-", response);
          console.log("response postNoHeader", response);
          if (!res?.ok) {
            console.log("response postNoHeader--ok---", response);
            return reject(response);
          } else {
            console.log("response postNoHeader--mnmn--", response);
            // console.log('res----check-',.set-cookie);
            var data = res?.headers.map;

            let expTime = data["access-expire"];

            let b = expTime.split(" ");
            expTime = b[0] + "T" + b[1];
            console.log("-----", expTime);
            let checExpTime = new Date(expTime).getTime();

            console.log("res----refresh-token-checExpTime", checExpTime);

            Singleton.getInstance().saveData(
              Constant.SAVED_COOKIES,
              data["set-cookie"]
            );
            Singleton.getInstance().saveData(
              Constant.REFRESH_TOKEN,
              `${data["refresh-token"]}`
            );
            Singleton.getInstance().saveData(
              Constant.EXPIRE_TIME,
              `${checExpTime}`
            );
            // Singleton.getInstance().isLoginSuccess = true;
            return resolve(response);
          }
        })
        .catch(reject);
    });
  }
  postFile(endpoint, data, UserToken) {
    return new Promise((resolve, reject) => {
      console.log("UserToken", UserToken);
      console.log("url", `${END_POINT.BASE_URL}${endpoint}`);
      // console.log('data', JSON.stringify(data))
      RNFetchBlob.fetch(
        "POST",
        `${END_POINT.BASE_URL}${endpoint}`,
        {
          "api-access-token": UserToken,
          "Content-Type": "multipart/form-data",
        },
        [data]
      )
        .then(async (res) => {
          console.log("res", res);
          let response = await res?.json();
          console.log("response", response);
          return resolve(response);
        })
        .catch(reject);
    });
  }
};
export { APIClient };
